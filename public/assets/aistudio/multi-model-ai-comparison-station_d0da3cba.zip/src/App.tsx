import { useState } from "react";
import CodeViewer from "./components/CodeViewer";
import appPySource from "./python-app/app.py?raw";
import indexHtmlSource from "./python-app/static/index.html?raw";

const CODE_FILES = [
  { id: "app", label: "app.py", filename: "app.py", language: "python", content: appPySource },
  {
    id: "index",
    label: "static/index.html",
    filename: "index.html",
    language: "html",
    content: indexHtmlSource,
  },
];

const DESKS = [
  {
    icon: "🏛️",
    title: "Masa 1 · Açık Konsey Odası",
    accent: "from-violet-500 to-indigo-600",
    ring: "ring-violet-500/30",
    desc:
      "3 model + 1 insan operatör aynı masada oturur. Model A (Stratejist) ilk argümanı sunar, Model B (Tekniker) teknik açıdan sınar, Model C (Eleştirmen) kör noktaları avlar. Adım adım ya da tur sayısı belirleyerek Otomatik Tartışma modunda ilerletebilir, istediğiniz an araya girip yönü değiştirebilirsiniz.",
    bullets: [
      "Sıralı konuşma: 'Sıradaki Sözü Ver' ile tek tıkla ilerletme",
      "Otomatik Tartışma: belirlenen tur sayısı kadar paslaşma",
      "Operatör her an araya girip mesaj enjekte edebilir",
    ],
  },
  {
    icon: "⚖️",
    title: "Masa 2 · Kör Jüri Odası",
    accent: "from-emerald-500 to-teal-600",
    ring: "ring-emerald-500/30",
    desc:
      "Modeller birbirini asla görmez. Aynı soru 3 modele paralel olarak gönderilir, 3 eşit kolonda bağımsız cevaplar akarak kıyaslanır. Sıfır grup düşüncesi, sıfır halüsinasyon zinciri.",
    bullets: [
      "Tek seferde yazılan soru 3 modele aynı anda gider",
      "Sonuçlar yan yana; kim doğru biliyor, kim boş konuşuyor net görülür",
      "Her kolon ayrı ayrı veya topluca durdurulabilir",
    ],
  },
  {
    icon: "🎯",
    title: "Masa 3 · Sentez ve Hakem Odası",
    accent: "from-amber-500 to-orange-600",
    ring: "ring-amber-500/30",
    desc:
      "Masa 1'deki tartışmayı veya Masa 2'deki bağımsız cevapları tek tıkla çekin. Tarafsız bir Hakem modeli, Konsensüs / Risk & Anlaşmazlık / Eylem Planı başlıklarıyla nihai raporu üretir.",
    bullets: [
      "'Metni Çek' butonuyla diğer masalardan içerik aktarımı",
      "Hakem modeli markdown formatında yapılandırılmış rapor sunar",
      "Girdi metni elle düzenlenebilir, rapor canlı akar (streaming)",
    ],
  },
];

const FEATURES = [
  { icon: "🔌", title: "OpenAI Uyumlu", text: "9Router, Ollama, LM Studio, OpenAI, DeepSeek, Groq — tek sözleşme." },
  { icon: "📡", title: "SSE Streaming", text: "Harf harf akan yanıtlar, terminal çöpü veya ham JSON yok." },
  { icon: "🛑", title: "Tek Tık Durdur", text: "Her koltuk/kolon için bağımsız AbortController ile anında kesme." },
  { icon: "🎨", title: "Koyu Fütüristik Tema", text: "#0d1117 zemin, rol bazlı neon renkler, cam efektli paneller." },
  { icon: "📝", title: "Markdown + Kod Vurgulama", text: "marked.js + highlight.js ile düzgün render, ham metin yok." },
  { icon: "💾", title: "Sıfır Kurulum Çöplüğü", text: "npm yok, webpack yok, Docker yok. Sadece pip + python app.py." },
];

const CHAIRS = [
  { key: "A", color: "#b16cea", name: "Stratejist", model: "pineal-general-reasoning", role: "Büyük resmi görür, hedef & risk değerlendirir" },
  { key: "B", color: "#39d98a", name: "Kodlayıcı / Tekniker", model: "asistan-ultra", role: "Teknik fizibiliteyi sınar, hataları yakalar" },
  { key: "C", color: "#58a6ff", name: "Eleştirmen / Şüpheci", model: "pineal-fast-extract", role: "Kör noktaları ve mantık hatalarını avlar" },
  { key: "J", color: "#f2b94d", name: "Hakem", model: "pineal-general-reasoning", role: "Sentezler, nihai eylem planı sunar" },
];

function Section({
  id,
  eyebrow,
  title,
  children,
}: {
  id: string;
  eyebrow: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-indigo-400">{eyebrow}</p>
      <h2 className="mt-2 text-2xl font-bold text-white sm:text-3xl">{title}</h2>
      <div className="mt-8">{children}</div>
    </section>
  );
}

export default function App() {
  const [navOpen, setNavOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#0a0e14] text-slate-200 antialiased">
      {/* Background glow */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 left-1/4 h-96 w-96 rounded-full bg-indigo-600/20 blur-[120px]" />
        <div className="absolute top-1/3 right-0 h-96 w-96 rounded-full bg-emerald-600/10 blur-[120px]" />
        <div className="absolute bottom-0 left-0 h-96 w-96 rounded-full bg-amber-500/10 blur-[120px]" />
      </div>

      {/* NAV */}
      <header className="sticky top-0 z-50 border-b border-white/5 bg-[#0a0e14]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-lg shadow-lg shadow-indigo-900/50">
            🧠
          </div>
          <div className="leading-none">
            <div className="text-sm font-bold text-white">KONSÜL AI</div>
            <div className="text-[10px] text-slate-500">Konsey &amp; Kör Jüri İstasyonu</div>
          </div>
          <nav className="ml-auto hidden gap-6 text-sm text-slate-400 md:flex">
            <a href="#mimari" className="hover:text-white">Mimari</a>
            <a href="#kurulum" className="hover:text-white">Kurulum</a>
            <a href="#kod" className="hover:text-white">Kaynak Kod</a>
            <a href="#ozellikler" className="hover:text-white">Özellikler</a>
          </nav>
          <button
            onClick={() => setNavOpen((v) => !v)}
            className="ml-auto rounded-lg border border-white/10 px-3 py-1.5 text-xs text-slate-300 md:hidden"
          >
            Menü
          </button>
        </div>
        {navOpen && (
          <div className="flex flex-col gap-2 border-t border-white/5 px-4 py-3 text-sm text-slate-300 md:hidden">
            <a href="#mimari" onClick={() => setNavOpen(false)}>Mimari</a>
            <a href="#kurulum" onClick={() => setNavOpen(false)}>Kurulum</a>
            <a href="#kod" onClick={() => setNavOpen(false)}>Kaynak Kod</a>
            <a href="#ozellikler" onClick={() => setNavOpen(false)}>Özellikler</a>
          </div>
        )}
      </header>

      {/* HERO */}
      <section className="relative mx-auto max-w-6xl px-4 pt-16 pb-10 sm:px-6 sm:pt-24">
        <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold">
          <span className="rounded-full border border-indigo-500/30 bg-indigo-500/10 px-3 py-1 text-indigo-300">FastAPI</span>
          <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-emerald-300">Python 100% Yerel</span>
          <span className="rounded-full border border-sky-500/30 bg-sky-500/10 px-3 py-1 text-sky-300">SSE Streaming</span>
          <span className="rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1 text-amber-300">Sıfır Bağımlılık Çöplüğü</span>
        </div>
        <h1 className="mt-6 max-w-3xl text-4xl font-extrabold leading-tight text-white sm:text-5xl">
          Çoklu Model{" "}
          <span className="bg-gradient-to-r from-violet-400 via-indigo-400 to-sky-400 bg-clip-text text-transparent">
            Konsey ve Kör Jüri
          </span>{" "}
          İstasyonu
        </h1>
        <p className="mt-5 max-w-2xl text-base text-slate-400 sm:text-lg">
          9Router, Ollama, LM Studio veya bulut API'lerinizdeki modelleri aynı masaya oturtun. Tartıştırın,
          birbirinden habersiz sorgulayın, sonra tarafsız bir hakeme nihai kararı sentezletin —
          tamamı tek bir <code className="rounded bg-white/10 px-1.5 py-0.5 text-sm text-indigo-300">python app.py</code> komutuyla, yerelinizde.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a
            href="#kod"
            className="rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-indigo-900/40 hover:brightness-110"
          >
            ⬇ Kodu Al &amp; Çalıştır
          </a>
          <a
            href="#mimari"
            className="rounded-xl border border-white/10 bg-white/5 px-5 py-3 text-sm font-bold text-slate-200 hover:bg-white/10"
          >
            Mimariyi İncele
          </a>
        </div>

        {/* mini preview */}
        <div className="mt-14 overflow-hidden rounded-2xl border border-white/10 bg-[#0d1117] shadow-2xl shadow-black/50">
          <div className="flex items-center gap-2 border-b border-white/10 bg-[#111722] px-4 py-2.5">
            <span className="h-2.5 w-2.5 rounded-full bg-rose-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-amber-500" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
            <span className="ml-3 text-[11px] text-slate-500">http://127.0.0.1:8888</span>
          </div>
          <div className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-3">
            {CHAIRS.filter((c) => c.key !== "J").map((c) => (
              <div
                key={c.key}
                className="rounded-xl border border-white/10 bg-[#161b22] p-3"
                style={{ borderLeft: `3px solid ${c.color}` }}
              >
                <div className="text-xs font-bold" style={{ color: c.color }}>
                  {c.name}
                </div>
                <div className="mt-1 text-[11px] text-slate-500">{c.model}</div>
                <div className="mt-2 h-2 w-3/4 rounded bg-white/10" />
                <div className="mt-1.5 h-2 w-1/2 rounded bg-white/5" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MİMARİ */}
      <Section id="mimari" eyebrow="Mimari" title="Üç çalışma masası, tek istasyon">
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {DESKS.map((d) => (
            <div
              key={d.title}
              className={`rounded-2xl border border-white/10 bg-white/[0.03] p-5 ring-1 ${d.ring}`}
            >
              <div className={`inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${d.accent} text-xl`}>
                {d.icon}
              </div>
              <h3 className="mt-4 text-lg font-bold text-white">{d.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{d.desc}</p>
              <ul className="mt-4 space-y-2">
                {d.bullets.map((b) => (
                  <li key={b} className="flex gap-2 text-xs text-slate-400">
                    <span className="mt-0.5 text-emerald-400">✓</span>
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* chairs table */}
        <div className="mt-8 overflow-hidden rounded-2xl border border-white/10">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/5 text-xs uppercase tracking-wide text-slate-400">
              <tr>
                <th className="px-4 py-3">Koltuk</th>
                <th className="px-4 py-3">Varsayılan Rol</th>
                <th className="px-4 py-3">Varsayılan Model ID</th>
                <th className="px-4 py-3">Görev</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {CHAIRS.map((c) => (
                <tr key={c.key} className="bg-white/[0.02]">
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center gap-2 font-semibold" style={{ color: c.color }}>
                      <span className="h-2 w-2 rounded-full" style={{ background: c.color }} />
                      {c.key}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-300">{c.name}</td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-400">{c.model}</td>
                  <td className="px-4 py-3 text-slate-400">{c.role}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      {/* KURULUM */}
      <Section id="kurulum" eyebrow="Kurulum" title="Tek tıkla, Windows üzerinde çalıştırın">
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6">
            <h3 className="text-base font-bold text-white">1. Dosyaları yerleştirin</h3>
            <p className="mt-2 text-sm text-slate-400">
              Aşağıdaki "Kaynak Kod" bölümünden <code className="rounded bg-white/10 px-1 py-0.5">app.py</code> dosyasını
              bir klasöre, <code className="rounded bg-white/10 px-1 py-0.5">index.html</code> dosyasını ise o klasörün
              içindeki <code className="rounded bg-white/10 px-1 py-0.5">static/</code> alt klasörüne kaydedin:
            </p>
            <pre className="mt-3 overflow-x-auto rounded-xl bg-[#0d1117] p-3 text-xs text-slate-300">
{`konsul-ai/
├── app.py
└── static/
    └── index.html`}
            </pre>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6">
            <h3 className="text-base font-bold text-white">2. Bağımlılıkları kurun</h3>
            <p className="mt-2 text-sm text-slate-400">Terminal / CMD üzerinden klasöre girip tek satır kurulum yapın:</p>
            <pre className="mt-3 overflow-x-auto rounded-xl bg-[#0d1117] p-3 text-xs text-emerald-300">
              pip install fastapi uvicorn httpx pydantic
            </pre>
            <h3 className="mt-5 text-base font-bold text-white">3. Çalıştırın</h3>
            <pre className="mt-3 overflow-x-auto rounded-xl bg-[#0d1117] p-3 text-xs text-emerald-300">python app.py</pre>
            <p className="mt-2 text-xs text-slate-500">
              Tarayıcı otomatik olarak <code className="rounded bg-white/10 px-1 py-0.5">http://127.0.0.1:8888</code> adresinde açılır.
              9Router / Ollama / LM Studio'nun arka planda açık olduğundan emin olun.
            </p>
          </div>
        </div>
      </Section>

      {/* KOD */}
      <Section id="kod" eyebrow="Kaynak Kod" title="Kopyala, indir, doğrudan çalıştır">
        <p className="mb-6 max-w-3xl text-sm text-slate-400">
          Aşağıda tam üretim kodu yer alıyor: FastAPI backend (<code className="rounded bg-white/10 px-1 py-0.5">app.py</code>) ve
          3 masayı yöneten tek sayfa arayüz (<code className="rounded bg-white/10 px-1 py-0.5">static/index.html</code>).
          Hiçbir derleme adımı gerekmez — dosyaları olduğu gibi kullanın.
        </p>
        <CodeViewer files={CODE_FILES} />
      </Section>

      {/* ÖZELLİKLER */}
      <Section id="ozellikler" eyebrow="Özellikler" title="Üretime hazır detaylar">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <div className="text-2xl">{f.icon}</div>
              <h3 className="mt-3 text-sm font-bold text-white">{f.title}</h3>
              <p className="mt-1.5 text-xs leading-relaxed text-slate-400">{f.text}</p>
            </div>
          ))}
        </div>
      </Section>

      <footer className="border-t border-white/5 px-4 py-8 text-center text-xs text-slate-600">
        Konsül AI — yerel-öncelikli, çoklu model karşılaştırma ve karar destek istasyonu. Tüm işlem bilgisayarınızda kalır.
      </footer>
    </div>
  );
}
