"""
========================================================================
 KONSUL AI - Coklu Model Konsey ve Kor Jüri Istasyonu
 FastAPI Backend - Tek dosya, sifir bagimlilik copluğu.
========================================================================

Calistirmak icin (Windows / Mac / Linux):

    pip install fastapi uvicorn httpx pydantic

    python app.py

Ardindan tarayici otomatik olarak http://127.0.0.1:8888 adresini acar.

Bu backend; 9Router (http://127.0.0.1:20128/v1), Ollama
(http://127.0.0.1:11434/v1), LM Studio veya herhangi bir OpenAI
uyumlu bulut API'si (OpenAI, DeepSeek, Groq, vb.) ile calisan, tek bir
genel amacli /api/chat endpoint'i uzerinden SSE (Server-Sent Events)
streaming yapar. Frontend (static/index.html) bu endpoint'e istedigi
Base URL / API Key / Model ID / Sistem Promptu ile istek atar.
========================================================================
"""

import json
import threading
import webbrowser
from pathlib import Path
from typing import List, Optional

import httpx
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# ------------------------------------------------------------------
# AYARLAR
# ------------------------------------------------------------------
APP_HOST = "127.0.0.1"
APP_PORT = 8888

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(title="Konsul AI - Coklu Model Istasyonu")


# ------------------------------------------------------------------
# VERI MODELLERI
# ------------------------------------------------------------------
class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    baseUrl: str
    apiKey: Optional[str] = ""
    model: str
    messages: List[ChatMessage]
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 2048


# ------------------------------------------------------------------
# YARDIMCI
# ------------------------------------------------------------------
def sse_pack(data: dict) -> bytes:
    """Bir Python dict'ini SSE 'data: ...\\n\\n' formatina paketler."""
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n".encode("utf-8")


# ------------------------------------------------------------------
# ANA PROXY ROTASI (Her masa / her koltuk bunu kullanir)
# ------------------------------------------------------------------
@app.post("/api/chat")
async def chat_proxy(req: ChatRequest, request: Request):
    """
    OpenAI uyumlu /chat/completions endpoint'ine vekaleten (proxy)
    istek atar ve yaniti SSE olarak frontend'e aninda akitir (streaming).
    9Router, Ollama, LM Studio, OpenAI, DeepSeek, Groq -- hepsiyle
    ayni sozlesme (contract) uzerinden calisir.
    """
    url = req.baseUrl.rstrip("/") + "/chat/completions"
    headers = {"Content-Type": "application/json"}
    if req.apiKey:
        headers["Authorization"] = f"Bearer {req.apiKey}"

    payload = {
        "model": req.model,
        "messages": [m.dict() for m in req.messages],
        "temperature": req.temperature,
        "max_tokens": req.max_tokens,
        "stream": True,
    }

    async def event_stream():
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(180.0)) as client:
                async with client.stream("POST", url, headers=headers, json=payload) as resp:
                    if resp.status_code != 200:
                        body = await resp.aread()
                        msg = body.decode(errors="ignore")[:400]
                        yield sse_pack({
                            "error": f"Sunucu hatasi ({resp.status_code}) - {req.baseUrl} : {msg}"
                        })
                        yield b"data: [DONE]\n\n"
                        return

                    async for line in resp.aiter_lines():
                        if await request.is_disconnected():
                            break
                        if not line:
                            continue
                        if not line.startswith("data:"):
                            continue
                        data_str = line[5:].strip()
                        if data_str == "[DONE]":
                            break
                        try:
                            obj = json.loads(data_str)
                        except Exception:
                            continue
                        try:
                            choice = obj.get("choices", [{}])[0]
                            delta = choice.get("delta", {}) or {}
                            content = delta.get("content") or ""
                            if content:
                                yield sse_pack({"delta": content})
                        except Exception:
                            continue

            yield b"data: [DONE]\n\n"

        except httpx.ConnectError:
            yield sse_pack({
                "error": f"Baglanti kurulamadi: {req.baseUrl}. "
                         f"Yerel sunucunun (9Router / Ollama / LM Studio) acik oldugundan emin olun."
            })
            yield b"data: [DONE]\n\n"
        except httpx.ReadTimeout:
            yield sse_pack({"error": "Istek zaman asimina ugradi (timeout)."})
            yield b"data: [DONE]\n\n"
        except Exception as exc:  # son çare - asla çökme
            yield sse_pack({"error": f"Beklenmeyen hata: {str(exc)}"})
            yield b"data: [DONE]\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "konsul-ai"}


# ------------------------------------------------------------------
# STATIK DOSYALAR (Frontend) - index.html burada servis edilir
# ------------------------------------------------------------------
if STATIC_DIR.exists():
    app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")


def _open_browser():
    try:
        webbrowser.open(f"http://{APP_HOST}:{APP_PORT}")
    except Exception:
        pass


if __name__ == "__main__":
    threading.Timer(1.2, _open_browser).start()
    print("=" * 64)
    print("  KONSUL AI baslatiliyor...")
    print(f"  Arayuz adresi : http://{APP_HOST}:{APP_PORT}")
    print("  Durdurmak icin : CTRL + C")
    print("=" * 64)
    uvicorn.run(app, host=APP_HOST, port=APP_PORT, log_level="warning")
