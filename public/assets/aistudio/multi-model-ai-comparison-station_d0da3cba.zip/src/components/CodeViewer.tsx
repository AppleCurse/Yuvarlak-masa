import { useState } from "react";

type CodeFile = {
  id: string;
  label: string;
  filename: string;
  language: string;
  content: string;
};

export default function CodeViewer({ files }: { files: CodeFile[] }) {
  const [active, setActive] = useState(files[0]?.id);
  const [copied, setCopied] = useState(false);
  const current = files.find((f) => f.id === active) ?? files[0];

  const handleCopy = async () => {
    if (!current) return;
    try {
      await navigator.clipboard.writeText(current.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* ignore */
    }
  };

  const handleDownload = () => {
    if (!current) return;
    const blob = new Blob([current.content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = current.filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadAll = () => {
    files.forEach((f, i) => {
      setTimeout(() => {
        const blob = new Blob([f.content], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = f.filename;
        a.click();
        URL.revokeObjectURL(url);
      }, i * 300);
    });
  };

  if (!current) return null;

  return (
    <div className="rounded-2xl border border-white/10 bg-[#0d1117] overflow-hidden">
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 bg-[#111722] px-3 py-2">
        <div className="flex gap-1">
          {files.map((f) => (
            <button
              key={f.id}
              onClick={() => setActive(f.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                current.id === f.id
                  ? "bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-900/40"
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="ml-auto flex gap-2">
          <button
            onClick={handleCopy}
            className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:bg-white/5"
          >
            {copied ? "✓ Kopyalandı" : "📋 Kopyala"}
          </button>
          <button
            onClick={handleDownload}
            className="rounded-lg border border-white/10 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:bg-white/5"
          >
            ⬇ {current.filename}
          </button>
          <button
            onClick={handleDownloadAll}
            className="rounded-lg bg-emerald-600/90 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-500"
          >
            ⬇ Tüm Projeyi İndir
          </button>
        </div>
      </div>
      <div className="max-h-[560px] overflow-auto">
        <pre className="m-0 p-4 text-[12.5px] leading-relaxed text-slate-200">
          <code>{current.content}</code>
        </pre>
      </div>
    </div>
  );
}
