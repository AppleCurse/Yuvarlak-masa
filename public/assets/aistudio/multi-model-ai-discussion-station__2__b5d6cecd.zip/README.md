# KONSÜL AI · Çoklu Model "Konsey ve Kör Jüri" İstasyonu

Üç masalı, çoklu yapay zekâ tartışma ve karşılaştırma istasyonu. Tüm model uçları
**OpenAI uyumlu** `/chat/completions` standardı üzerinden konuşur: 9Router
(`127.0.0.1:20128/v1`), Ollama (`11434/v1`), LM Studio (`1234/v1`), DeepSeek, Groq, OpenAI.

## Odalar

| Masa | Ad | İşleyiş |
| --- | --- | --- |
| 1 | 🏛️ **Açık Konsey Odası** | Model A (Stratejist) → Model B (Tekniker) → Model C (Eleştirmen). Her konuşmacı kendinden öncekilerin tutanağını okur. *Sonraki Sözü Ver* ile adım adım, *Otomatik Tartışma* ile tur sayısı kadar kesintisiz ilerler. Operatör istediği anda söz alıp tartışmayı yönlendirir. |
| 2 | ⚖️ **Kör Jüri Odası** | Aynı soru üç modele **paralel** gider; modeller birbirini görmez/duymaz (istemde kör jüri kuralı zorunlu). Yan yana 3 eşit sütunda bağımsız yanıtlar akar; token/süre ölçülür. |
| 3 | 🎯 **Sentez ve Hakem Odası** | *Konseyden Çek* / *Kör Jüriden Çek* / arşivden seç → Hakem modeli raporu üretir: **Konsensüs · Anlaşmazlık ve Risk · Operatör için Eylem Planı · Hakem Notu**. Bölümler otomatik kartlara ayrılır, Markdown olarak indirilir. |

Ek olarak **Kayıtlar** (tüm oturumların kalıcı arşivi, sabitleme/silme/geri açma) ve
**Yapılandırma** (uçlar, koltuklar, roller, sistem istemleri, sıcaklık, max token, akış hızı).

## Teknik

- **Arka uç:** Next.js (App Router) + FastAPI benzeri SSE proxy rotası (`/api/chat/stream`),
  Drizzle ORM + PostgreSQL (providers / seats / topics / messages / settings).
- **Akış:** `ReadableStream` + `text/event-stream`; istemci `AbortController` ile **Durdur**
  desteği (iptal upstream `fetch`'e `request.signal` ile iletilir).
- **Ön yüz:** Tek sayfa, koyu fütüristik tema (`#0d1117` / `#161b22`), neon vurgular
  (eflatun = Stratejist, mavi = Tekniker, gül = Eleştirmen, altın = Hakem, beyaz = İnsan),
  `marked` + `highlight.js` + DOMPurify ile güvenli Markdown ve renkli kod blokları.
- **Simülatör:** Gerçek bir yönlendirici çalışmıyorsa istasyon boş kalmaz — `prov_demo`
  (Konsül Simülatör) rol farkındalıklı, kelime kelime akan yerel yanıtlar üretir. Bir uca
  *Test Et* ile ulaşılabilirse **Koltukları bağla** tek tıkla tüm masayı canlı modele taşır.
- Kısayollar: `Ctrl+1/2/3` masa geçişi, `Ctrl+.` üretimi durdur, `Ctrl+Enter` gönder.

## Çalıştırma

```bash
npm install
npx drizzle-kit push   # tabloları oluşturur (ilk açılışta varsayılanlar otomatik yazılır)
npm run build && npm start
```

## Masaüstü Python sürümü (npm/Docker yok)

`public/desktop/` altında tek tıkla çalışan bağımsız sürüm bulunur:

```bash
pip install fastapi uvicorn httpx
python app.py          # → http://127.0.0.1:8888, tarayıcı otomatik açılır
```

- `app.py`: FastAPI + Uvicorn + httpx; SSE akış motoru, OpenAI uyumlu proxy, uç testi
  (`/api/providers/{id}/probe`), `konsul.json` içinde kalıcı yapılandırma.
- `index.html`: CDN'siz, derleme gerektirmeyen tek dosya arayüz — üç masa, paralel kör jüri,
  Markdown + kod renklendirme, Durdur butonu, uç/koltuk düzenleyici.
