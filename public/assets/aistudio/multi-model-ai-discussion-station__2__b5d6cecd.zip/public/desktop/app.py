#!/usr/bin/env python3
"""
KONSÜL AI — Çoklu Model "Konsey ve Kör Jüri" İstasyonu (masaüstü sürümü)
=========================================================================
Tek dosya arka uç. npm / webpack / Docker / derleme hizmeti GEREKTİRMEZ.

Kurulum:
    pip install fastapi uvicorn httpx
Çalıştırma:
    python app.py            -> http://127.0.0.1:8888 (tarayıcı otomatik açılır)

Uyumluluk: 9Router (127.0.0.1:20128), Ollama (11434), LM Studio (1234),
OpenAI / DeepSeek / Groq — hepsi OpenAI standardı /chat/completions üzerinden.
Yapılandırma app.py'nin yanındaki konsul.json dosyasında saklanır.
"""

from __future__ import annotations

import json
import os
import sys
import threading
import time
import uuid
import webbrowser
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional

import httpx
import uvicorn
from fastapi import Body, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "konsul.json"
INDEX_PATH = BASE_DIR / "index.html"
HOST = os.environ.get("KONSUL_HOST", "127.0.0.1")
PORT = int(os.environ.get("KONSUL_PORT", "8888"))

# --------------------------------------------------------------------------- #
#  Varsayılan yapılandırma
# --------------------------------------------------------------------------- #
DEFAULT_PROVIDERS: List[Dict[str, Any]] = [
    {
        "id": "prov_9router",
        "name": "9Router",
        "kind": "openai",
        "baseUrl": "http://127.0.0.1:20128/v1",
        "apiKey": "",
        "color": "#c084fc",
        "models": ["pineal-general-reasoning", "pineal-fast-extract", "asistan-ultra"],
        "enabled": True,
    },
    {
        "id": "prov_ollama",
        "name": "Ollama",
        "kind": "openai",
        "baseUrl": "http://127.0.0.1:11434/v1",
        "apiKey": "",
        "color": "#22c55e",
        "models": ["llama3.2", "mixtral-8x7b", "codellama"],
        "enabled": True,
    },
    {
        "id": "prov_lmstudio",
        "name": "LM Studio",
        "kind": "openai",
        "baseUrl": "http://127.0.0.1:1234/v1",
        "apiKey": "",
        "color": "#38bdf8",
        "models": ["mixtral-8x7b-32768", "llama-3.1-70b"],
        "enabled": True,
    },
    {
        "id": "prov_deepseek",
        "name": "DeepSeek",
        "kind": "openai",
        "baseUrl": "https://api.deepseek.com/v1",
        "apiKey": os.environ.get("DEEPSEEK_API_KEY", ""),
        "color": "#34d399",
        "models": ["deepseek-chat", "deepseek-reasoner"],
        "enabled": False,
    },
    {
        "id": "prov_groq",
        "name": "Groq",
        "kind": "openai",
        "baseUrl": "https://api.groq.com/openai/v1",
        "apiKey": os.environ.get("GROQ_API_KEY", ""),
        "color": "#fb923c",
        "models": ["llama-3.3-70b-versatile"],
        "enabled": False,
    },
    {
        "id": "prov_openai",
        "name": "OpenAI",
        "kind": "openai",
        "baseUrl": "https://api.openai.com/v1",
        "apiKey": os.environ.get("OPENAI_API_KEY", ""),
        "color": "#f0f6fc",
        "models": ["gpt-4o-mini", "gpt-4o"],
        "enabled": False,
    },
]

DEFAULT_SEATS: List[Dict[str, Any]] = [
    {
        "id": "seat_strategist",
        "slot": "strategist",
        "name": "Model A",
        "roleTitle": "Stratejist",
        "avatar": "A",
        "color": "#c084fc",
        "providerId": "prov_9router",
        "model": "pineal-general-reasoning",
        "temperature": 0.7,
        "maxTokens": 900,
        "active": True,
        "systemPrompt": (
            "Sen Açık Konsey Odası'nın STRATEJİST üyesisin. Gündemi çerçevele, kısıtları "
            "netleştir, 2-3 uygulanabilir seçenek sun ve somut bir öneriyle bitir. "
            "Kısa, madde imli, Markdown biçiminde ve Türkçe yaz."
        ),
    },
    {
        "id": "seat_engineer",
        "slot": "engineer",
        "name": "Model B",
        "roleTitle": "Tekniker",
        "avatar": "B",
        "color": "#38bdf8",
        "providerId": "prov_9router",
        "model": "pineal-fast-extract",
        "temperature": 0.5,
        "maxTokens": 900,
        "active": True,
        "systemPrompt": (
            "Sen Açık Konsey Odası'nın TEKNİKER/KODLAYICI üyesisin. Önceki konuşmacıların "
            "iddialarını teknik olarak doğrula, eksikleri düzelt, uygulanabilir adımlar ve "
            "gerekirse kısa kod bloğu ver. Markdown, Türkçe."
        ),
    },
    {
        "id": "seat_critic",
        "slot": "critic",
        "name": "Model C",
        "roleTitle": "Eleştirmen",
        "avatar": "C",
        "color": "#fb7185",
        "providerId": "prov_9router",
        "model": "asistan-ultra",
        "temperature": 0.8,
        "maxTokens": 900,
        "active": True,
        "systemPrompt": (
            "Sen Açık Konsey Odası'nın ELEŞTİRMEN/ŞÜPHECİ üyesisin. Her önerinin açık noktasını, "
            "gizli varsayımını ve başarısızlık senaryosunu bul. En az 3 somut risk ve erken uyarı "
            "göstergesi ver. Markdown, Türkçe."
        ),
    },
    {
        "id": "seat_referee",
        "slot": "referee",
        "name": "Hakem",
        "roleTitle": "Sentez Hakemi",
        "avatar": "⚖",
        "color": "#fbbf24",
        "providerId": "prov_9router",
        "model": "pineal-general-reasoning",
        "temperature": 0.3,
        "maxTokens": 1400,
        "active": True,
        "systemPrompt": (
            "Sen Sentez ve Hakem Odası'nın HAKEM MODELİSİN. Verilen kaynakları analiz et ve YALNIZCA "
            "şu başlıklarla rapor üret:\n## ✅ Ortaklaşılan Konular (Konsensüs)\n"
            "## ⚠️ Anlaşmazlık ve Risk Noktaları\n"
            "## 🎯 Operatör İçin En Mantıklı Eylem Planı (Nihai Karar)\n"
            "## 📌 Hakem Notu\nKaynak metni birebir kopyalama, sentezle. Türkçe yaz."
        ),
    },
]

DEFAULT_CONFIG: Dict[str, Any] = {
    "providers": DEFAULT_PROVIDERS,
    "seats": DEFAULT_SEATS,
    "settings": {"rounds": 2, "streamSpeedMs": 18, "operatorName": "Operatör"},
}

_config_lock = threading.Lock()


def load_config() -> Dict[str, Any]:
    if not CONFIG_PATH.exists():
        save_config(DEFAULT_CONFIG)
        return json.loads(json.dumps(DEFAULT_CONFIG))
    try:
        with CONFIG_PATH.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (json.JSONDecodeError, OSError):
        return json.loads(json.dumps(DEFAULT_CONFIG))
    data.setdefault("providers", DEFAULT_PROVIDERS)
    data.setdefault("seats", DEFAULT_SEATS)
    data.setdefault("settings", DEFAULT_CONFIG["settings"])
    return data


def save_config(config: Dict[str, Any]) -> None:
    with _config_lock:
        tmp = CONFIG_PATH.with_suffix(".json.tmp")
        with tmp.open("w", encoding="utf-8") as handle:
            json.dump(config, handle, ensure_ascii=False, indent=2)
        tmp.replace(CONFIG_PATH)


# --------------------------------------------------------------------------- #
#  FastAPI uygulaması
# --------------------------------------------------------------------------- #
app = FastAPI(title="KONSÜL AI", version="2.0.0", docs_url=None, redoc_url=None)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatPayload(BaseModel):
    providerId: Optional[str] = None
    provider: Optional[Dict[str, Any]] = None
    model: str
    messages: List[Dict[str, str]]
    temperature: Optional[float] = 0.7
    maxTokens: Optional[int] = 900
    stream: bool = True


def find_provider(config: Dict[str, Any], provider_id: str) -> Dict[str, Any]:
    for provider in config["providers"]:
        if provider["id"] == provider_id:
            return provider
    raise HTTPException(status_code=404, detail=f"Sağlayıcı bulunamadı: {provider_id}")


def resolve_provider(payload: ChatPayload) -> Dict[str, Any]:
    if payload.provider:
        return {
            "name": payload.provider.get("name", "sağlayıcı"),
            "kind": payload.provider.get("kind", "openai"),
            "baseUrl": payload.provider.get("baseUrl", ""),
            "apiKey": payload.provider.get("apiKey", ""),
        }
    if not payload.providerId:
        raise HTTPException(status_code=400, detail="Sağlayıcı belirtilmedi")
    return find_provider(load_config(), payload.providerId)


def normalize_base(url: str) -> str:
    base = (url or "").strip().rstrip("/")
    if base.endswith("/chat/completions"):
        base = base[: -len("/chat/completions")]
    return base


def upstream_body(payload: ChatPayload, stream: bool) -> Dict[str, Any]:
    return {
        "model": payload.model,
        "messages": [
            {"role": m.get("role", "user"), "content": m.get("content", "")}
            for m in payload.messages
        ],
        "stream": stream,
        "temperature": payload.temperature if payload.temperature is not None else 0.7,
        "max_tokens": payload.maxTokens or 900,
    }


def sse(event: str, data: Dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


async def relay_stream(payload: ChatPayload) -> AsyncIterator[str]:
    provider = resolve_provider(payload)
    base = normalize_base(provider["baseUrl"])
    started = time.time()
    if not base:
        yield sse("error", {"message": "Base URL boş"})
        return

    headers = {"Content-Type": "application/json"}
    if provider.get("apiKey"):
        headers["Authorization"] = f"Bearer {provider['apiKey']}"

    total = ""
    try:
        timeout = httpx.Timeout(None, connect=10.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream(
                "POST", f"{base}/chat/completions", json=upstream_body(payload, True), headers=headers
            ) as response:
                if response.status_code != 200:
                    detail = (await response.aread()).decode("utf-8", "ignore")[:400]
                    yield sse(
                        "error",
                        {"message": f"{provider['name']} → HTTP {response.status_code}: {detail}"},
                    )
                    return

                yield sse("open", {"model": payload.model, "provider": provider["name"]})
                async for line in response.aiter_lines():
                    line = (line or "").strip()
                    if not line or not line.startswith("data:"):
                        continue
                    chunk = line[5:].strip()
                    if chunk == "[DONE]":
                        break
                    try:
                        data = json.loads(chunk)
                    except json.JSONDecodeError:
                        continue
                    choices = data.get("choices") or []
                    if not choices:
                        continue
                    piece = (choices[0].get("delta") or {}).get("content")
                    if piece is None:
                        piece = (choices[0].get("message") or {}).get("content")
                    if piece:
                        total += piece
                        yield sse("token", {"t": piece})
    except httpx.HTTPError as exc:
        yield sse("error", {"message": f"{provider['name']} erişilemedi: {exc.__class__.__name__}: {exc}"})
        return
    except Exception as exc:  # pragma: no cover - safety net
        yield sse("error", {"message": f"Beklenmeyen hata: {exc}"})
        return

    yield sse(
        "done",
        {"tokens": max(1, len(total) // 4), "latencyMs": int((time.time() - started) * 1000)},
    )


@app.post("/api/chat/stream")
async def chat_stream(payload: ChatPayload) -> StreamingResponse:
    return StreamingResponse(
        relay_stream(payload),
        media_type="text/event-stream; charset=utf-8",
        headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"},
    )


@app.post("/api/chat")
async def chat_once(payload: ChatPayload) -> JSONResponse:
    started = time.time()
    provider = resolve_provider(payload)
    base = normalize_base(provider["baseUrl"])
    if not base:
        raise HTTPException(status_code=400, detail="Base URL boş")

    headers = {"Content-Type": "application/json"}
    if provider.get("apiKey"):
        headers["Authorization"] = f"Bearer {provider['apiKey']}"

    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(None, connect=10.0)) as client:
            response = await client.post(
                f"{base}/chat/completions", json=upstream_body(payload, False), headers=headers
            )
    except httpx.HTTPError as exc:
        return JSONResponse({"error": f"{provider['name']} erişilemedi: {exc}"}, status_code=502)

    if response.status_code != 200:
        return JSONResponse(
            {"error": f"HTTP {response.status_code}: {response.text[:400]}"}, status_code=502
        )

    data = response.json()
    content = ""
    choices = data.get("choices") or []
    if choices:
        content = (choices[0].get("message") or {}).get("content", "")
    return JSONResponse(
        {
            "content": content,
            "model": payload.model,
            "provider": provider["name"],
            "tokens": (data.get("usage") or {}).get("completion_tokens", max(1, len(content) // 4)),
            "latencyMs": int((time.time() - started) * 1000),
        }
    )


@app.post("/api/providers/{provider_id}/probe")
async def probe(provider_id: str) -> JSONResponse:
    provider = find_provider(load_config(), provider_id)
    base = normalize_base(provider["baseUrl"])
    headers = {}
    if provider.get("apiKey"):
        headers["Authorization"] = f"Bearer {provider['apiKey']}"
    started = time.time()
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            response = await client.get(f"{base}/models", headers=headers)
    except httpx.HTTPError as exc:
        return JSONResponse(
            {"ok": False, "label": f"{exc.__class__.__name__}", "models": [], "latencyMs": 0}
        )
    latency = int((time.time() - started) * 1000)
    if response.status_code != 200:
        return JSONResponse(
            {"ok": False, "label": f"HTTP {response.status_code}", "models": [], "latencyMs": latency}
        )
    try:
        data = response.json()
    except json.JSONDecodeError:
        return JSONResponse({"ok": False, "label": "geçersiz yanıt", "models": [], "latencyMs": latency})

    models: List[str] = []
    if isinstance(data, dict) and isinstance(data.get("data"), list):
        models = [m.get("id") for m in data["data"] if isinstance(m, dict) and m.get("id")]
    elif isinstance(data, dict) and isinstance(data.get("models"), list):
        models = [m for m in data["models"] if isinstance(m, str)]

    if models:
        config = load_config()
        for entry in config["providers"]:
            if entry["id"] == provider_id:
                entry["models"] = models[:200]
        save_config(config)
    return JSONResponse({"ok": True, "label": f"{len(models)} model", "models": models, "latencyMs": latency})


@app.get("/api/config")
async def get_config() -> JSONResponse:
    return JSONResponse(load_config())


@app.put("/api/config")
async def put_config(request: Request) -> JSONResponse:
    body = await request.json()
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="Geçersiz yapılandırma")
    config = load_config()
    for key in ("providers", "seats", "settings"):
        if key in body and body[key] is not None:
            config[key] = body[key]
    save_config(config)
    return JSONResponse(config)


@app.get("/api/health")
async def health() -> JSONResponse:
    return JSONResponse({"ok": True, "id": str(uuid.uuid4())})


@app.get("/")
async def index() -> FileResponse:
    if not INDEX_PATH.exists():
        raise HTTPException(status_code=500, detail="index.html bulunamadı")
    return FileResponse(INDEX_PATH, media_type="text/html; charset=utf-8")


@app.get("/favicon.ico")
async def favicon() -> JSONResponse:
    return JSONResponse({"ok": True})


def open_browser() -> None:
    """Sunucu ayağa kalkınca varsayılan tarayıcıyı açar (Windows/macOS/Linux)."""
    import urllib.request

    url = f"http://{HOST}:{PORT}"
    for _ in range(20):
        time.sleep(0.4)
        try:
            with urllib.request.urlopen(url, timeout=1.0):
                break
        except Exception:
            continue
    try:
        webbrowser.open(url)
    except Exception:
        pass


def main() -> None:
    banner = "=" * 64
    print(banner)
    print("  KONSÜL AI · Çoklu Model Konsey ve Kör Jüri İstasyonu")
    print(banner)
    print(f"  Adres      : http://{HOST}:{PORT}")
    print(f"  Yapılandırma: {CONFIG_PATH}")
    print("  Odalar     : 1) Açık Konsey  2) Kör Jüri  3) Sentez & Hakem")
    print("  Durdur     : Ctrl+C")
    print(banner)
    if "--no-browser" not in sys.argv:
        threading.Thread(target=open_browser, daemon=True).start()
    uvicorn.run(app, host=HOST, port=PORT, log_level="warning", access_log=False)


if __name__ == "__main__":
    main()
