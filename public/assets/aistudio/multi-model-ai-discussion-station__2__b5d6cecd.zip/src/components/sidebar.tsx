"use client";

import { Archive, Landmark, OctagonX, Scale, SlidersHorizontal, Target } from "lucide-react";
import type { Station, View } from "@/lib/use-station";
import { cn, withAlpha } from "@/lib/format";
import { StatusDot } from "./ui";

const NAV: { view: View; label: string; sub: string; icon: typeof Landmark; accent: string }[] = [
  { view: "council", label: "Açık Konsey", sub: "Masa 1 · tartışma", icon: Landmark, accent: "#c084fc" },
  { view: "jury", label: "Kör Jüri", sub: "Masa 2 · bağımsız", icon: Scale, accent: "#38bdf8" },
  { view: "synthesis", label: "Sentez & Hakem", sub: "Masa 3 · nihai karar", icon: Target, accent: "#fbbf24" },
  { view: "records", label: "Kayıtlar", sub: "arşiv · tutanaklar", icon: Archive, accent: "#34d399" },
  { view: "settings", label: "Yapılandırma", sub: "sağlayıcı · koltuk", icon: SlidersHorizontal, accent: "#fb7185" },
];

export function Sidebar({ s }: { s: Station }) {
  const busy = s.councilRunning || s.juryRunning || s.synthLive;
  const enabled = s.providers.filter((p) => p.enabled);

  return (
    <aside className="flex h-full w-[248px] shrink-0 flex-col border-r border-line bg-[#0b0f15]/90">
      <div className="flex items-center gap-3 border-b border-line px-4 py-4">
        <span className="relative grid h-10 w-10 place-items-center rounded-xl border border-[#c084fc]/40 bg-gradient-to-br from-[#2a1b3d] to-[#101828]">
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="#c084fc" strokeWidth="1.6">
            <path d="M12 2.6 21 7.4v9.2L12 21.4 3 16.6V7.4z" strokeLinejoin="round" />
            <circle cx="12" cy="12" r="2.6" />
            <path d="M12 5.6v3.8M12 14.6v3.8M6.4 8.9l3 1.7M14.6 13.4l3 1.7" strokeLinecap="round" />
          </svg>
        </span>
        <div className="min-w-0">
          <p className="truncate text-[15px] font-bold tracking-[0.14em] text-chalk">KONSÜL AI</p>
          <p className="truncate text-[10.5px] uppercase tracking-[0.18em] text-mute">konsey · jüri · hakem</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-2.5 py-3">
        {NAV.map((item) => {
          const active = s.view === item.view;
          const Icon = item.icon;
          return (
            <button
              key={item.view}
              type="button"
              onClick={() => s.setView(item.view)}
              className={cn(
                "focus-ring group relative flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-all",
                active
                  ? "border-line2 bg-[#151b26]"
                  : "border-transparent hover:border-line hover:bg-[#111721]",
              )}
              style={active ? { boxShadow: `inset 2px 0 0 ${item.accent}` } : undefined}
            >
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border transition-colors"
                style={{
                  color: active ? item.accent : "#8b949e",
                  borderColor: active ? withAlpha(item.accent, 0.35) : "#232b36",
                  background: active ? withAlpha(item.accent, 0.12) : "transparent",
                }}
              >
                <Icon size={16} />
              </span>
              <span className="min-w-0 flex-1">
                <span
                  className={cn(
                    "block truncate text-[13px] font-medium",
                    active ? "text-chalk" : "text-mute group-hover:text-chalk",
                  )}
                >
                  {item.label}
                </span>
                <span className="block truncate text-[10.5px] text-mute/70">{item.sub}</span>
              </span>
              {item.view === "records" && s.archive.length ? (
                <span className="rounded-md border border-line2 bg-[#0f141d] px-1.5 py-0.5 font-mono text-[10px] text-mute">
                  {s.archive.length}
                </span>
              ) : null}
            </button>
          );
        })}
      </nav>

      <div className="border-t border-line px-3 py-3">
        <p className="mb-2 px-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-mute/70">
          uçlar
        </p>
        <ul className="space-y-1.5">
          {enabled.slice(0, 5).map((p) => {
            const probe = s.probes[p.id];
            const tone =
              p.kind === "demo" ? "#34d399" : probe?.status === "ok" ? "#22c55e" : probe?.status === "bad" ? "#ef4444" : "#5b6675";
            return (
              <li key={p.id} className="flex items-center gap-2 px-1">
                <StatusDot tone={tone} pulse={probe?.status === "probing"} />
                <span className="truncate text-[11.5px] text-mute">{p.name}</span>
                <span className="ml-auto truncate font-mono text-[10px] text-mute/60">
                  {p.kind === "demo" ? "yerel" : probe ? probe.label : "test edilmedi"}
                </span>
              </li>
            );
          })}
        </ul>

        {busy ? (
          <button
            type="button"
            onClick={s.stopEverything}
            className="focus-ring mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-[#ef4444]/45 bg-[#2a1215] px-3 py-2 text-[12.5px] font-semibold text-[#ff9aa2] transition-colors hover:bg-[#3a161b]"
          >
            <OctagonX size={14} /> Üretimi Durdur
          </button>
        ) : null}

        {s.offline ? (
          <p className="mt-3 rounded-lg border border-[#fbbf24]/35 bg-[#2a2314]/70 px-2.5 py-2 text-[11px] leading-relaxed text-[#fcd34d]">
            Veritabanına ulaşılamadı. İstasyon bellek içi çalışıyor; oturumlar kaydedilmez.
          </p>
        ) : null}
      </div>
    </aside>
  );
}
