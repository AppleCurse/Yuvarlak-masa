"use client";

import { ArrowRight, Eraser, Landmark, MessageSquarePlus, OctagonX, Play, Send, SkipForward, Sparkles } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { Station } from "@/lib/use-station";
import { cn, withAlpha } from "@/lib/format";
import { MessageBubble } from "./message-bubble";
import { Avatar, Button, Chip, EmptyState, Meter, Panel, PanelHead, StatusDot, TextInput } from "./ui";

export function CouncilRoom({ s }: { s: Station }) {
  const [draft, setDraft] = useState("");
  const [interjection, setInterjection] = useState("");
  const scroller = useRef<HTMLDivElement | null>(null);
  const sticky = useRef(true);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    const onScroll = () => {
      sticky.current = el.scrollHeight - el.scrollTop - el.clientHeight < 140;
    };
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    if (sticky.current || s.settings.autoScroll) el.scrollTop = el.scrollHeight;
  }, [s.councilMessages, s.settings.autoScroll]);

  const hasTopic = Boolean(s.councilTopic);
  const streaming = s.councilMessages.some((m) => m.status === "streaming");
  const lastBySeat = new Map<string, { tokens: number; latencyMs: number }>();
  for (const m of s.councilMessages) {
    if (m.seatId && m.tokens) lastBySeat.set(m.seatId, { tokens: m.tokens, latencyMs: m.latencyMs });
  }

  const submitTopic = async () => {
    const text = draft.trim();
    if (!text) return;
    setDraft("");
    await s.councilSend(text);
  };

  const submitInterjection = async () => {
    const text = interjection.trim();
    if (!text) return;
    setInterjection("");
    await s.councilInterject(text);
  };

  return (
    <div className="flex h-full min-h-0 gap-4 p-4">
      <Panel className="flex min-w-0 flex-1 flex-col overflow-hidden" glow="#c084fc">
        <PanelHead
          accent="#c084fc"
          icon={<Landmark size={15} />}
          title={
            <span className="flex items-center gap-2">
              MASA 1 · AÇIK KONSEY ODASI
              {s.councilTopic ? (
                <span className="max-w-[42vw] truncate text-[12px] font-normal text-mute">
                  — {s.councilTopic.title}
                </span>
              ) : null}
            </span>
          }
          right={
            <>
              <Chip color={streaming ? "#38bdf8" : hasTopic ? "#22c55e" : undefined}>
                <StatusDot
                  tone={streaming ? "#38bdf8" : hasTopic ? "#22c55e" : "#5b6675"}
                  pulse={streaming}
                />
                {streaming ? "konuşuluyor" : s.councilRunning ? "hazırlanıyor" : hasTopic ? "oturum açık" : "boş masa"}
              </Chip>
              <Button size="sm" variant="ghost" onClick={() => s.pullFromCouncil()} disabled={!s.councilMessages.length}>
                <ArrowRight size={13} /> Senteze aktar
              </Button>
              <Button size="sm" variant="ghost" onClick={() => void s.newCouncilTopic()} disabled={!hasTopic}>
                <MessageSquarePlus size={13} /> Yeni oturum
              </Button>
              <Button size="sm" variant="danger" onClick={() => void s.clearCouncil()} disabled={!hasTopic}>
                <Eraser size={13} /> Temizle
              </Button>
            </>
          }
        />

        <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto px-4 py-4">
          {!hasTopic && s.councilMessages.length === 0 ? (
            <EmptyState
              icon={<Landmark size={34} />}
              title="Masa boş — üç model ve bir insan operatör oturuyor"
              hint="Bir gündem yazın: Model A (Stratejist) açılışı yapar, Model B (Tekniker) üzerine ekler, Model C (Eleştirmen) her açığı denetler. İsterseniz adım adım 'Sonraki Sözü Ver' ile, isterseniz otomatik turlarla ilerleyin."
            />
          ) : (
            <>
              {s.councilTopic?.question ? (
                <div className="mb-4 rounded-xl border border-line2 bg-[#141a25] px-3.5 py-3">
                  <p className="text-[10.5px] font-semibold uppercase tracking-[0.16em] text-mute">gündem</p>
                  <p className="mt-1 text-[13.5px] leading-relaxed text-chalk">{s.councilTopic.question}</p>
                </div>
              ) : null}
              {s.councilMessages
                .filter((m) => m.speaker !== "system" || s.settings.showSystemLines)
                .map((m) => (
                  <MessageBubble key={m.id} message={m} />
                ))}
              {s.councilQueue.length ? (
                <div className="mb-2 flex items-center gap-2 pl-1 text-[11.5px] text-mute">
                  <Sparkles size={13} className="text-[#c084fc]" />
                  sırada:
                  {s.councilQueue.slice(0, 6).map((seatId, i) => {
                    const seat = s.seats.find((x) => x.id === seatId);
                    return seat ? (
                      <span key={`${seatId}-${i}`} style={{ color: seat.color }}>
                        {seat.name}
                      </span>
                    ) : null;
                  })}
                </div>
              ) : null}
            </>
          )}
        </div>

        <div className="border-t border-line bg-[#0f141c]/80 px-4 py-3">
          {!hasTopic ? (
            <div className="flex items-end gap-2">
              <div className="flex-1">
                <textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) void submitTopic();
                  }}
                  rows={2}
                  placeholder="Konseye gündemi atın… (Ctrl + Enter ile gönderilir)"
                  className="focus-ring w-full resize-y rounded-xl border border-line2 bg-[#0b1017] px-3.5 py-2.5 text-[13.5px] leading-relaxed text-chalk placeholder:text-mute/60"
                />
              </div>
              <Button variant="primary" onClick={() => void submitTopic()} disabled={!draft.trim()}>
                <Send size={14} /> Konseyi Başlat
              </Button>
            </div>
          ) : (
            <div className="flex items-end gap-2">
              <div className="flex-1">
                <textarea
                  value={interjection}
                  onChange={(e) => setInterjection(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) void submitInterjection();
                  }}
                  rows={2}
                  placeholder="Operatör olarak tartışmaya istediğiniz anda girin — sözünüz tutanağa işlenir ve sıradaki model bunu okur…"
                  className="focus-ring w-full resize-y rounded-xl border border-line2 bg-[#0b1017] px-3.5 py-2.5 text-[13.5px] leading-relaxed text-chalk placeholder:text-mute/60"
                />
              </div>
              <Button variant="outline" onClick={() => void submitInterjection()} disabled={!interjection.trim()}>
                <Send size={14} /> Sözü Al
              </Button>
            </div>
          )}
        </div>
      </Panel>

      <div className="flex w-[330px] shrink-0 flex-col gap-4 overflow-y-auto">
        <Panel>
          <PanelHead accent="#c084fc" title="Masadaki Üyeler" icon={<Landmark size={14} />} />
          <div className="space-y-2 p-3">
            {s.councilSeats.length === 0 ? (
              <p className="px-1 py-3 text-center text-[12px] text-mute">
                Aktif koltuk yok — Yapılandırma odasından bir koltuk açın.
              </p>
            ) : null}
            {s.councilSeats.map((seat) => {
              const provider = s.providerFor(seat);
              const stat = lastBySeat.get(seat.id);
              const isNext = s.nextSpeaker()?.id === seat.id && !s.councilRunning;
              const speaking = s.councilMessages.some((m) => m.seatId === seat.id && m.status === "streaming");
              return (
                <div
                  key={seat.id}
                  className={cn(
                    "rounded-xl border px-3 py-2.5 transition-all",
                    speaking ? "border-transparent" : "border-line bg-[#111721]",
                  )}
                  style={speaking ? { borderColor: withAlpha(seat.color, 0.5), background: withAlpha(seat.color, 0.07) } : undefined}
                >
                  <div className="flex items-center gap-2.5">
                    <Avatar label={seat.avatar} color={seat.color} size={30} ring={speaking} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12.5px] font-semibold text-chalk">
                        {seat.name} <span className="font-normal text-mute">· {seat.roleTitle}</span>
                      </p>
                      <p className="truncate font-mono text-[10.5px] text-mute/80">
                        {provider?.name ?? "—"} / {seat.model}
                      </p>
                    </div>
                    {isNext ? <Chip color="#c084fc">sırada</Chip> : null}
                    {speaking ? <Chip color="#38bdf8">konuşuyor</Chip> : null}
                  </div>
                  {stat ? (
                    <div className="mt-2 flex items-center gap-2 text-[10.5px] text-mute">
                      <Meter value={Math.min(100, (stat.tokens / Math.max(1, seat.maxTokens)) * 100)} color={seat.color} />
                      <span className="font-mono">
                        {stat.tokens} tok · {(stat.latencyMs / 1000).toFixed(1)} s
                      </span>
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        </Panel>

        <Panel>
          <PanelHead accent="#38bdf8" title="Tartışma Kontrolü" icon={<Play size={14} />} />
          <div className="space-y-3 p-3">
            <div className="flex items-end gap-2">
              <label className="flex-1">
                <span className="mb-1.5 block text-[11px] font-medium uppercase tracking-[0.08em] text-mute">
                  tur sayısı
                </span>
                <TextInput
                  type="number"
                  min={1}
                  max={8}
                  value={s.rounds}
                  onChange={(e) => s.setRounds(Math.max(1, Math.min(8, Number(e.target.value) || 1)))}
                />
              </label>
              <div className="flex-1 rounded-lg border border-line2 bg-[#0f141d] px-3 py-2 text-[11.5px] text-mute">
                <p className="font-mono text-[10.5px] uppercase tracking-wider text-mute/70">konuşma</p>
                <p className="text-chalk">
                  {s.councilMessages.filter((m) => m.speaker === "seat").length}{" "}
                  <span className="text-mute">/ {s.councilSeats.length * s.rounds}</span>
                </p>
              </div>
            </div>

            <Button
              className="w-full"
              variant="outline"
              onClick={() => void s.speakNext()}
              disabled={s.councilRunning || !hasTopic}
            >
              <SkipForward size={14} /> Sonraki Sözü Ver
            </Button>
            <Button
              className="w-full"
              variant="primary"
              onClick={() => void s.autoDebate()}
              disabled={s.councilRunning || !hasTopic}
            >
              <Play size={14} /> Otomatik Tartışma ({s.rounds} tur)
            </Button>
            <Button className="w-full" variant="danger" onClick={s.stopEverything} disabled={!s.councilRunning && !streaming}>
              <OctagonX size={14} /> Durdur
            </Button>

            {!hasTopic ? (
              <p className="rounded-lg border border-line bg-[#0f141d] px-2.5 py-2 text-[11.5px] leading-relaxed text-mute">
                Tartışmayı başlatmak için aşağıya bir gündem yazın. İlk sözü otomatik olarak{" "}
                <span className="text-chalk">{s.councilSeats[0]?.name ?? "Model A"}</span> alır.
              </p>
            ) : null}
          </div>
        </Panel>
      </div>
    </div>
  );
}
