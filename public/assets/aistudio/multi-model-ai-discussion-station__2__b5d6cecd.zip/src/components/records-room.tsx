"use client";

import { Archive, ExternalLink, Landmark, Pin, PinOff, Scale, Search, Target, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import type { Station } from "@/lib/use-station";
import { cn, timeAgo } from "@/lib/format";
import { Button, Chip, EmptyState, Panel, PanelHead, TextInput } from "./ui";

const ROOM_META: Record<string, { label: string; icon: typeof Landmark; color: string }> = {
  council: { label: "Konsey", icon: Landmark, color: "#c084fc" },
  jury: { label: "Kör Jüri", icon: Scale, color: "#38bdf8" },
  synthesis: { label: "Sentez", icon: Target, color: "#fbbf24" },
};

const STATUS_TONE: Record<string, string> = {
  done: "#22c55e",
  running: "#38bdf8",
  stopped: "#fbbf24",
  error: "#ef4444",
  idle: "#5b6675",
};

export function RecordsRoom({ s }: { s: Station }) {
  const [filter, setFilter] = useState<"all" | "council" | "jury" | "synthesis">("all");
  const [query, setQuery] = useState("");

  const entries = useMemo(() => {
    const q = query.trim().toLowerCase();
    return s.archive
      .filter((e) => (filter === "all" ? true : e.room === filter))
      .filter((e) => (q ? `${e.title} ${e.question}`.toLowerCase().includes(q) : true))
      .sort((a, b) => Number(b.pinned) - Number(a.pinned));
  }, [filter, query, s.archive]);

  return (
    <div className="flex h-full min-h-0 flex-col gap-4 p-4">
      <Panel>
        <PanelHead
          accent="#34d399"
          icon={<Archive size={15} />}
          title="KAYITLAR · OTURUM ARŞİVİ"
          right={
            <Button size="sm" variant="ghost" onClick={() => void s.refreshArchive()}>
              Yenile
            </Button>
          }
        />
        <div className="flex flex-wrap items-center gap-2 px-4 py-3">
          <div className="relative min-w-[240px] flex-1">
            <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-mute" />
            <TextInput
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Tutanaklarda ara…"
              className="pl-9"
            />
          </div>
          {(["all", "council", "jury", "synthesis"] as const).map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => setFilter(key)}
              className={cn(
                "focus-ring rounded-lg border px-3 py-1.5 text-[12px] transition-colors",
                filter === key
                  ? "border-[#34d399]/45 bg-[#34d399]/12 text-[#6ee7b7]"
                  : "border-line2 bg-[#111721] text-mute hover:text-chalk",
              )}
            >
              {key === "all" ? "Tümü" : ROOM_META[key].label}
            </button>
          ))}
        </div>
      </Panel>

      <Panel className="min-h-0 flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto p-3">
          {entries.length === 0 ? (
            <EmptyState
              icon={<Archive size={34} />}
              title="Kayıt yok"
              hint="Konsey, kör jüri ve sentez odalarında üretilen her oturum burada saklanır; tek tıkla geri açıp devam edebilirsiniz."
            />
          ) : (
            <ul className="space-y-2">
              {entries.map((entry) => {
                const meta = ROOM_META[entry.room] ?? ROOM_META.council;
                const Icon = meta.icon;
                return (
                  <li
                    key={entry.id}
                    className="group flex items-center gap-3 rounded-xl border border-line bg-[#111721] px-3 py-2.5 transition-colors hover:border-line2"
                  >
                    <span
                      className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border"
                      style={{
                        color: meta.color,
                        borderColor: `${meta.color}55`,
                        background: `${meta.color}14`,
                      }}
                    >
                      <Icon size={16} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-2 truncate text-[13px] font-medium text-chalk">
                        {entry.pinned ? <Pin size={11} className="shrink-0 text-[#fbbf24]" /> : null}
                        {entry.title}
                      </p>
                      <p className="truncate text-[11.5px] text-mute">
                        {entry.question || "gündem yok"} · {entry.count} mesaj · {timeAgo(entry.updatedAt)}
                      </p>
                    </div>
                    <Chip color={STATUS_TONE[entry.status] ?? "#5b6675"}>{entry.status}</Chip>
                    <div className="flex items-center gap-1 opacity-70 transition-opacity group-hover:opacity-100">
                      <Button size="sm" variant="outline" onClick={() => void s.openTopic(entry)}>
                        <ExternalLink size={12} /> Aç
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => void s.togglePin(entry)} title="Sabitle">
                        {entry.pinned ? <PinOff size={13} /> : <Pin size={13} />}
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => void s.deleteTopic(entry.id)} title="Sil">
                        <Trash2 size={13} className="text-[#fb7185]" />
                      </Button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </Panel>
    </div>
  );
}
