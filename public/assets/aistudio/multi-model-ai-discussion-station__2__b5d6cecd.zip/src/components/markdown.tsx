"use client";

import { useMemo } from "react";
import DOMPurify from "dompurify";
import { Marked } from "marked";
import { markedHighlight } from "marked-highlight";
import hljs from "highlight.js/lib/common";
import { cn } from "@/lib/format";

const marked = new Marked(
  markedHighlight({
    emptyLangClass: "hljs",
    langPrefix: "hljs language-",
    highlight(code, lang) {
      const language = hljs.getLanguage(lang) ? lang : "plaintext";
      try {
        return hljs.highlight(code, { language }).value;
      } catch {
        return code;
      }
    },
  }),
);

marked.setOptions({ gfm: true, breaks: true });

function render(src: string) {
  const raw = marked.parse(src, { async: false }) as string;
  if (typeof window === "undefined") return raw;
  return DOMPurify.sanitize(raw, { ADD_ATTR: ["target", "rel"] });
}

/** Sanitised markdown with GFM tables and highlighted code blocks. */
export function Markdown({
  children,
  className,
  streaming = false,
}: {
  children: string;
  className?: string;
  streaming?: boolean;
}) {
  const html = useMemo(() => render(children || ""), [children]);
  return (
    <div
      className={cn("md", streaming && "caret", className)}
      // Sanitised through DOMPurify on the client before injection.
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
