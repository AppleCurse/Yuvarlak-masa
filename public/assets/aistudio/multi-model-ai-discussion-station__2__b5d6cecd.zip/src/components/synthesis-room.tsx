"use client";

import {
  Check,
  Copy,
  Download,
  Eraser,
  Gavel,
  Landmark,
  OctagonX,
  Scale,
  Sparkles,
  Target,
  Wand2,
} from "lucide-react";
import { useMemo, useState } from "react";
import { api } from "@/lib/client-api";
import {
  cn,
  copyText,
  downloadText,
  parseReport,
  reportToMarkdown,
  timeAgo,
  transcriptFrom,
  withAlpha,
} from "@/lib/format";
import type { Station } from "@/lib/use-station";
import { Markdown } from "./markdown";
import { Avatar, Button, Chip, EmptyState, Panel, PanelHead, Select, StatusDot, TextArea } from "./ui";

const TONE = {
  consensus: { color: "#22c55e", icon: Check, title: "Ortaklaşılan Konular (Konsensüs)" },
  risk: { color: "#fb7185", icon: Sparkles, title: "Anlaşmazlık ve Risk Noktaları" },
  action: { color: "#fbbf24", icon: Target, title: "Operatör İçin Eylem Planı (Nihai Karar)" },
  note: { color: "#38bdf8", icon: Gavel, title: "Hakem Notu" },
} as const;

export function SynthesisRoom({ s }: { s: Station }) {
  const [copied, setCopied] = useState(false);
  const referee = s.refereeSeat;
  const provider = s.providerFor(referee);
  const sections = useMemo(() => parseReport(s.synthReport), [s.synthReport]);
  const showCards = !s.synthLive && sections.length >= 2;
  const archiveOptions = s.archive.filter((a) => a.room === "council" || a.room === "jury");

  const loadArchive = async (id: string) => {
    if (!id) return;
    try {
      const res = await api.getTopic(id);
      const label =
        res.topic.room === "council"
          ? `KAYNAK: Açık Konsey — "${res.topic.title}"`
          : `KAYNAK: Kör Jüri — "${res.topic.title}"`;
      const body =
        res.topic.room === "jury"
          ? res.messages
              .map((m) => `--- ${m.authorName} · ${m.roleTitle} [${m.model}] ---\n${m.content.trim()}`)
              .join("\n\n")
          : transcriptFrom(res.messages);
      s.setSynthSource([label, `GÜNDEM: ${res.topic.question}`, "", body].join("\n"));
      s.toast(`Arşivden çekildi: ${res.topic.title}`, "ok");
    } catch (err) {
      s.toast(err instanceof Error ? err.message : "Kaynak çekilemedi", "bad");
    }
  };

  const copyReport = async () => {
    const ok = await copyText(s.synthReport);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    }
  };

  return (
    <div className="flex h-full min-h-0 gap-4 p-4">
      <div className="flex w-[400px] shrink-0 flex-col gap-4 overflow-y-auto">
        <Panel glow="#fbbf24">
          <PanelHead accent="#fbbf24" icon={<Wand2 size={15} />} title="MASA 3 · KAYNAK AKTARIMI" />
          <div className="space-y-3 p-3">
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" onClick={() => void s.pullFromCouncil()}>
                <Landmark size={13} /> Konseyden Çek
              </Button>
              <Button variant="outline" onClick={() => void s.pullFromJury()}>
                <Scale size={13} /> Kör Jüriden Çek
              </Button>
            </div>

            <Select onChange={(e) => void loadArchive(e.target.value)} defaultValue="">
              <option value="">Arşivden bir tutanak seç…</option>
              {archiveOptions.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.room === "council" ? "Konsey" : "Jüri"} · {a.title} ({timeAgo(a.updatedAt)})
                </option>
              ))}
            </Select>

            <div>
              <p className="mb-1.5 flex items-center justify-between text-[11px] font-medium uppercase tracking-[0.08em] text-mute">
                kaynak metin
                <span className="normal-case tracking-normal text-mute/70">
                  {s.synthOrigin === "none" ? "boş" : s.synthOrigin === "council" ? "konsey tutanağı" : s.synthOrigin === "jury" ? "kör jüri" : s.synthOrigin === "archive" ? "arşiv" : "elle"} ·{" "}
                  {s.synthSource.length} karakter
                </span>
              </p>
              <TextArea
                rows={9}
                value={s.synthSource}
                onChange={(e) => s.setSynthSource(e.target.value)}
                placeholder="Konsey tutanağı veya kör jüri yanıtları buraya gelir. Elle de yapıştırabilirsiniz."
                className="font-mono text-[11.5px] leading-relaxed"
              />
            </div>

            <div>
              <p className="mb-1.5 text-[11px] font-medium uppercase tracking-[0.08em] text-mute">
                operatör talimatı (opsiyonel)
              </p>
              <TextArea
                rows={2}
                value={s.synthNote}
                onChange={(e) => s.setSynthNote(e.target.value)}
                placeholder="Örn: Bütçe kısıtını önceliklendir, riskleri maliyetle eşleştir…"
                className="text-[12.5px]"
              />
            </div>
          </div>
        </Panel>

        <Panel>
          <PanelHead accent="#c084fc" icon={<Gavel size={14} />} title="Hakem Koltuğu" />
          <div className="space-y-3 p-3">
            {referee ? (
              <div className="flex items-center gap-2.5 rounded-xl border border-line bg-[#111721] px-3 py-2.5">
                <Avatar label={referee.avatar} color={referee.color} size={32} ring={s.synthLive} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12.5px] font-semibold text-chalk">
                    {referee.name} <span className="font-normal text-mute">· {referee.roleTitle}</span>
                  </p>
                  <p className="truncate font-mono text-[10.5px] text-mute/80">
                    {provider?.name ?? "—"} / {referee.model}
                  </p>
                </div>
                <Chip color={s.synthLive ? "#38bdf8" : "#22c55e"}>
                  <StatusDot tone={s.synthLive ? "#38bdf8" : "#22c55e"} pulse={s.synthLive} />
                  {s.synthLive ? "yazıyor" : "hazır"}
                </Chip>
              </div>
            ) : (
              <p className="text-[12px] text-mute">Hakem koltuğu tanımlı değil.</p>
            )}

            <Button className="w-full" variant="primary" onClick={() => void s.runSynthesis()} disabled={s.synthLive || !s.synthSource.trim()}>
              <Target size={14} /> Nihai Raporu Üret
            </Button>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="danger" onClick={s.stopEverything} disabled={!s.synthLive}>
                <OctagonX size={13} /> Durdur
              </Button>
              <Button variant="ghost" onClick={() => void s.clearSynthesis()}>
                <Eraser size={13} /> Temizle
              </Button>
            </div>
          </div>
        </Panel>
      </div>

      <Panel className="flex min-w-0 flex-1 flex-col overflow-hidden" glow="#fbbf24">
        <PanelHead
          accent="#fbbf24"
          icon={<Target size={15} />}
          title="NİHAİ HAKEM RAPORU"
          right={
            <>
              {s.synthMeta.tokens ? (
                <Chip>
                  {s.synthMeta.tokens} tok · {(s.synthMeta.latencyMs / 1000).toFixed(1)} s
                </Chip>
              ) : null}
              <Button size="sm" variant="ghost" onClick={copyReport} disabled={!s.synthReport}>
                {copied ? <Check size={13} /> : <Copy size={13} />} Kopyala
              </Button>
              <Button
                size="sm"
                variant="ghost"
                disabled={!s.synthReport}
                onClick={() =>
                  downloadText(
                    `konsul-rapor-${new Date().toISOString().slice(0, 10)}.md`,
                    reportToMarkdown(s.synthReport, {
                      title: s.synthTopic?.title,
                      model: s.synthMeta.model,
                    }),
                  )
                }
              >
                <Download size={13} /> Markdown
              </Button>
            </>
          }
        />

        <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4">
          {!s.synthReport && !s.synthLive ? (
            <EmptyState
              icon={<Gavel size={34} />}
              title="Henüz rapor yok"
              hint="Soldaki panelden konsey tutanağını veya kör jüri yanıtlarını çekin, ardından 'Nihai Raporu Üret' deyin. Hakem modeli konsensüsü, anlaşmazlıkları ve operatör için eylem planını tek raporda birleştirir."
              action={
                <div className="mt-1 flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => void s.pullFromCouncil()}>
                    <Landmark size={13} /> Konseyden Çek
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => void s.pullFromJury()}>
                    <Scale size={13} /> Kör Jüriden Çek
                  </Button>
                </div>
              }
            />
          ) : showCards ? (
            <div className="space-y-3">
              {sections.map((section) => {
                const tone = TONE[section.tone];
                const Icon = tone.icon;
                return (
                  <section
                    key={section.key}
                    className="animate-fade-up overflow-hidden rounded-xl border"
                    style={{
                      borderColor: withAlpha(tone.color, 0.3),
                      background: `linear-gradient(180deg, ${withAlpha(tone.color, 0.07)}, rgba(17,22,29,0.6))`,
                    }}
                  >
                    <header className="flex items-center gap-2 border-b px-3.5 py-2.5" style={{ borderColor: withAlpha(tone.color, 0.18) }}>
                      <span
                        className="grid h-6 w-6 place-items-center rounded-md"
                        style={{ color: tone.color, background: withAlpha(tone.color, 0.14) }}
                      >
                        <Icon size={13} />
                      </span>
                      <h3 className={cn("text-[12.5px] font-semibold tracking-wide")} style={{ color: tone.color }}>
                        {section.title}
                      </h3>
                    </header>
                    <div className="px-3.5 py-3">
                      <Markdown>{section.body}</Markdown>
                    </div>
                  </section>
                );
              })}
            </div>
          ) : (
            <Markdown streaming={s.synthLive}>{s.synthReport}</Markdown>
          )}
        </div>
      </Panel>
    </div>
  );
}
