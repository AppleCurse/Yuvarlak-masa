"use client";

import { Check, Copy, TriangleAlert } from "lucide-react";
import { useState } from "react";
import { Markdown } from "./markdown";
import { Avatar, Chip } from "./ui";
import { clockTime, cn, copyText, withAlpha } from "@/lib/format";
import type { Message } from "@/lib/types";

export function MessageBubble({ message, compact = false }: { message: Message; compact?: boolean }) {
  const [copied, setCopied] = useState(false);
  const isHuman = message.speaker === "human";
  const accent = message.color || (isHuman ? "#f0f6fc" : "#c084fc");

  const onCopy = async () => {
    const ok = await copyText(message.content);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    }
  };

  if (message.speaker === "system") {
    return (
      <div className="flex items-center gap-2 py-1 pl-1 text-[11.5px] text-mute/80">
        <span className="h-px flex-1 bg-line" />
        <span className="font-mono uppercase tracking-[0.14em]">{message.content}</span>
        <span className="h-px flex-1 bg-line" />
      </div>
    );
  }

  return (
    <article
      className={cn("group animate-fade-up", compact ? "mb-2" : "mb-3")}
      style={{ opacity: 1 }}
    >
      <div
        className={cn(
          "relative overflow-hidden rounded-2xl border transition-colors",
          isHuman ? "border-line2 bg-[#171d29]" : "border-line bg-[#12171f]",
        )}
        style={!isHuman ? { borderLeft: `2px solid ${withAlpha(accent, 0.75)}` } : undefined}
      >
        <div className="flex items-start gap-3 px-3.5 pt-3">
          <Avatar label={message.avatar} color={accent} size={compact ? 28 : 34} ring={message.status === "streaming"} />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <span className="text-[13px] font-semibold" style={{ color: isHuman ? "#f0f6fc" : accent }}>
                {message.authorName}
              </span>
              {message.roleTitle ? (
                <span className="text-[11.5px] text-mute">· {message.roleTitle}</span>
              ) : null}
              {message.round > 0 ? <Chip>tur {message.round}</Chip> : null}
              {message.model ? <Chip color={withAlpha(accent, 0.9)}>{message.model}</Chip> : null}
              {message.providerName ? <Chip>{message.providerName}</Chip> : null}
              {message.status === "streaming" ? (
                <Chip color="#38bdf8">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#38bdf8]" />
                  yazıyor
                </Chip>
              ) : null}
              {message.status === "stopped" ? <Chip color="#fbbf24">durduruldu</Chip> : null}
              <span className="ml-auto flex items-center gap-2 font-mono text-[10.5px] text-mute/70">
                {message.tokens > 0 ? <span>{message.tokens} tok</span> : null}
                {message.latencyMs > 0 ? <span>{(message.latencyMs / 1000).toFixed(1)} s</span> : null}
                <span>{clockTime(message.createdAt)}</span>
                <button
                  type="button"
                  onClick={onCopy}
                  title="Mesajı kopyala"
                  className="focus-ring rounded p-1 text-mute/70 opacity-0 transition-opacity hover:text-chalk group-hover:opacity-100"
                >
                  {copied ? <Check size={13} /> : <Copy size={13} />}
                </button>
              </span>
            </div>

            <div className={cn("mt-2", compact ? "text-[12.5px]" : "")}>
              {message.content ? (
                <Markdown streaming={message.status === "streaming"}>{message.content}</Markdown>
              ) : message.status === "streaming" ? (
                <span className="text-[12.5px] text-mute">
                  bağlantı kuruldu<span className="caret" />
                </span>
              ) : null}
            </div>

            {message.error ? (
              <p className="mt-2 flex items-start gap-2 rounded-lg border border-[#ef4444]/35 bg-[#2a1215]/70 px-2.5 py-2 text-[12px] text-[#ffb4bb]">
                <TriangleAlert size={14} className="mt-[1px] shrink-0" />
                <span>{message.error}</span>
              </p>
            ) : null}
          </div>
        </div>
        <div className="h-2.5" />
      </div>
    </article>
  );
}
