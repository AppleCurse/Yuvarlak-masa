"use client";

import { OctagonX, Radio, Wifi, WifiOff } from "lucide-react";
import { useEffect } from "react";
import { CouncilRoom } from "./council-room";
import { JuryRoom } from "./jury-room";
import { RecordsRoom } from "./records-room";
import { SettingsRoom } from "./settings-room";
import { Sidebar } from "./sidebar";
import { SynthesisRoom } from "./synthesis-room";
import { Button, Chip } from "./ui";
import { useStation } from "@/lib/use-station";
import type { Bootstrap } from "@/lib/types";
import { cn, withAlpha } from "@/lib/format";

const HEADINGS: Record<string, { title: string; hint: string; accent: string }> = {
  council: {
    title: "Açık Konsey Odası",
    hint: "3 model + 1 operatör · sıralı veya otomatik paslaşmalı tartışma",
    accent: "#c084fc",
  },
  jury: {
    title: "Kör Jüri Odası",
    hint: "3 bağımsız yanıt, paralel üretim, yan yana karşılaştırma",
    accent: "#38bdf8",
  },
  synthesis: {
    title: "Sentez ve Hakem Odası",
    hint: "konsensüs · anlaşmazlık ve risk · operatör için eylem planı",
    accent: "#fbbf24",
  },
  records: { title: "Kayıtlar", hint: "tüm oturumların kalıcı arşivi", accent: "#34d399" },
  settings: { title: "Yapılandırma", hint: "model uçları, koltuklar, roller ve istasyon ayarları", accent: "#fb7185" },
};

export function Station({ initial }: { initial: Bootstrap | null }) {
  const s = useStation(initial);
  const busy = s.councilRunning || s.juryRunning || s.synthLive;
  const heading = HEADINGS[s.view];
  const demoMode = s.councilSeats.every((seat) => s.providerFor(seat)?.kind === "demo");

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const ctrl = event.ctrlKey || event.metaKey;
      if (!ctrl) return;
      const map: Record<string, typeof s.view> = {
        "1": "council",
        "2": "jury",
        "3": "synthesis",
        "4": "records",
        "5": "settings",
      };
      if (map[event.key]) {
        event.preventDefault();
        s.setView(map[event.key]);
      }
      if (event.key === ".") {
        event.preventDefault();
        s.stopEverything();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [s]);

  return (
    <div className="flex h-screen w-full overflow-hidden bg-ink text-chalk">
      <Sidebar s={s} />

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex shrink-0 items-center gap-3 border-b border-line bg-[#0b0f15]/85 px-4 py-2.5 backdrop-blur">
          <div className="min-w-0">
            <h1 className="truncate text-[14px] font-semibold tracking-wide text-chalk">{heading.title}</h1>
            <p className="truncate text-[11px] text-mute">{heading.hint}</p>
          </div>

          <div className="ml-auto flex items-center gap-2">
            {demoMode ? (
              <Chip color="#34d399">
                <Radio size={11} /> simülatör modu
              </Chip>
            ) : (
              <Chip color="#c084fc">
                <Wifi size={11} /> canlı uçlar
              </Chip>
            )}
            {s.offline ? (
              <Chip color="#fbbf24">
                <WifiOff size={11} /> kayıt dışı
              </Chip>
            ) : null}
            <Chip>
              <span className="font-mono">Ctrl+1/2/3</span> masa geçişi
            </Chip>
            {busy ? (
              <Button
                size="sm"
                variant="danger"
                onClick={s.stopEverything}
                className="border-[#ef4444]/50"
                style={{ background: withAlpha("#ef4444", 0.12) }}
              >
                <OctagonX size={13} /> Durdur
              </Button>
            ) : null}
            {demoMode ? (
              <Button size="sm" variant="ghost" onClick={() => s.setView("settings")}>
                uca bağlan
              </Button>
            ) : null}
          </div>
        </header>

        <main className="grid-etch min-h-0 flex-1 overflow-hidden">
          <div className={cn("h-full", s.view !== "council" && "hidden")}>
            <CouncilRoom s={s} />
          </div>
          <div className={cn("h-full", s.view !== "jury" && "hidden")}>
            <JuryRoom s={s} />
          </div>
          <div className={cn("h-full", s.view !== "synthesis" && "hidden")}>
            <SynthesisRoom s={s} />
          </div>
          {s.view === "records" ? <RecordsRoom s={s} /> : null}
          {s.view === "settings" ? <SettingsRoom s={s} /> : null}
        </main>
      </div>

      <div className="pointer-events-none fixed bottom-4 right-4 z-50 flex w-[340px] flex-col gap-2">
        {s.toasts.map((t) => {
          const tone =
            t.tone === "ok" ? "#22c55e" : t.tone === "bad" ? "#ef4444" : t.tone === "warn" ? "#fbbf24" : "#38bdf8";
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => s.dismissToast(t.id)}
              className="pointer-events-auto animate-fade-up rounded-xl border px-3 py-2.5 text-left text-[12.5px] leading-snug shadow-[0_18px_40px_-24px_rgba(0,0,0,0.9)] backdrop-blur"
              style={{ borderColor: withAlpha(tone, 0.4), background: `linear-gradient(180deg, ${withAlpha(tone, 0.14)}, rgba(13,17,23,0.96))`, color: "#e6edf3" }}
            >
              <span className="mr-2 inline-block h-2 w-2 rounded-full align-middle" style={{ background: tone }} />
              {t.text}
            </button>
          );
        })}
      </div>
    </div>
  );
}
