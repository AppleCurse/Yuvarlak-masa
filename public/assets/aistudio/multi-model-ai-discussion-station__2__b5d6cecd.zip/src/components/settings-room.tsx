"use client";

import {
  Activity,
  Armchair,
  Check,
  Download,
  Plug,
  Plus,
  RotateCcw,
  Save,
  SlidersHorizontal,
  Terminal,
  Trash2,
} from "lucide-react";
import { useEffect, useState } from "react";
import type { Station } from "@/lib/use-station";
import { cn, withAlpha } from "@/lib/format";
import type { Provider, Seat } from "@/lib/types";
import { Avatar, Button, Chip, Field, Panel, PanelHead, Select, TextInput, Toggle } from "./ui";

interface ProviderDraft extends Provider {
  modelsText: string;
}

const toDraft = (p: Provider): ProviderDraft => ({ ...p, modelsText: p.models.join(", ") });

export function SettingsRoom({ s }: { s: Station }) {
  const [drafts, setDrafts] = useState<ProviderDraft[]>(() => s.providers.map(toDraft));
  const [seatDrafts, setSeatDrafts] = useState<Seat[]>(() => s.seats.map((x) => ({ ...x })));
  const [adding, setAdding] = useState(false);
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [local, setLocal] = useState({
    rounds: s.settings.rounds,
    streamSpeedMs: s.settings.streamSpeedMs,
    operatorName: s.settings.operatorName,
    autoScroll: s.settings.autoScroll,
    showSystemLines: s.settings.showSystemLines,
  });

  useEffect(() => setDrafts(s.providers.map(toDraft)), [s.providers]);
  useEffect(() => setSeatDrafts(s.seats.map((x) => ({ ...x }))), [s.seats]);
  useEffect(
    () =>
      setLocal({
        rounds: s.settings.rounds,
        streamSpeedMs: s.settings.streamSpeedMs,
        operatorName: s.settings.operatorName,
        autoScroll: s.settings.autoScroll,
        showSystemLines: s.settings.showSystemLines,
      }),
    [s.settings],
  );

  const patchDraft = (id: string, patch: Partial<ProviderDraft>) =>
    setDrafts((prev) => prev.map((d) => (d.id === id ? { ...d, ...patch } : d)));

  const patchSeat = (id: string, patch: Partial<Seat>) =>
    setSeatDrafts((prev) => prev.map((d) => (d.id === id ? { ...d, ...patch } : d)));

  const saveProviderDraft = async (draft: ProviderDraft) => {
    const models = draft.modelsText
      .split(",")
      .map((m) => m.trim())
      .filter(Boolean);
    const { modelsText: _ignored, ...payload } = { ...draft, models };
    await s.saveProvider(payload);
  };

  return (
    <div className="h-full min-h-0 overflow-y-auto p-4">
      <div className="mx-auto grid max-w-[1500px] grid-cols-1 gap-4 xl:grid-cols-2">
        <Panel className="xl:col-span-2" glow="#fb7185">
          <PanelHead
            accent="#fb7185"
            icon={<Plug size={15} />}
            title="MODEL UÇLARI · OpenAI UYUMLU SAĞLAYICILAR"
            right={
              <>
                <Button size="sm" variant="ghost" onClick={() => s.setView("council")}>
                  Masaya dön
                </Button>
                <Button size="sm" variant="outline" onClick={() => setAdding((v) => !v)}>
                  <Plus size={13} /> Yeni uç
                </Button>
              </>
            }
          />
          <div className="grid grid-cols-1 gap-3 p-3 lg:grid-cols-2">
            {adding ? (
              <NewProviderForm
                onCancel={() => setAdding(false)}
                onCreate={async (payload) => {
                  await s.saveProvider(payload);
                  setAdding(false);
                }}
              />
            ) : null}

            {drafts.map((draft) => {
              const probe = s.probes[draft.id];
              const used = s.seats.filter((seat) => seat.providerId === draft.id).length;
              return (
                <div
                  key={draft.id}
                  className="rounded-xl border border-line bg-[#111721] p-3"
                  style={{ borderColor: withAlpha(draft.color, 0.28) }}
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="grid h-8 w-8 place-items-center rounded-lg border"
                      style={{
                        color: draft.color,
                        borderColor: withAlpha(draft.color, 0.4),
                        background: withAlpha(draft.color, 0.1),
                      }}
                    >
                      <Plug size={15} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-semibold text-chalk">{draft.name}</p>
                      <p className="truncate font-mono text-[10.5px] text-mute">{draft.baseUrl || "base url yok"}</p>
                    </div>
                    <Chip color={probe?.status === "ok" ? "#22c55e" : probe?.status === "bad" ? "#ef4444" : undefined}>
                      {draft.kind === "demo"
                        ? "simülatör"
                        : probe
                          ? probe.label
                          : "test edilmedi"}
                    </Chip>
                  </div>

                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <Field label="ad">
                      <TextInput value={draft.name} onChange={(e) => patchDraft(draft.id, { name: e.target.value })} />
                    </Field>
                    <Field label="tür">
                      <Select
                        value={draft.kind}
                        onChange={(e) =>
                          patchDraft(draft.id, { kind: e.target.value as Provider["kind"] })
                        }
                      >
                        <option value="openai">OpenAI uyumlu</option>
                        <option value="demo">Yerel simülatör</option>
                      </Select>
                    </Field>
                    <Field label="base url" className="col-span-2">
                      <TextInput
                        value={draft.baseUrl}
                        spellCheck={false}
                        onChange={(e) => patchDraft(draft.id, { baseUrl: e.target.value })}
                        placeholder="http://127.0.0.1:20128/v1"
                        className="font-mono text-[12px]"
                      />
                    </Field>
                    <Field label="api key" className="col-span-2">
                      <div className="flex gap-2">
                        <TextInput
                          type={showKeys[draft.id] ? "text" : "password"}
                          value={draft.apiKey}
                          spellCheck={false}
                          onChange={(e) => patchDraft(draft.id, { apiKey: e.target.value })}
                          placeholder="boş bırakılabilir (yerel uçlar)"
                          className="font-mono text-[12px]"
                        />
                        <Button variant="ghost" size="sm" onClick={() => setShowKeys((p) => ({ ...p, [draft.id]: !p[draft.id] }))}>
                          {showKeys[draft.id] ? "gizle" : "göster"}
                        </Button>
                      </div>
                    </Field>
                    <Field label="modeller (virgülle)" className="col-span-2">
                      <TextInput
                        value={draft.modelsText}
                        spellCheck={false}
                        onChange={(e) => patchDraft(draft.id, { modelsText: e.target.value })}
                        className="font-mono text-[11.5px]"
                      />
                    </Field>
                    <Field label="vurgu rengi">
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={draft.color}
                          onChange={(e) => patchDraft(draft.id, { color: e.target.value })}
                          className="h-9 w-12 cursor-pointer rounded-lg border border-line2 bg-[#0f141d]"
                        />
                        <TextInput
                          value={draft.color}
                          onChange={(e) => patchDraft(draft.id, { color: e.target.value })}
                          className="font-mono text-[12px]"
                        />
                      </div>
                    </Field>
                    <div className="flex items-end justify-end gap-3 pb-1">
                      <Toggle
                        checked={draft.enabled}
                        onChange={(v) => patchDraft(draft.id, { enabled: v })}
                        label="listede görünsün"
                      />
                    </div>
                  </div>

                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <Button size="sm" variant="primary" onClick={() => void saveProviderDraft(draft)}>
                      <Save size={12} /> Kaydet
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => void s.probeProvider(draft.id)} disabled={draft.kind === "demo"}>
                      <Activity size={12} /> Test Et
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => void s.moveSeatsToProvider(draft.id)}
                      title="Tüm koltukları bu uca bağla"
                    >
                      <Armchair size={12} /> Koltukları bağla {used ? `(${used})` : ""}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="ml-auto"
                      disabled={draft.id === "prov_demo"}
                      onClick={() => void s.removeProvider(draft.id)}
                    >
                      <Trash2 size={12} className="text-[#fb7185]" />
                    </Button>
                  </div>
                  {draft.note ? <p className="mt-2 text-[11px] leading-relaxed text-mute/80">{draft.note}</p> : null}
                </div>
              );
            })}
          </div>
        </Panel>

        <Panel glow="#c084fc">
          <PanelHead
            accent="#c084fc"
            icon={<Armchair size={15} />}
            title="KOLTUKLAR · ROLLER VE SİSTEM İSTEMLERİ"
            right={
              <Button size="sm" variant="primary" onClick={() => void s.saveSeats(seatDrafts)}>
                <Save size={12} /> Koltukları kaydet
              </Button>
            }
          />
          <div className="space-y-3 p-3">
            {seatDrafts.map((seat) => {
              const provider = s.providers.find((p) => p.id === seat.providerId);
              return (
                <div key={seat.id} className="rounded-xl border border-line bg-[#111721] p-3" style={{ borderColor: withAlpha(seat.color, 0.25) }}>
                  <div className="flex items-center gap-2.5">
                    <Avatar label={seat.avatar} color={seat.color} size={30} />
                    <p className="text-[12.5px] font-semibold text-chalk">
                      {seat.name} <span className="font-normal text-mute">· {seat.roleTitle}</span>
                    </p>
                    <Chip className="ml-auto">{seat.slot}</Chip>
                    <Toggle checked={seat.active} onChange={(v) => patchSeat(seat.id, { active: v })} label="aktif" />
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <Field label="görünen ad">
                      <TextInput value={seat.name} onChange={(e) => patchSeat(seat.id, { name: e.target.value })} />
                    </Field>
                    <Field label="rol">
                      <TextInput value={seat.roleTitle} onChange={(e) => patchSeat(seat.id, { roleTitle: e.target.value })} />
                    </Field>
                    <Field label="sağlayıcı">
                      <Select value={seat.providerId} onChange={(e) => patchSeat(seat.id, { providerId: e.target.value })}>
                        {s.providers.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name}
                          </option>
                        ))}
                      </Select>
                    </Field>
                    <Field label="model id">
                      <Select value={seat.model} onChange={(e) => patchSeat(seat.id, { model: e.target.value })}>
                        {(provider?.models ?? []).includes(seat.model) || !seat.model ? null : (
                          <option value={seat.model}>{seat.model}</option>
                        )}
                        {(provider?.models ?? []).map((m) => (
                          <option key={m} value={m}>
                            {m}
                          </option>
                        ))}
                      </Select>
                    </Field>
                    <Field label={`sıcaklık · ${seat.temperature.toFixed(2)}`}>
                      <input
                        type="range"
                        min={0}
                        max={1.6}
                        step={0.05}
                        value={seat.temperature}
                        onChange={(e) => patchSeat(seat.id, { temperature: Number(e.target.value) })}
                        className="focus-ring h-9 w-full cursor-pointer accent-[#c084fc]"
                      />
                    </Field>
                    <Field label="max token">
                      <TextInput
                        type="number"
                        min={128}
                        max={16000}
                        step={128}
                        value={seat.maxTokens}
                        onChange={(e) => patchSeat(seat.id, { maxTokens: Number(e.target.value) || 512 })}
                      />
                    </Field>
                    <Field label="rol/sistem istemi" className="col-span-2">
                      <textarea
                        rows={4}
                        value={seat.systemPrompt}
                        onChange={(e) => patchSeat(seat.id, { systemPrompt: e.target.value })}
                        className="focus-ring w-full resize-y rounded-lg border border-line2 bg-[#0f141d] px-3 py-2 text-[12px] leading-relaxed text-chalk"
                      />
                    </Field>
                  </div>
                </div>
              );
            })}
          </div>
        </Panel>

        <div className="space-y-4">
          <Panel glow="#38bdf8">
            <PanelHead
              accent="#38bdf8"
              icon={<SlidersHorizontal size={15} />}
              title="İSTASYON AYARLARI"
              right={
                <Button
                  size="sm"
                  variant="primary"
                  onClick={() =>
                    void s.saveSettings({
                      rounds: local.rounds,
                      streamSpeedMs: local.streamSpeedMs,
                      operatorName: local.operatorName,
                      autoScroll: local.autoScroll,
                      showSystemLines: local.showSystemLines,
                    })
                  }
                >
                  <Save size={12} /> Kaydet
                </Button>
              }
            />
            <div className="grid grid-cols-2 gap-3 p-3">
              <Field label="varsayılan tur sayısı">
                <TextInput
                  type="number"
                  min={1}
                  max={8}
                  value={local.rounds}
                  onChange={(e) => setLocal((p) => ({ ...p, rounds: Number(e.target.value) || 1 }))}
                />
              </Field>
              <Field label="akış hızı (ms/kelime)" hint="simülatör">
                <TextInput
                  type="number"
                  min={0}
                  max={120}
                  value={local.streamSpeedMs}
                  onChange={(e) => setLocal((p) => ({ ...p, streamSpeedMs: Number(e.target.value) || 0 }))}
                />
              </Field>
              <Field label="operatör adı" className="col-span-2">
                <TextInput
                  value={local.operatorName}
                  onChange={(e) => setLocal((p) => ({ ...p, operatorName: e.target.value }))}
                />
              </Field>
              <div className="col-span-2 flex flex-wrap gap-5 rounded-lg border border-line bg-[#0f141d] px-3 py-2.5">
                <Toggle
                  checked={local.autoScroll}
                  onChange={(v) => setLocal((p) => ({ ...p, autoScroll: v }))}
                  label="otomatik kaydırma"
                />
                <Toggle
                  checked={local.showSystemLines}
                  onChange={(v) => setLocal((p) => ({ ...p, showSystemLines: v }))}
                  label="sistem satırlarını göster"
                />
              </div>
              <Button variant="outline" className="col-span-2" onClick={() => void s.resetDefaults()}>
                <RotateCcw size={13} /> Varsayılan yapılandırmayı geri yükle
              </Button>
            </div>
          </Panel>

          <Panel glow="#34d399">
            <PanelHead accent="#34d399" icon={<Terminal size={15} />} title="MASAÜSTÜ PYTHON SÜRÜMÜ" />
            <div className="space-y-3 p-3 text-[12.5px] leading-relaxed text-mute">
              <p>
                Bu istasyonun bağımsız Python sürümü (FastAPI + Uvicorn + httpx) tek dosyalık arka uç ve tek
                sayfalık arayüz olarak paketlenmiştir. npm, webpack veya Docker gerektirmez.
              </p>
              <pre className="overflow-x-auto rounded-lg border border-line bg-[#0b0f16] px-3 py-2.5 font-mono text-[11.5px] text-[#a5f3d0]">
{`pip install fastapi uvicorn httpx
python app.py   # → http://127.0.0.1:8888`}
              </pre>
              <div className="flex flex-wrap gap-2">
                <a href="/desktop/app.py" download className={cn("inline-flex")}>
                  <Button variant="outline" size="sm">
                    <Download size={12} /> app.py
                  </Button>
                </a>
                <a href="/desktop/index.html" download className={cn("inline-flex")}>
                  <Button variant="outline" size="sm">
                    <Download size={12} /> index.html
                  </Button>
                </a>
              </div>
              <p className="text-[11.5px] text-mute/70">
                Python sürümü de aynı uçları kullanır: 9Router (127.0.0.1:20128), Ollama (11434), LM Studio
                (1234) ve bulut API&apos;leri.
              </p>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function NewProviderForm({
  onCreate,
  onCancel,
}: {
  onCreate: (payload: Partial<Provider>) => Promise<void>;
  onCancel: () => void;
}) {
  const [form, setForm] = useState({
    name: "",
    kind: "openai" as Provider["kind"],
    baseUrl: "http://127.0.0.1:20128/v1",
    apiKey: "",
    color: "#22c55e",
    modelsText: "",
    note: "",
  });

  return (
    <div className="rounded-xl border border-[#34d399]/35 bg-[#0f1a15] p-3">
      <p className="mb-2 flex items-center gap-2 text-[12.5px] font-semibold text-[#6ee7b7]">
        <Plus size={13} /> Yeni model ucu
      </p>
      <div className="grid grid-cols-2 gap-2">
        <Field label="ad">
          <TextInput value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} placeholder="Örn: DeepSeek" />
        </Field>
        <Field label="base url">
          <TextInput value={form.baseUrl} onChange={(e) => setForm((p) => ({ ...p, baseUrl: e.target.value }))} className="font-mono text-[12px]" />
        </Field>
        <Field label="api key">
          <TextInput value={form.apiKey} onChange={(e) => setForm((p) => ({ ...p, apiKey: e.target.value }))} className="font-mono text-[12px]" />
        </Field>
        <Field label="modeller (virgülle)">
          <TextInput value={form.modelsText} onChange={(e) => setForm((p) => ({ ...p, modelsText: e.target.value }))} className="font-mono text-[12px]" />
        </Field>
      </div>
      <div className="mt-3 flex gap-2">
        <Button
          size="sm"
          variant="success"
          onClick={() =>
            void onCreate({
              name: form.name || "Yeni uç",
              kind: form.kind,
              baseUrl: form.baseUrl,
              apiKey: form.apiKey,
              color: form.color,
              note: form.note,
              models: form.modelsText
                .split(",")
                .map((m) => m.trim())
                .filter(Boolean),
            })
          }
        >
          <Check size={12} /> Ekle
        </Button>
        <Button size="sm" variant="ghost" onClick={onCancel}>
          Vazgeç
        </Button>
      </div>
    </div>
  );
}
