"use client";

import { ArrowRight, Check, Copy, Eraser, EyeOff, OctagonX, Scale, Zap } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { Station } from "@/lib/use-station";
import { cn, copyText, withAlpha } from "@/lib/format";
import { Markdown } from "./markdown";
import { Avatar, Button, Chip, Panel, Select, StatusDot } from "./ui";

export function JuryRoom({ s }: { s: Station }) {
  const [question, setQuestion] = useState(s.juryQuestion);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const cols = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => setQuestion(s.juryQuestion), [s.juryQuestion]);

  useEffect(() => {
    for (const el of cols.current) {
      if (el) el.scrollTop = el.scrollHeight;
    }
  }, [s.juryColumns]);

  const anyRunning = s.juryColumns.some((c) => c.status === "streaming") || s.juryRunning;

  const start = async () => {
    const q = question.trim();
    if (!q) {
      s.toast("Kör jüri için bir soru yazın", "warn");
      return;
    }
    await s.runJury(q);
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-4 p-4">
      <Panel glow="#38bdf8">
        <div className="flex flex-wrap items-center gap-3 px-4 py-3">
          <span className="grid h-8 w-8 place-items-center rounded-lg border border-[#38bdf8]/35 bg-[#38bdf8]/10 text-[#38bdf8]">
            <Scale size={16} />
          </span>
          <div className="min-w-0">
            <h2 className="text-[13.5px] font-semibold tracking-wide text-chalk">MASA 2 · KÖR JÜRİ ODASI</h2>
            <p className="flex items-center gap-1.5 text-[11px] text-mute">
              <EyeOff size={11} /> Modeller birbirini görmez ve duymaz — sıfır halüsinasyon zinciri
            </p>
          </div>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <Chip color={anyRunning ? "#38bdf8" : undefined}>
              <StatusDot tone={anyRunning ? "#38bdf8" : "#5b6675"} pulse={anyRunning} />
              {anyRunning ? "paralel üretim" : "hazır"}
            </Chip>
            <Button variant="primary" onClick={() => void start()} disabled={anyRunning || !question.trim()}>
              <Zap size={14} /> Paralel Karşılaştır
            </Button>
            <Button variant="danger" onClick={s.stopEverything} disabled={!anyRunning}>
              <OctagonX size={14} /> Durdur
            </Button>
            <Button variant="ghost" onClick={() => void s.pullFromJury()} disabled={!s.juryColumns.some((c) => c.message?.content)}>
              <ArrowRight size={13} /> Senteze aktar
            </Button>
            <Button variant="ghost" onClick={() => void s.clearJury()}>
              <Eraser size={13} /> Temizle
            </Button>
          </div>
        </div>
        <div className="border-t border-line px-4 py-3">
          <textarea
            value={question}
            onChange={(e) => {
              setQuestion(e.target.value);
              s.setJuryQuestion(e.target.value);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) void start();
            }}
            rows={2}
            placeholder="Aynı soruyu üç modele birden sorun — her biri bağımsız yanıt üretir… (Ctrl + Enter)"
            className="focus-ring w-full resize-y rounded-xl border border-line2 bg-[#0b1017] px-3.5 py-2.5 text-[13.5px] leading-relaxed text-chalk placeholder:text-mute/60"
          />
        </div>
      </Panel>

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 lg:grid-cols-3">
        {s.juryColumns.map((column, index) => {
          const seat = s.seats.find((x) => x.id === column.seatId) ?? s.councilSeats[index] ?? null;
          const provider = seat ? s.providerFor(seat) : null;
          const accent = seat?.color ?? "#38bdf8";
          const message = column.message;
          const statusTone =
            column.status === "streaming"
              ? "#38bdf8"
              : column.status === "error"
                ? "#ef4444"
                : column.status === "done"
                  ? "#22c55e"
                  : column.status === "stopped"
                    ? "#fbbf24"
                    : "#5b6675";
          const statusLabel =
            column.status === "streaming"
              ? "üretiyor"
              : column.status === "error"
                ? "hata"
                : column.status === "done"
                  ? "tamam"
                  : column.status === "stopped"
                    ? "durduruldu"
                    : "beklemede";

          return (
            <Panel key={column.key} className="flex min-h-0 flex-col overflow-hidden" glow={accent}>
              <div className="border-b border-line px-3 py-2.5">
                <div className="flex items-center gap-2.5">
                  <Avatar label={seat?.avatar ?? String(index + 1)} color={accent} size={32} ring={column.status === "streaming"} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-semibold text-chalk">
                      Jüri {index + 1} · {seat?.name ?? "—"}
                    </p>
                    <p className="truncate text-[10.5px] text-mute">{seat?.roleTitle}</p>
                  </div>
                  <Chip color={statusTone}>
                    <StatusDot tone={statusTone} pulse={column.status === "streaming"} />
                    {statusLabel}
                  </Chip>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <Select
                    value={column.seatId}
                    onChange={(e) => {
                      const nextSeat = s.seats.find((x) => x.id === e.target.value);
                      s.setColumnSeat(column.key, e.target.value);
                      if (nextSeat) s.setColumnModel(column.key, nextSeat.model);
                    }}
                    className="py-1.5 text-[11.5px]"
                  >
                    {s.seats.map((option) => (
                      <option key={option.id} value={option.id}>
                        {option.name} · {option.roleTitle}
                      </option>
                    ))}
                  </Select>
                  <Select
                    value={column.model}
                    onChange={(e) => s.setColumnModel(column.key, e.target.value)}
                    className="py-1.5 font-mono text-[11px]"
                  >
                    {(provider?.models ?? []).includes(column.model) || !column.model ? null : (
                      <option value={column.model}>{column.model}</option>
                    )}
                    {(provider?.models ?? []).map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </Select>
                </div>
                <p className="mt-1.5 truncate font-mono text-[10px] text-mute/70">
                  {provider?.name ?? "—"} · {provider?.kind === "demo" ? "simülatör" : provider?.baseUrl}
                  {column.tokens ? ` · ${column.tokens} tok · ${(column.latencyMs / 1000).toFixed(1)} s` : ""}
                </p>
              </div>

              <div
                ref={(el) => {
                  cols.current[index] = el;
                }}
                className="min-h-0 flex-1 overflow-y-auto px-3.5 py-3"
                style={{ background: withAlpha(accent, 0.03) }}
              >
                {message?.content ? (
                  <Markdown streaming={column.status === "streaming"}>{message.content}</Markdown>
                ) : column.status === "streaming" ? (
                  <div className="space-y-2">
                    {[92, 78, 85, 60].map((w, i) => (
                      <span
                        key={i}
                        className="block h-2.5 animate-pulse rounded-full bg-[#1c2431]"
                        style={{ width: `${w}%`, animationDelay: `${i * 120}ms` }}
                      />
                    ))}
                  </div>
                ) : (
                  <p className="py-8 text-center text-[12px] leading-relaxed text-mute/70">
                    Soruyu yazıp <span className="text-chalk">Paralel Karşılaştır</span>&apos;a basın.
                    <br />
                    Bu sütun yalnızca kendi yanıtını görür.
                  </p>
                )}
                {column.error ? (
                  <p className={cn("mt-3 rounded-lg border border-[#ef4444]/35 bg-[#2a1215]/70 px-2.5 py-2 text-[11.5px] text-[#ffb4bb]")}>
                    {column.error}
                  </p>
                ) : null}
              </div>

              <div className="flex items-center gap-2 border-t border-line px-3 py-2">
                <Button
                  size="sm"
                  variant="ghost"
                  disabled={!message?.content}
                  onClick={async () => {
                    const ok = await copyText(message?.content ?? "");
                    if (ok) {
                      setCopiedKey(column.key);
                      setTimeout(() => setCopiedKey(null), 1400);
                    }
                  }}
                >
                  {copiedKey === column.key ? <Check size={12} /> : <Copy size={12} />} Kopyala
                </Button>
                <span className="ml-auto font-mono text-[10px] text-mute/60">
                  {message?.content ? `${message.content.length} karakter` : "—"}
                </span>
              </div>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}
