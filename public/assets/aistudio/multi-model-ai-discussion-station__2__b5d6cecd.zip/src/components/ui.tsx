"use client";

import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { cn, withAlpha } from "@/lib/format";

type Variant = "primary" | "ghost" | "outline" | "danger" | "success";

const VARIANTS: Record<Variant, string> = {
  primary:
    "bg-gradient-to-b from-[#a855f7] to-[#7c3aed] text-white border border-[#a855f7]/40 shadow-[0_6px_20px_-8px_rgba(168,85,247,0.9)] hover:from-[#b57afc] hover:to-[#8b46ef]",
  success:
    "bg-gradient-to-b from-[#22c55e] to-[#15803d] text-[#04140a] border border-[#22c55e]/40 hover:brightness-110 font-semibold",
  danger:
    "bg-[#2a1215] text-[#ff9aa2] border border-[#ef4444]/40 hover:bg-[#3a161b] hover:text-[#ffc2c7]",
  outline:
    "bg-[#151b25] text-chalk border border-line2 hover:border-[#4a5568] hover:bg-[#1b2230]",
  ghost: "bg-transparent text-mute border border-transparent hover:text-chalk hover:bg-[#161d28]",
};

export function Button({
  variant = "outline",
  size = "md",
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: "sm" | "md" | "lg" }) {
  return (
    <button
      {...rest}
      className={cn(
        "focus-ring inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-all duration-150 active:translate-y-[1px] disabled:cursor-not-allowed disabled:opacity-45 disabled:active:translate-y-0",
        size === "sm" ? "px-2.5 py-1.5 text-[12px]" : size === "lg" ? "px-5 py-3 text-[15px]" : "px-3.5 py-2 text-[13px]",
        VARIANTS[variant],
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Panel({
  className,
  children,
  glow,
}: {
  className?: string;
  children: ReactNode;
  glow?: string;
}) {
  return (
    <section
      className={cn(
        "relative rounded-2xl border border-line bg-card/85 backdrop-blur-[2px]",
        className,
      )}
      style={glow ? { boxShadow: `0 0 0 1px ${withAlpha(glow, 0.12)}, 0 18px 50px -34px ${glow}` } : undefined}
    >
      {children}
    </section>
  );
}

export function PanelHead({
  title,
  icon,
  right,
  accent,
}: {
  title: ReactNode;
  icon?: ReactNode;
  right?: ReactNode;
  accent?: string;
}) {
  return (
    <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
      <div className="flex min-w-0 items-center gap-2.5">
        {icon ? (
          <span
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border"
            style={{
              color: accent ?? "#c084fc",
              borderColor: withAlpha(accent ?? "#c084fc", 0.3),
              background: withAlpha(accent ?? "#c084fc", 0.1),
            }}
          >
            {icon}
          </span>
        ) : null}
        <h2 className="truncate text-[13.5px] font-semibold tracking-wide text-chalk">{title}</h2>
      </div>
      {right ? <div className="flex shrink-0 items-center gap-2">{right}</div> : null}
    </header>
  );
}

export function Avatar({
  label,
  color,
  size = 34,
  ring = false,
}: {
  label: string;
  color: string;
  size?: number;
  ring?: boolean;
}) {
  return (
    <span
      className={cn(
        "grid shrink-0 place-items-center rounded-xl border font-mono font-semibold",
        ring && "animate-pulse-ring",
      )}
      style={{
        width: size,
        height: size,
        fontSize: size * 0.42,
        color,
        borderColor: withAlpha(color, 0.45),
        background: `linear-gradient(150deg, ${withAlpha(color, 0.24)}, ${withAlpha(color, 0.06)})`,
      }}
    >
      {label}
    </span>
  );
}

export function Chip({
  children,
  color,
  className,
}: {
  children: ReactNode;
  color?: string;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-md border px-2 py-[3px] text-[11px] font-medium leading-none",
        !color && "border-line2 bg-[#151b25] text-mute",
        className,
      )}
      style={
        color
          ? { color, borderColor: withAlpha(color, 0.35), background: withAlpha(color, 0.1) }
          : undefined
      }
    >
      {children}
    </span>
  );
}

export function StatusDot({ tone, pulse = false }: { tone: string; pulse?: boolean }) {
  return (
    <span className="relative inline-flex h-2 w-2">
      <span className="h-2 w-2 rounded-full" style={{ background: tone }} />
      {pulse ? (
        <span
          className="absolute inset-0 rounded-full opacity-70"
          style={{ background: tone, animation: "pulse-ring 1.6s ease-out infinite" }}
        />
      ) : null}
    </span>
  );
}

export function Field({
  label,
  hint,
  children,
  className,
}: {
  label: ReactNode;
  hint?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1.5 flex items-center justify-between gap-2 text-[11px] font-medium uppercase tracking-[0.08em] text-mute">
        {label}
        {hint ? <span className="normal-case tracking-normal text-[11px] text-mute/70">{hint}</span> : null}
      </span>
      {children}
    </label>
  );
}

const CONTROL =
  "focus-ring w-full rounded-lg border border-line2 bg-[#0f141d] px-3 py-2 text-[13px] text-chalk placeholder:text-mute/60 transition-colors hover:border-[#3d4a5c]";

export function TextInput({ className, ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...rest} className={cn(CONTROL, className)} />;
}

export function TextArea({ className, ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...rest} className={cn(CONTROL, "resize-y leading-relaxed", className)} />;
}

export function Select({ className, children, ...rest }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select {...rest} className={cn(CONTROL, "cursor-pointer appearance-none pr-8", className)}>
      {children}
    </select>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="focus-ring inline-flex items-center gap-2 text-[12.5px] text-mute hover:text-chalk"
    >
      <span
        className={cn(
          "relative h-[18px] w-[32px] rounded-full border transition-colors",
          checked ? "border-[#a855f7]/60 bg-[#7c3aed]/45" : "border-line2 bg-[#151b25]",
        )}
      >
        <span
          className={cn(
            "absolute top-[2px] h-[12px] w-[12px] rounded-full transition-all",
            checked ? "left-[16px] bg-[#d8b4fe]" : "left-[2px] bg-[#5b6675]",
          )}
        />
      </span>
      {label}
    </button>
  );
}

export function EmptyState({
  icon,
  title,
  hint,
  action,
}: {
  icon?: ReactNode;
  title: string;
  hint?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-3 px-6 py-12 text-center">
      {icon ? <div className="text-mute/50">{icon}</div> : null}
      <p className="text-[13.5px] font-medium text-mute">{title}</p>
      {hint ? <p className="max-w-md text-[12.5px] leading-relaxed text-mute/70">{hint}</p> : null}
      {action}
    </div>
  );
}

export function Meter({ value, color }: { value: number; color: string }) {
  return (
    <span className="h-1 w-16 overflow-hidden rounded-full bg-[#1b2230]">
      <span
        className="block h-full rounded-full transition-all duration-300"
        style={{ width: `${Math.min(100, Math.max(3, value))}%`, background: color }}
      />
    </span>
  );
}
