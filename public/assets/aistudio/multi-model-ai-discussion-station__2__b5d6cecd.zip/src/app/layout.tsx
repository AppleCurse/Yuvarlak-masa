import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "KONSÜL AI · Çoklu Model Konsey ve Kör Jüri İstasyonu",
  description:
    "Açık Konsey, Kör Jüri ve Sentez/Hakem odaları: çoklu yapay zekâ modellerini tartıştıran, karşılaştıran ve nihai karara bağlayan yerel istasyon.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-ink text-chalk antialiased">{children}</body>
    </html>
  );
}
