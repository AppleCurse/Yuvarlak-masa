import { db } from "@/db";
import { eq } from "drizzle-orm";
import { settings } from "@/db/schema";
import { DEFAULT_SETTINGS } from "@/lib/defaults";
import { ensureSeed, getSettings } from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  return Response.json({ settings: await getSettings() });
}

export async function PUT(req: Request) {
  await ensureSeed();
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const allowed = Object.keys(DEFAULT_SETTINGS);

  for (const key of allowed) {
    if (key in body) {
      const existing = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
      if (existing.length) {
        await db
          .update(settings)
          .set({ value: body[key], updatedAt: new Date() })
          .where(eq(settings.key, key));
      } else {
        await db.insert(settings).values({ key, value: body[key] });
      }
    }
  }

  return Response.json({ settings: await getSettings() });
}
