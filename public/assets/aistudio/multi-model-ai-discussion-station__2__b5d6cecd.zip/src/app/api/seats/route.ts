import { db } from "@/db";
import { asc, eq } from "drizzle-orm";
import { seats } from "@/db/schema";
import { ensureSeed, mapSeat } from "@/lib/store";
import { uid } from "@/lib/defaults";
import type { Seat } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const rows = await db.select().from(seats).orderBy(asc(seats.sortIndex));
  return Response.json({ seats: rows.map(mapSeat) });
}

function toRow(seat: Partial<Seat> & { id?: string }, index: number) {
  return {
    id: seat.id || uid("seat"),
    slot: seat.slot || "custom",
    name: seat.name || "Model",
    roleTitle: seat.roleTitle || "Üye",
    avatar: seat.avatar || (seat.name || "M").charAt(0).toUpperCase(),
    systemPrompt: seat.systemPrompt ?? "",
    providerId: seat.providerId || "prov_demo",
    model: seat.model || "",
    color: seat.color || "#8b5cf6",
    temperature: typeof seat.temperature === "number" ? seat.temperature : 0.7,
    maxTokens: typeof seat.maxTokens === "number" ? seat.maxTokens : 900,
    active: seat.active ?? true,
    sortIndex: typeof seat.sortIndex === "number" ? seat.sortIndex : index,
  };
}

/** Bulk save: existing ids are updated, new ones inserted. */
export async function PUT(req: Request) {
  await ensureSeed();
  const body = (await req.json().catch(() => ({}))) as { seats?: Partial<Seat>[] };
  const incoming = Array.isArray(body.seats) ? body.seats : [];
  if (!incoming.length) return Response.json({ error: "Koltuk listesi boş" }, { status: 400 });

  for (const [index, seat] of incoming.entries()) {
    const row = toRow(seat, index);
    const exists = seat.id
      ? await db.select({ id: seats.id }).from(seats).where(eq(seats.id, seat.id)).limit(1)
      : [];
    if (exists.length) {
      await db.update(seats).set(row).where(eq(seats.id, row.id));
    } else {
      await db.insert(seats).values(row);
    }
  }

  const rows = await db.select().from(seats).orderBy(asc(seats.sortIndex));
  return Response.json({ seats: rows.map(mapSeat) });
}

export async function DELETE(req: Request) {
  await ensureSeed();
  const { id } = (await req.json().catch(() => ({}))) as { id?: string };
  if (!id) return Response.json({ error: "id gerekli" }, { status: 400 });
  const rows = await db.select().from(seats).where(eq(seats.id, id));
  if (!rows.length) return Response.json({ error: "Koltuk bulunamadı" }, { status: 404 });
  if (!["custom"].includes(rows[0].slot))
    return Response.json({ error: "Çekirdek koltuk silinemez, pasife alabilirsiniz" }, { status: 400 });
  await db.delete(seats).where(eq(seats.id, id));
  return Response.json({ ok: true, id });
}
