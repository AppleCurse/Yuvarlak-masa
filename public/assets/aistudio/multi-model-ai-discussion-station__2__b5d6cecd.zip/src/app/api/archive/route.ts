import { db } from "@/db";
import { desc, eq, sql } from "drizzle-orm";
import { messages, topics } from "@/db/schema";
import { ensureSeed } from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Archive listing with per-topic message counters for the records room. */
export async function GET() {
  await ensureSeed();
  const rows = await db
    .select({
      id: topics.id,
      room: topics.room,
      title: topics.title,
      question: topics.question,
      status: topics.status,
      pinned: topics.pinned,
      createdAt: topics.createdAt,
      updatedAt: topics.updatedAt,
      count: sql<number>`count(${messages.id})::int`,
    })
    .from(topics)
    .leftJoin(messages, eq(messages.topicId, topics.id))
    .groupBy(topics.id)
    .orderBy(desc(topics.updatedAt))
    .limit(200);

  return Response.json({
    entries: rows.map((r) => ({
      id: r.id,
      room: r.room,
      title: r.title,
      question: r.question,
      status: r.status,
      pinned: r.pinned,
      count: r.count,
      createdAt: r.createdAt.toISOString(),
      updatedAt: r.updatedAt.toISOString(),
    })),
  });
}
