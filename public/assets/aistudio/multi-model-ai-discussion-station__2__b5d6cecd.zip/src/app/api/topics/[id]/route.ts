import { db } from "@/db";
import { eq } from "drizzle-orm";
import { messages, topics } from "@/db/schema";
import { ensureSeed, getTopicMessages, mapTopic } from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  const rows = await db.select().from(topics).where(eq(topics.id, id));
  if (!rows.length) return Response.json({ error: "Oturum bulunamadı" }, { status: 404 });
  const list = await getTopicMessages(id);
  return Response.json({ topic: mapTopic(rows[0]), messages: list });
}

export async function PATCH(req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

  const patch: Record<string, unknown> = { updatedAt: new Date() };
  for (const key of ["title", "question", "status", "sourceText", "report"] as const) {
    if (typeof body[key] === "string") patch[key] = body[key];
  }
  if (typeof body.rounds === "number") patch.rounds = body.rounds;
  if (typeof body.pinned === "boolean") patch.pinned = body.pinned;
  if (Array.isArray(body.sourceIds)) patch.sourceIds = body.sourceIds.map(String);

  const updated = await db.update(topics).set(patch).where(eq(topics.id, id)).returning();
  if (!updated.length) return Response.json({ error: "Oturum bulunamadı" }, { status: 404 });
  return Response.json({ topic: mapTopic(updated[0]) });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  await db.delete(messages).where(eq(messages.topicId, id));
  await db.delete(topics).where(eq(topics.id, id));
  return Response.json({ ok: true, id });
}


