import { db } from "@/db";
import { asc, eq } from "drizzle-orm";
import { messages, topics } from "@/db/schema";
import { ensureSeed, mapMessage } from "@/lib/store";
import { uid } from "@/lib/defaults";
import type { Message, Speaker } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  const list = await getOrdered(id);
  return Response.json({ messages: list });
}

async function getOrdered(topicId: string): Promise<Message[]> {
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.topicId, topicId))
    .orderBy(asc(messages.turnIndex), asc(messages.createdAt));
  return rows.map(mapMessage);
}

export async function POST(req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as Partial<Message> & {
    speaker?: Speaker;
  };

  const row = {
    id: body.id || uid("msg"),
    topicId: id,
    speaker: (body.speaker ?? "seat") as Speaker,
    seatId: body.seatId ?? null,
    authorName: body.authorName || "Model",
    roleTitle: body.roleTitle || "",
    providerName: body.providerName || "",
    model: body.model || "",
    color: body.color || "#8b5cf6",
    avatar: body.avatar || "◈",
    content: body.content ?? "",
    round: body.round ?? 0,
    turnIndex: body.turnIndex ?? Date.now(),
    tokens: body.tokens ?? 0,
    latencyMs: body.latencyMs ?? 0,
    status: body.status ?? "done",
    error: body.error ?? "",
  };

  const inserted = await db.insert(messages).values(row).returning();
  await db.update(topics).set({ updatedAt: new Date() }).where(eq(topics.id, id));
  return Response.json({ message: mapMessage(inserted[0]) }, { status: 201 });
}

/** Bulk append — used when importing a full transcript. */
export async function PUT(req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as { messages?: Partial<Message>[] };
  const incoming = Array.isArray(body.messages) ? body.messages : [];

  for (const [index, item] of incoming.entries()) {
    await db.insert(messages).values({
      id: uid("msg"),
      topicId: id,
      speaker: (item.speaker ?? "seat") as Speaker,
      seatId: item.seatId ?? null,
      authorName: item.authorName || "Model",
      roleTitle: item.roleTitle || "",
      providerName: item.providerName || "",
      model: item.model || "",
      color: item.color || "#8b5cf6",
      avatar: item.avatar || "◈",
      content: item.content ?? "",
      round: item.round ?? 0,
      turnIndex: item.turnIndex ?? index,
      tokens: item.tokens ?? 0,
      latencyMs: item.latencyMs ?? 0,
      status: item.status ?? "done",
      error: item.error ?? "",
    });
  }

  await db.update(topics).set({ updatedAt: new Date() }).where(eq(topics.id, id));
  return Response.json({ messages: await getOrdered(id) });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  await db.delete(messages).where(eq(messages.topicId, id));
  await db
    .update(topics)
    .set({ status: "idle", report: "", updatedAt: new Date() })
    .where(eq(topics.id, id));
  return Response.json({ ok: true, id });
}
