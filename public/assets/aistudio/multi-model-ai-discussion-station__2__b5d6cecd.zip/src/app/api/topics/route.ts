import { db } from "@/db";
import { topics } from "@/db/schema";
import { ensureSeed, getTopics, mapTopic } from "@/lib/store";
import { uid } from "@/lib/defaults";
import type { RoomKind } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  return Response.json({ topics: await getTopics() });
}

export async function POST(req: Request) {
  await ensureSeed();
  const body = (await req.json().catch(() => ({}))) as {
    room?: RoomKind;
    title?: string;
    question?: string;
    rounds?: number;
    sourceIds?: string[];
    sourceText?: string;
  };

  const room = (["council", "jury", "synthesis"] as const).includes(body.room as RoomKind)
    ? (body.room as RoomKind)
    : "council";

  const question = (body.question || "").trim();
  const title =
    (body.title || "").trim() ||
    (question ? (question.length > 60 ? `${question.slice(0, 60)}…` : question) : "Yeni oturum");

  const inserted = await db
    .insert(topics)
    .values({
      id: uid("top"),
      room,
      title,
      question,
      status: "idle",
      rounds: body.rounds ?? 1,
      sourceIds: Array.isArray(body.sourceIds) ? body.sourceIds : [],
      sourceText: body.sourceText ?? "",
      updatedAt: new Date(),
    })
    .returning();

  return Response.json({ topic: mapTopic(inserted[0]) }, { status: 201 });
}


