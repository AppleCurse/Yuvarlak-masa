import { db } from "@/db";
import { eq } from "drizzle-orm";
import { providers, seats } from "@/db/schema";
import { ensureSeed, mapProvider } from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

  const patch: Record<string, unknown> = {};
  if (typeof body.name === "string" && body.name.trim()) patch.name = body.name.trim();
  if (typeof body.kind === "string") patch.kind = body.kind === "demo" ? "demo" : "openai";
  if (typeof body.baseUrl === "string") patch.baseUrl = body.baseUrl.trim();
  if (typeof body.apiKey === "string") patch.apiKey = body.apiKey;
  if (typeof body.color === "string") patch.color = body.color;
  if (typeof body.note === "string") patch.note = body.note;
  if (typeof body.enabled === "boolean") patch.enabled = body.enabled;
  if (Array.isArray(body.models))
    patch.models = body.models.map((m) => String(m)).filter(Boolean);

  if (!Object.keys(patch).length)
    return Response.json({ error: "Güncellenecek alan yok" }, { status: 400 });

  const updated = await db
    .update(providers)
    .set(patch)
    .where(eq(providers.id, id))
    .returning();
  if (!updated.length) return Response.json({ error: "Sağlayıcı bulunamadı" }, { status: 404 });
  return Response.json({ provider: mapProvider(updated[0]) });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  if (id === "prov_demo")
    return Response.json({ error: "Simülatör silinemez" }, { status: 400 });

  const used = await db.select({ id: seats.id }).from(seats).where(eq(seats.providerId, id));
  if (used.length)
    return Response.json(
      { error: "Bu sağlayıcı bir koltukta kullanılıyor, önce koltuğu taşıyın" },
      { status: 409 },
    );

  await db.delete(providers).where(eq(providers.id, id));
  return Response.json({ ok: true, id });
}
