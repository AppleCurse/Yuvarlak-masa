import { db } from "@/db";
import { providers } from "@/db/schema";
import { ensureSeed, getProviders, mapProvider } from "@/lib/store";
import { uid } from "@/lib/defaults";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  return Response.json({ providers: await getProviders() });
}

export async function POST(req: Request) {
  await ensureSeed();
  const body = (await req.json().catch(() => ({}))) as Partial<{
    name: string;
    kind: string;
    baseUrl: string;
    apiKey: string;
    color: string;
    models: string[];
    enabled: boolean;
    note: string;
  }>;

  const name = (body.name || "").trim();
  if (!name) return Response.json({ error: "Sağlayıcı adı gerekli" }, { status: 400 });

  const row = {
    id: uid("prov"),
    name,
    kind: body.kind === "demo" ? "demo" : "openai",
    baseUrl: (body.baseUrl || "").trim(),
    apiKey: body.apiKey || "",
    color: body.color || "#8b5cf6",
    models: Array.isArray(body.models) ? body.models.filter(Boolean) : [],
    enabled: body.enabled ?? true,
    note: body.note || "",
    sortIndex: 100,
  };

  const inserted = await db.insert(providers).values(row).returning();
  return Response.json({ provider: mapProvider(inserted[0]) }, { status: 201 });
}
