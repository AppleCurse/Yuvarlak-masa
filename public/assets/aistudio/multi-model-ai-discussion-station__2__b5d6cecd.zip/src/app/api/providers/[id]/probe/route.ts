import { db } from "@/db";
import { eq } from "drizzle-orm";
import { providers } from "@/db/schema";
import { ensureSeed, mapProvider } from "@/lib/store";
import { probeProvider } from "@/lib/llm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;

  const rows = await db.select().from(providers).where(eq(providers.id, id));
  if (!rows.length) return Response.json({ error: "Sağlayıcı bulunamadı" }, { status: 404 });
  const provider = mapProvider(rows[0]);

  const body = (await req.json().catch(() => ({}))) as { saveModels?: boolean };
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const result = await probeProvider(
      { kind: provider.kind, baseUrl: provider.baseUrl, apiKey: provider.apiKey, name: provider.name },
      controller.signal,
    );

    if (result.ok && result.models.length && body.saveModels !== false) {
      await db
        .update(providers)
        .set({ models: result.models })
        .where(eq(providers.id, id));
      provider.models = result.models;
    }

    return Response.json({ ...result, provider });
  } finally {
    clearTimeout(timeout);
  }
}
