import { getProviders } from "@/lib/store";
import { streamCompletion } from "@/lib/llm";
import type { ChatMessage, ProviderKind } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

interface Body {
  providerId?: string;
  provider?: { kind?: ProviderKind; baseUrl?: string; apiKey?: string; name?: string };
  model?: string;
  messages?: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
  demoDelayMs?: number;
}

export async function POST(req: Request) {
  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return Response.json({ error: "Geçersiz gövde" }, { status: 400 });
  }

  const messages = Array.isArray(body.messages) ? body.messages.filter((m) => m && m.role) : [];
  if (!messages.length) {
    return Response.json({ error: "En az bir mesaj gerekli" }, { status: 400 });
  }
  const model = (body.model || "").trim();
  if (!model) return Response.json({ error: "Model seçilmedi" }, { status: 400 });

  let upstream = body.provider
    ? {
        kind: (body.provider.kind ?? "openai") as ProviderKind,
        baseUrl: body.provider.baseUrl ?? "",
        apiKey: body.provider.apiKey ?? "",
        name: body.provider.name ?? "Sağlayıcı",
      }
    : null;

  if (!upstream && body.providerId) {
    const all = await getProviders();
    const found = all.find((p) => p.id === body.providerId);
    if (!found) return Response.json({ error: "Sağlayıcı bulunamadı" }, { status: 404 });
    upstream = {
      kind: found.kind,
      baseUrl: found.baseUrl,
      apiKey: found.apiKey,
      name: found.name,
    };
  }

  if (!upstream) return Response.json({ error: "Sağlayıcı belirtilmedi" }, { status: 400 });

  const provider = upstream;
  const encoder = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      const send = (event: string, data: unknown) => {
        if (closed) return;
        try {
          controller.enqueue(
            encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`),
          );
        } catch {
          closed = true;
        }
      };
      const close = () => {
        if (closed) return;
        closed = true;
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };

      send("open", { model, provider: provider.name });

      try {
        for await (const event of streamCompletion({
          provider,
          model,
          messages,
          temperature: body.temperature,
          maxTokens: body.maxTokens,
          demoDelayMs: body.demoDelayMs,
          signal: req.signal,
        })) {
          if (req.signal.aborted) break;
          if (event.type === "token") send("token", { t: event.text });
          else if (event.type === "done")
            send("done", { tokens: event.tokens, latencyMs: event.latencyMs });
          else send("error", { message: event.message });
        }
      } catch (err) {
        send("error", { message: err instanceof Error ? err.message : "Bilinmeyen hata" });
      } finally {
        send("close", {});
        close();
      }
    },
    cancel() {
      /* client aborted — upstream fetch is bound to req.signal */
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
