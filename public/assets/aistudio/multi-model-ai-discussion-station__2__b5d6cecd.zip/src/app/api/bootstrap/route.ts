import { ensureSeed, getBootstrap } from "@/lib/store";
import type { Bootstrap } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeed();
    const data: Bootstrap = await getBootstrap();
    return Response.json(data);
  } catch (err) {
    return Response.json(
      { error: err instanceof Error ? err.message : "Veritabanına ulaşılamadı" },
      { status: 500 },
    );
  }
}
