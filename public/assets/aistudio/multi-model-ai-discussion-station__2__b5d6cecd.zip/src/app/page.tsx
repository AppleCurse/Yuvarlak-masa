import type { Metadata } from "next";
import { Station } from "@/components/station";
import { getBootstrap } from "@/lib/store";
import type { Bootstrap } from "@/lib/types";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "KONSÜL AI · Konsey ve Kör Jüri İstasyonu",
};

export default async function Page() {
  let initial: Bootstrap | null = null;
  try {
    initial = await getBootstrap();
  } catch {
    initial = null;
  }
  return <Station initial={initial} />;
}
