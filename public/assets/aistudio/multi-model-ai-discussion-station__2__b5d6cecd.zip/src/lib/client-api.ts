import type { Bootstrap, Message, Provider, Seat, Topic } from "./types";

async function json<T>(res: Response): Promise<T> {
  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    throw new Error(`Sunucu yanıtı çözümlenemedi (HTTP ${res.status})`);
  }
  if (!res.ok) {
    const message =
      (data as { error?: string } | null)?.error || `İstek başarısız (HTTP ${res.status})`;
    throw new Error(message);
  }
  return data as T;
}

export const api = {
  bootstrap: () => fetch("/api/bootstrap").then((r) => json<Bootstrap>(r)),

  archive: () =>
    fetch("/api/archive", { cache: "no-store" }).then((r) =>
      json<{
        entries: {
          id: string;
          room: string;
          title: string;
          question: string;
          status: string;
          pinned: boolean;
          count: number;
          createdAt: string;
          updatedAt: string;
        }[];
      }>(r),
    ),

  createProvider: (body: Partial<Provider>) =>
    fetch("/api/providers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then((r) => json<{ provider: Provider }>(r)),

  updateProvider: (id: string, body: Partial<Provider>) =>
    fetch(`/api/providers/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then((r) => json<{ provider: Provider }>(r)),

  deleteProvider: (id: string) =>
    fetch(`/api/providers/${id}`, { method: "DELETE" }).then((r) => json<{ ok: boolean }>(r)),

  probeProvider: (id: string) =>
    fetch(`/api/providers/${id}/probe`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ saveModels: true }),
    }).then((r) =>
      json<{ ok: boolean; label: string; models: string[]; latencyMs: number; provider: Provider }>(r),
    ),

  saveSeats: (seatsList: Seat[]) =>
    fetch("/api/seats", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ seats: seatsList }),
    }).then((r) => json<{ seats: Seat[] }>(r)),

  createTopic: (body: Partial<Topic>) =>
    fetch("/api/topics", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then((r) => json<{ topic: Topic }>(r)),

  getTopic: (id: string) =>
    fetch(`/api/topics/${id}`, { cache: "no-store" }).then((r) =>
      json<{ topic: Topic; messages: Message[] }>(r),
    ),

  patchTopic: (id: string, body: Partial<Topic>) =>
    fetch(`/api/topics/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then((r) => json<{ topic: Topic }>(r)),

  deleteTopic: (id: string) =>
    fetch(`/api/topics/${id}`, { method: "DELETE" }).then((r) => json<{ ok: boolean }>(r)),

  addMessage: (topicId: string, body: Partial<Message>) =>
    fetch(`/api/topics/${topicId}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then((r) => json<{ message: Message }>(r)),

  clearMessages: (topicId: string) =>
    fetch(`/api/topics/${topicId}/messages`, { method: "DELETE" }).then((r) =>
      json<{ ok: boolean }>(r),
    ),

  saveSettings: (body: Record<string, unknown>) =>
    fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then((r) => json<{ settings: Record<string, unknown> }>(r)),
};
