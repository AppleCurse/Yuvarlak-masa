import { db } from "@/db";
import { asc, eq } from "drizzle-orm";
import { messages, providers, seats, settings, topics } from "@/db/schema";
import { DEFAULT_PROVIDERS, DEFAULT_SEATS, DEFAULT_SETTINGS } from "./defaults";
import type { Bootstrap, Message, Provider, Seat, Topic } from "./types";

let seedChecked = false;

/** Idempotent first-run seeding so a fresh database is immediately usable. */
export async function ensureSeed(force = false) {
  if (seedChecked && !force) return;
  seedChecked = true;

  const providerCount = await db.select({ n: providers.id }).from(providers).limit(1);
  if (providerCount.length === 0) {
    await db.insert(providers).values(DEFAULT_PROVIDERS);
  }
  const seatCount = await db.select({ n: seats.id }).from(seats).limit(1);
  if (seatCount.length === 0) {
    await db.insert(seats).values(DEFAULT_SEATS);
  }
  const settingCount = await db.select({ n: settings.key }).from(settings).limit(1);
  if (settingCount.length === 0) {
    await db.insert(settings).values(
      Object.entries(DEFAULT_SETTINGS).map(([key, value]) => ({ key, value })),
    );
  }
}

export async function getProviders(): Promise<Provider[]> {
  const rows = await db.select().from(providers).orderBy(asc(providers.sortIndex));
  return rows.map(mapProvider);
}

export async function getSeats(): Promise<Seat[]> {
  const rows = await db.select().from(seats).orderBy(asc(seats.sortIndex));
  return rows.map(mapSeat);
}

export async function getTopics(): Promise<Topic[]> {
  const rows = await db
    .select()
    .from(topics)
    .orderBy(asc(topics.pinned), asc(topics.updatedAt));
  return rows.map(mapTopic).sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1));
}

export async function getTopicMessages(topicId: string): Promise<Message[]> {
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.topicId, topicId))
    .orderBy(asc(messages.turnIndex), asc(messages.createdAt));
  return rows.map(mapMessage);
}

export async function getSettings(): Promise<Record<string, unknown>> {
  const rows = await db.select().from(settings);
  const out: Record<string, unknown> = { ...DEFAULT_SETTINGS };
  for (const row of rows) out[row.key] = row.value;
  return out;
}

export async function getBootstrap(): Promise<Bootstrap> {
  await ensureSeed();
  const [providerList, seatList, topicList, settingMap] = await Promise.all([
    getProviders(),
    getSeats(),
    getTopics(),
    getSettings(),
  ]);
  return {
    providers: providerList,
    seats: seatList,
    topics: topicList,
    settings: settingMap,
  };
}

/* ----------------------------- row mappers ----------------------------- */

export function mapProvider(row: typeof providers.$inferSelect): Provider {
  return {
    id: row.id,
    name: row.name,
    kind: row.kind === "demo" ? "demo" : "openai",
    baseUrl: row.baseUrl,
    apiKey: row.apiKey ?? "",
    color: row.color,
    models: Array.isArray(row.models) ? row.models : [],
    enabled: row.enabled,
    sortIndex: row.sortIndex,
    note: row.note ?? "",
  };
}

export function mapSeat(row: typeof seats.$inferSelect): Seat {
  return {
    id: row.id,
    slot: row.slot,
    name: row.name,
    roleTitle: row.roleTitle,
    avatar: row.avatar || row.name.charAt(0).toUpperCase(),
    systemPrompt: row.systemPrompt ?? "",
    providerId: row.providerId,
    model: row.model,
    color: row.color,
    temperature: row.temperature ?? 0.7,
    maxTokens: row.maxTokens ?? 900,
    active: row.active,
    sortIndex: row.sortIndex,
  };
}

export function mapTopic(row: typeof topics.$inferSelect): Topic {
  return {
    id: row.id,
    room: row.room as Topic["room"],
    title: row.title,
    question: row.question ?? "",
    status: row.status,
    rounds: row.rounds,
    sourceIds: Array.isArray(row.sourceIds) ? row.sourceIds : [],
    sourceText: row.sourceText ?? "",
    report: row.report ?? "",
    pinned: row.pinned,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function mapMessage(row: typeof messages.$inferSelect): Message {
  return {
    id: row.id,
    topicId: row.topicId,
    speaker: row.speaker as Message["speaker"],
    seatId: row.seatId,
    authorName: row.authorName,
    roleTitle: row.roleTitle ?? "",
    providerName: row.providerName ?? "",
    model: row.model ?? "",
    color: row.color,
    avatar: row.avatar || "◈",
    content: row.content,
    round: row.round ?? 0,
    turnIndex: row.turnIndex ?? 0,
    tokens: row.tokens ?? 0,
    latencyMs: row.latencyMs ?? 0,
    status: row.status as Message["status"],
    error: row.error ?? "",
    createdAt: row.createdAt.toISOString(),
  };
}
