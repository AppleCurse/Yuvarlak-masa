export type RoomKind = "council" | "jury" | "synthesis";
export type ProviderKind = "openai" | "demo";

export interface Provider {
  id: string;
  name: string;
  kind: ProviderKind;
  baseUrl: string;
  apiKey: string;
  color: string;
  models: string[];
  enabled: boolean;
  sortIndex: number;
  note: string;
}

export interface Seat {
  id: string;
  slot: string;
  name: string;
  roleTitle: string;
  avatar: string;
  systemPrompt: string;
  providerId: string;
  model: string;
  color: string;
  temperature: number;
  maxTokens: number;
  active: boolean;
  sortIndex: number;
}

export type Speaker = "human" | "seat" | "system";
export type MessageStatus = "done" | "streaming" | "stopped" | "error";

export interface Message {
  id: string;
  topicId: string;
  speaker: Speaker;
  seatId: string | null;
  authorName: string;
  roleTitle: string;
  providerName: string;
  model: string;
  color: string;
  avatar: string;
  content: string;
  round: number;
  turnIndex: number;
  tokens: number;
  latencyMs: number;
  status: MessageStatus;
  error: string;
  createdAt: string;
}

export interface Topic {
  id: string;
  room: RoomKind;
  title: string;
  question: string;
  status: string;
  rounds: number;
  sourceIds: string[];
  sourceText: string;
  report: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface StreamRequest {
  providerId?: string;
  provider?: Pick<Provider, "kind" | "baseUrl" | "apiKey" | "name">;
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
}

export interface StreamResult {
  content: string;
  tokens: number;
  latencyMs: number;
  stopped: boolean;
  error?: string;
}

export interface Bootstrap {
  providers: Provider[];
  seats: Seat[];
  topics: Topic[];
  settings: Record<string, unknown>;
}
