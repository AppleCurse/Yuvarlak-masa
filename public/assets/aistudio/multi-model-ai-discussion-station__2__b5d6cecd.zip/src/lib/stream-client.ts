import type { ChatMessage, ProviderKind, StreamResult } from "./types";

export interface StreamBody {
  providerId?: string;
  provider?: { kind: ProviderKind; baseUrl: string; apiKey: string; name: string };
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
  demoDelayMs?: number;
}

interface StreamHandlers {
  signal?: AbortSignal;
  onToken?: (delta: string, full: string) => void;
}

/**
 * Consumes the SSE stream from /api/chat/stream.
 * Resolves with the aggregated result; never throws for upstream model errors —
 * those come back on `result.error` so the UI can show them inline.
 */
export async function streamChat(
  body: StreamBody,
  handlers: StreamHandlers = {},
): Promise<StreamResult> {
  const started = Date.now();
  let content = "";
  let tokens = 0;
  let latencyMs = 0;
  let error: string | undefined;

  let response: Response;
  try {
    response = await fetch("/api/chat/stream", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: handlers.signal,
    });
  } catch (err) {
    if (handlers.signal?.aborted)
      return { content, tokens, latencyMs: Date.now() - started, stopped: true };
    return {
      content,
      tokens,
      latencyMs: Date.now() - started,
      stopped: false,
      error: err instanceof Error ? err.message : "Bağlantı kurulamadı",
    };
  }

  if (!response.ok || !response.body) {
    const detail = await response.text().catch(() => "");
    let message = `HTTP ${response.status}`;
    try {
      message = (JSON.parse(detail) as { error?: string }).error || message;
    } catch {
      /* keep default */
    }
    return { content, tokens, latencyMs: Date.now() - started, stopped: false, error: message };
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const frames = buffer.split("\n\n");
      buffer = frames.pop() ?? "";
      for (const frame of frames) {
        let event = "message";
        const dataLines: string[] = [];
        for (const line of frame.split("\n")) {
          if (line.startsWith("event:")) event = line.slice(6).trim();
          else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
        }
        if (!dataLines.length) continue;
        let payload: Record<string, unknown> = {};
        try {
          payload = JSON.parse(dataLines.join("\n"));
        } catch {
          payload = {};
        }

        if (event === "token") {
          const piece = String(payload.t ?? "");
          if (piece) {
            content += piece;
            handlers.onToken?.(piece, content);
          }
        } else if (event === "done") {
          tokens = Number(payload.tokens ?? 0) || Math.round(content.length / 4);
          latencyMs = Number(payload.latencyMs ?? 0) || Date.now() - started;
        } else if (event === "error") {
          error = String(payload.message ?? "Model hatası");
        }
      }
    }
  } catch (err) {
    if (!handlers.signal?.aborted) {
      error = error ?? (err instanceof Error ? err.message : "Akış kesildi");
    }
  }

  return {
    content,
    tokens: tokens || Math.round(content.length / 4),
    latencyMs: latencyMs || Date.now() - started,
    stopped: Boolean(handlers.signal?.aborted),
    error,
  };
}
