import { demoCompletion, demoStream } from "./demo";
import type { ChatMessage, ProviderKind } from "./types";

export interface UpstreamProvider {
  kind: ProviderKind;
  baseUrl: string;
  apiKey: string;
  name: string;
}

export interface StreamOptions {
  provider: UpstreamProvider;
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
  signal?: AbortSignal;
  demoDelayMs?: number;
}

export type StreamEvent =
  | { type: "token"; text: string }
  | { type: "done"; tokens: number; latencyMs: number }
  | { type: "error"; message: string };

export function normalizeBaseUrl(url: string) {
  const trimmed = (url || "").trim().replace(/\/+$/, "");
  if (!trimmed) return "";
  if (/\/chat\/completions$/.test(trimmed)) return trimmed.replace(/\/chat\/completions$/, "");
  return trimmed;
}

function joinUrl(base: string, path: string) {
  return `${normalizeBaseUrl(base)}${path}`;
}

function authHeaders(provider: UpstreamProvider) {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (provider.apiKey) headers.Authorization = `Bearer ${provider.apiKey}`;
  return headers;
}

export const approximateTokens = (text: string) => Math.max(1, Math.round(text.length / 4));

/** Streams a chat completion from any OpenAI-compatible endpoint (or the local simulator). */
export async function* streamCompletion(opts: StreamOptions): AsyncGenerator<StreamEvent> {
  const started = Date.now();
  const { provider, model, messages, signal } = opts;

  if (provider.kind === "demo") {
    const text = demoCompletion({
      model,
      messages,
      systemPrompt: messages.find((m) => m.role === "system")?.content,
    });
    let out = "";
    for await (const piece of demoStream(text, opts.demoDelayMs ?? 16, signal)) {
      out += piece;
      yield { type: "token", text: piece };
    }
    yield {
      type: "done",
      tokens: approximateTokens(out),
      latencyMs: Date.now() - started,
    };
    return;
  }

  const base = normalizeBaseUrl(provider.baseUrl);
  if (!base) {
    yield { type: "error", message: "Bu sağlayıcı için Base URL tanımlı değil." };
    return;
  }

  let response: Response;
  try {
    response = await fetch(joinUrl(base, "/chat/completions"), {
      method: "POST",
      headers: authHeaders(provider),
      signal,
      body: JSON.stringify({
        model,
        messages,
        stream: true,
        temperature: opts.temperature ?? 0.7,
        max_tokens: opts.maxTokens ?? 900,
        stream_options: { include_usage: true },
      }),
    });
  } catch (err) {
    if (signal?.aborted) return;
    yield {
      type: "error",
      message: `${provider.name} adresine ulaşılamadı (${base}). ${describe(err)}`,
    };
    return;
  }

  if (!response.ok || !response.body) {
    const detail = await safeText(response);
    yield {
      type: "error",
      message: `${provider.name} → HTTP ${response.status}. ${shorten(detail)}`,
    };
    return;
  }

  const contentType = response.headers.get("content-type") ?? "";
  const decoder = new TextDecoder();
  let buffer = "";
  let total = "";
  let usageTokens = 0;

  // Some servers ignore stream:true and answer with a single JSON document.
  if (!contentType.includes("text/event-stream")) {
    const raw = await safeText(response);
    try {
      const json = JSON.parse(raw);
      const text =
        json?.choices?.[0]?.message?.content ??
        json?.choices?.[0]?.text ??
        json?.message?.content ??
        "";
      if (text) {
        total = text;
        yield { type: "token", text };
      } else {
        yield { type: "error", message: `${provider.name} boş yanıt döndürdü.` };
        return;
      }
    } catch {
      if (raw.trim()) {
        total = raw;
        yield { type: "token", text: raw };
      } else {
        yield { type: "error", message: `${provider.name} beklenmeyen yanıt biçimi gönderdi.` };
        return;
      }
    }
    yield {
      type: "done",
      tokens: usageTokens || approximateTokens(total),
      latencyMs: Date.now() - started,
    };
    return;
  }

  const reader = response.body.getReader();
  try {
    while (true) {
      if (signal?.aborted) break;
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const rawLine of lines) {
        const line = rawLine.trim();
        if (!line || !line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
          const json = JSON.parse(payload);
          const piece =
            json?.choices?.[0]?.delta?.content ??
            json?.choices?.[0]?.message?.content ??
            json?.choices?.[0]?.text ??
            json?.response ??
            "";
          if (json?.usage?.completion_tokens) usageTokens = json.usage.completion_tokens;
          if (piece) {
            total += piece;
            yield { type: "token", text: piece };
          }
        } catch {
          /* keep-alive or partial frame — ignore */
        }
      }
    }
  } catch (err) {
    if (!signal?.aborted) {
      yield { type: "error", message: `Akış kesildi: ${describe(err)}` };
      return;
    }
  } finally {
    try {
      reader.releaseLock();
    } catch {
      /* noop */
    }
  }

  yield {
    type: "done",
    tokens: usageTokens || approximateTokens(total),
    latencyMs: Date.now() - started,
  };
}

/** Non-streaming completion used by quick actions (probe, titles, ...). */
export async function completeOnce(opts: StreamOptions): Promise<string> {
  let out = "";
  for await (const event of streamCompletion(opts)) {
    if (event.type === "token") out += event.text;
    if (event.type === "error") throw new Error(event.message);
  }
  return out;
}

export interface ProbeResult {
  ok: boolean;
  label: string;
  models: string[];
  latencyMs: number;
}

/** Checks reachability of an endpoint and pulls its model catalogue. */
export async function probeProvider(
  provider: UpstreamProvider,
  signal?: AbortSignal,
): Promise<ProbeResult> {
  const started = Date.now();
  if (provider.kind === "demo") {
    return {
      ok: true,
      label: "Yerel simülatör hazır",
      models: [],
      latencyMs: 0,
    };
  }
  const base = normalizeBaseUrl(provider.baseUrl);
  if (!base) return { ok: false, label: "Base URL boş", models: [], latencyMs: 0 };

  try {
    const res = await fetch(joinUrl(base, "/models"), {
      headers: authHeaders(provider),
      signal,
    });
    const latencyMs = Date.now() - started;
    if (!res.ok) {
      return {
        ok: false,
        label: `HTTP ${res.status}`,
        models: [],
        latencyMs,
      };
    }
    const json = (await res.json()) as { data?: { id?: string }[]; models?: string[] };
    const list = Array.isArray(json?.data)
      ? json.data.map((m) => m?.id).filter((v): v is string => Boolean(v))
      : Array.isArray(json?.models)
        ? json.models.filter((v): v is string => Boolean(v))
        : [];
    return { ok: true, label: `${list.length} model`, models: list.slice(0, 200), latencyMs };
  } catch (err) {
    return {
      ok: false,
      label: signal?.aborted ? "İptal edildi" : describe(err),
      models: [],
      latencyMs: Date.now() - started,
    };
  }
}

async function safeText(res: Response) {
  try {
    return await res.text();
  } catch {
    return "";
  }
}

const NETWORK_HINTS: Record<string, string> = {
  ECONNREFUSED: "bağlantı reddedildi — uç çalışmıyor olabilir",
  ENOTFOUND: "adres çözümlenemedi — Base URL'i kontrol edin",
  ECONNRESET: "bağlantı sıfırlandı",
  ETIMEDOUT: "zaman aşımı",
  EAI_AGAIN: "DNS geçici olarak yanıt vermiyor",
  EPIPE: "bağlantı koptu",
};

function describe(err: unknown): string {
  const cause = (err as { cause?: { code?: string; message?: string } } | null)?.cause;
  const code = cause?.code;
  if (code && NETWORK_HINTS[code]) return NETWORK_HINTS[code];
  if (cause?.message) return cause.message;
  if (err instanceof Error) {
    if (err.name === "AbortError") return "istek iptal edildi";
    return err.message;
  }
  return String(err);
}

function shorten(text: string, max = 260) {
  const clean = (text || "").replace(/\s+/g, " ").trim();
  return clean.length > max ? `${clean.slice(0, max)}…` : clean;
}
