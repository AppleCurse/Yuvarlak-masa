import type { ChatMessage, Seat } from "./types";

export interface SeatRunInput {
  seat: Seat;
  providerName: string;
  mode: "council" | "jury" | "synthesis";
  question: string;
  transcript?: string;
  round?: number;
  totalRounds?: number;
  operatorNote?: string;
  blindIndex?: number;
}

const BLIND_RULE = `KÖR JÜRİ KURALI: Bu odada diğer modellerin yanıtlarını GÖREMEZSİN ve DUYAMAZSIN.
Başka bir yapay zekâdan bahsetme, onları tahmin etme, "diğer model de dedi ki" gibi ifadeler kurma.
Yalnızca kendi bağımsız analizini üret. Yanıtını karşılaştırılabilir tutmak için şu iskeleti kullan:
## Kısa Cevap
## Gerekçe
## Somut Adımlar
## Belirsizlikler`;

export function buildMessages(input: SeatRunInput): ChatMessage[] {
  const { seat, mode, question } = input;
  const persona = `${seat.name} · ${seat.roleTitle}`;

  if (mode === "jury") {
    const system = [seat.systemPrompt.trim(), "", BLIND_RULE]
      .filter(Boolean)
      .join("\n")
      .trim();
    return [
      { role: "system", content: system },
      {
        role: "user",
        content: `OPERATÖRÜN SORUSU:\n${question.trim()}\n\nBağımsız yanıtını üret.`,
      },
    ];
  }

  if (mode === "synthesis") {
    const sources = input.transcript?.trim() || "(kaynak metin yok)";
    const system = seat.systemPrompt.trim() || "Sen bir sentez hakemisın.";
    const note = input.operatorNote?.trim()
      ? `\n\nOPERATÖRÜN EK TALİMATI:\n${input.operatorNote.trim()}`
      : "";
    return [
      { role: "system", content: system },
      {
        role: "user",
        content: `AŞAĞIDAKİ KAYNAKLARI ANALİZ ET VE NİHAİ RAPORU ÜRET.\n\n=== KAYNAK METİNLER ===\n${sources}\n=== KAYNAK SONU ===${note}\n\nRaporu yalnızca istenen başlıklarla yaz.`,
      },
    ];
  }

  // council
  const round = input.round ?? 1;
  const total = input.totalRounds ?? 1;
  const transcript = input.transcript?.trim();
  const speakerOrder = transcript
    ? "Önceki konuşmacıların iddialarını oku; katıldığın yeri kısa onayla, eksik veya hatalı gördüğün yeri somut gerekçeyle düzelt ve kendi katmanını ekle. Aynı şeyleri tekrar etme."
    : "Masadaki ilk sözü sen alıyorsun: gündemi çerçevele ve net bir öneriyle açılış yap.";

  const system = [
    seat.systemPrompt.trim(),
    "",
    `KİMLİK: ${persona} (${input.providerName} / ${seat.model}).`,
    "Aynı masada başka yapay zekâ üyeleri ve bir insan operatör var. Kısa, yoğun, tekrar etmeyen konuş.",
  ]
    .filter(Boolean)
    .join("\n")
    .trim();

  const user = [
    `GÜNDEM: ${question.trim() || "(operatör gündem girmedi)"}`,
    transcript ? `\nTARTIŞMA TUTANAĞI:\n${transcript}\n` : "",
    `\nSIRA SENDE: ${persona} — tur ${round}/${total}.`,
    speakerOrder,
  ]
    .filter(Boolean)
    .join("\n");

  return [
    { role: "system", content: system },
    { role: "user", content: user },
  ];
}

export function makeTitle(question: string) {
  const clean = question.replace(/\s+/g, " ").trim();
  if (!clean) return "Yeni oturum";
  return clean.length > 58 ? `${clean.slice(0, 58)}…` : clean;
}
