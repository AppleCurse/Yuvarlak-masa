import type { Provider, Seat } from "./types";

export const uid = (prefix = "id") =>
  `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

export const DEFAULT_PROVIDERS: Provider[] = [
  {
    id: "prov_demo",
    name: "Konsül Simülatör",
    kind: "demo",
    baseUrl: "internal://demo",
    apiKey: "",
    color: "#f0f6fc",
    models: [
      "konsul-council-v1",
      "konsul-coder-v1",
      "konsul-critic-v1",
      "konsul-referee-v1",
    ],
    enabled: true,
    sortIndex: 0,
    note: "Yerel yönlendirici bulunamadığında istasyonu çalışır tutan dâhilî akış motoru.",
  },
  {
    id: "prov_9router",
    name: "9Router",
    kind: "openai",
    baseUrl: "http://127.0.0.1:20128/v1",
    apiKey: "",
    color: "#c084fc",
    models: ["pineal-general-reasoning", "pineal-fast-extract", "asistan-ultra"],
    enabled: true,
    sortIndex: 1,
    note: "Varsayılan yerel yönlendirici — OpenAI uyumlu /chat/completions.",
  },
  {
    id: "prov_ollama",
    name: "Ollama",
    kind: "openai",
    baseUrl: "http://127.0.0.1:11434/v1",
    apiKey: "",
    color: "#22c55e",
    models: ["llama3.2", "mixtral-8x7b", "codellama"],
    enabled: true,
    sortIndex: 2,
    note: "Yerel Ollama OpenAI uyumluluk katmanı.",
  },
  {
    id: "prov_lmstudio",
    name: "LM Studio",
    kind: "openai",
    baseUrl: "http://127.0.0.1:1234/v1",
    apiKey: "",
    color: "#38bdf8",
    models: ["mixtral-8x7b-32768", "llama-3.1-70b"],
    enabled: true,
    sortIndex: 3,
    note: "LM Studio yerel sunucu (v1 OpenAI şeması).",
  },
  {
    id: "prov_deepseek",
    name: "DeepSeek",
    kind: "openai",
    baseUrl: "https://api.deepseek.com/v1",
    apiKey: "",
    color: "#34d399",
    models: ["deepseek-chat", "deepseek-reasoner"],
    enabled: false,
    sortIndex: 4,
    note: "Bulut — DEEPSEEK_API_KEY gerektirir.",
  },
  {
    id: "prov_groq",
    name: "Groq",
    kind: "openai",
    baseUrl: "https://api.groq.com/openai/v1",
    apiKey: "",
    color: "#fb923c",
    models: ["llama-3.3-70b-versatile", "mixtral-8x7b-32768"],
    enabled: false,
    sortIndex: 5,
    note: "Bulut — GROQ_API_KEY gerektirir.",
  },
  {
    id: "prov_openai",
    name: "OpenAI",
    kind: "openai",
    baseUrl: "https://api.openai.com/v1",
    apiKey: "",
    color: "#f0f6fc",
    models: ["gpt-4o-mini", "gpt-4o", "o4-mini"],
    enabled: false,
    sortIndex: 6,
    note: "Bulut — OPENAI_API_KEY gerektirir.",
  },
];

const PROMPT_STRATEGIST = `Sen "Açık Konsey Odası"nın STRATEJİST üyesisin.
Görevin: operatörün sorusunu çerçevelemek, hedefleri ve kısıtları netleştirmek, 2-3 uygulanabilir stratejik seçenek sunmak.
Kurallar:
- Kısa, yoğun, madde imli yaz. Uzun giriş cümleleri kurma.
- Her seçeneğin maliyetini ve kazanımını bir satırda belirt.
- Somut bir öneriyle bitir ("Önerim: ...").
- Markdown kullan: ## başlık, - madde, **vurgu**.
- Türkçe yanıt ver.`;

const PROMPT_ENGINEER = `Sen "Açık Konsey Odası"nın TEKNİKER / KODLAYICI üyesisin.
Görevin: stratejistin önerilerini uygulanabilir teknik adımlara, mimariye veya koda dönüştürmek.
Kurallar:
- Önceki konuşmacıların iddialarını teknik açıdan doğrula; yanlışsa somut gerekçeyle düzelt.
- Gerektiğinde kısa, çalışan bir kod bloğu ver (\`\`\` dil belirterek).
- Uygulama risklerini (performans, güvenlik, ölçek) açıkça listele.
- Markdown kullan. Türkçe yanıt ver.`;

const PROMPT_CRITIC = `Sen "Açık Konsey Odası"nın ELEŞTİRMEN / ŞÜPHECİ üyesisin.
Görevin: masadaki her önerinin açık noktasını, gizli varsayımını ve başarısızlık senaryosunu bulmak.
Kurallar:
- Nazik ama acımasız ol. Kanıtsız iddiaları "kanıt gerekli" diye işaretle.
- En az 3 somut risk ve her biri için bir erken uyarı göstergesi ver.
- Hangi önerinin hangi koşulla çökeceğini belirt.
- Markdown kullan. Türkçe yanıt ver.`;

const PROMPT_REFERE = `Sen "Sentez ve Hakem Odası"nın HAKEM MODELİSİN.
Sana bir konsey tartışması veya kör jüri yanıtları verilecek. Hepsini analiz et ve YALNIZCA aşağıdaki başlıkları içeren bir rapor üret:

## ✅ Ortaklaşılan Konular (Konsensüs)
- (tüm kaynakların üzerinde anlaştığı maddeler)

## ⚠️ Anlaşmazlık ve Risk Noktaları
- (kim ne dedi, neden ayrıştılar, hangi risk açıkta)

## 🎯 Operatör İçin En Mantıklı Eylem Planı (Nihai Karar)
1. (adım, sorumlu, süre)
2. ...

## 📌 Hakem Notu
- (güven düzeyi, eksik veri, takip sorusu)

Kurallar: kaynak metni asla birebir kopyalama, sentezle. Halüsinasyon üretme; veride yoksa "kaynaklarda yok" de. Türkçe yaz.`;

export const DEFAULT_SEATS: Seat[] = [
  {
    id: "seat_strategist",
    slot: "strategist",
    name: "Model A",
    roleTitle: "Stratejist",
    avatar: "A",
    systemPrompt: PROMPT_STRATEGIST,
    providerId: "prov_demo",
    model: "konsul-council-v1",
    color: "#c084fc",
    temperature: 0.7,
    maxTokens: 900,
    active: true,
    sortIndex: 0,
  },
  {
    id: "seat_engineer",
    slot: "engineer",
    name: "Model B",
    roleTitle: "Tekniker",
    avatar: "B",
    systemPrompt: PROMPT_ENGINEER,
    providerId: "prov_demo",
    model: "konsul-coder-v1",
    color: "#38bdf8",
    temperature: 0.5,
    maxTokens: 900,
    active: true,
    sortIndex: 1,
  },
  {
    id: "seat_critic",
    slot: "critic",
    name: "Model C",
    roleTitle: "Eleştirmen",
    avatar: "C",
    systemPrompt: PROMPT_CRITIC,
    providerId: "prov_demo",
    model: "konsul-critic-v1",
    color: "#fb7185",
    temperature: 0.8,
    maxTokens: 900,
    active: true,
    sortIndex: 2,
  },
  {
    id: "seat_referee",
    slot: "referee",
    name: "Hakem",
    roleTitle: "Sentez Hakemi",
    avatar: "⚖",
    systemPrompt: PROMPT_REFERE,
    providerId: "prov_demo",
    model: "konsul-referee-v1",
    color: "#fbbf24",
    temperature: 0.3,
    maxTokens: 1400,
    active: true,
    sortIndex: 3,
  },
];

export const DEFAULT_SETTINGS = {
  rounds: 2,
  autoScroll: true,
  streamSpeedMs: 12,
  showSystemLines: true,
  operatorName: "Operatör",
};

/** Council order used by auto-debate; referee is only for the synthesis room. */
export const COUNCIL_SLOTS = ["strategist", "engineer", "critic"];

export function seatBySlot(seats: Seat[], slot: string) {
  return seats.find((s) => s.slot === slot) ?? null;
}
