import type { Message } from "./types";

export function cn(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(" ");
}

export function timeAgo(iso: string) {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "";
  const diff = Date.now() - then;
  const min = Math.round(diff / 60000);
  if (min < 1) return "az önce";
  if (min < 60) return `${min} dk önce`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr} sa önce`;
  const day = Math.round(hr / 24);
  if (day < 30) return `${day} gün önce`;
  return new Date(iso).toLocaleDateString("tr-TR");
}

export function clockTime(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function withAlpha(hex: string, alpha: number) {
  const clean = hex.replace("#", "");
  const full =
    clean.length === 3
      ? clean
          .split("")
          .map((c) => c + c)
          .join("")
      : clean.padEnd(6, "0").slice(0, 6);
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function initials(name: string) {
  const clean = name.replace(/[^\p{L}\p{N}\s]/gu, "").trim();
  if (!clean) return "◈";
  const parts = clean.split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

export function downloadText(filename: string, text: string, mime = "text/markdown") {
  const blob = new Blob([text], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

/* ---------------------------- transcript tools ---------------------------- */

export function messageLabel(message: Message) {
  const bits = [message.authorName, message.roleTitle].filter(Boolean);
  return bits.join(" · ");
}

export function transcriptFrom(messages: Message[], maxChars = 14000) {
  const lines: string[] = [];
  for (const m of messages) {
    if (m.speaker === "system" && !m.content.trim()) continue;
    if (!m.content.trim()) continue;
    const who =
      m.speaker === "human"
        ? `OPERATÖR (${m.authorName})`
        : m.speaker === "system"
          ? "SİSTEM"
          : `${m.authorName}${m.roleTitle ? ` · ${m.roleTitle}` : ""}${m.model ? ` [${m.model}]` : ""}`;
    const round = m.round ? ` (tur ${m.round})` : "";
    lines.push(`${who}${round}:\n${m.content.trim()}`);
  }
  const text = lines.join("\n\n---\n\n");
  return text.length > maxChars ? `${text.slice(text.length - maxChars)}` : text;
}

export interface ReportSection {
  key: string;
  title: string;
  tone: "consensus" | "risk" | "action" | "note";
  body: string;
}

const SECTION_RULES: { key: string; tone: ReportSection["tone"]; match: RegExp }[] = [
  { key: "consensus", tone: "consensus", match: /konsensüs|ortaklaş|ortak\s*laşılan|uzlaş/i },
  { key: "risk", tone: "risk", match: /anlaşmazlık|risk|çelişki|itiraz|tehlike/i },
  { key: "action", tone: "action", match: /eylem planı|nihai karar|aksiyon|yapılacaklar|karar/i },
  { key: "note", tone: "note", match: /hakem notu|not|güven|kaynak/i },
];

const FALLBACK_TITLES: Record<string, string> = {
  consensus: "Ortaklaşılan Konular (Konsensüs)",
  risk: "Anlaşmazlık ve Risk Noktaları",
  action: "Operatör İçin Eylem Planı (Nihai Karar)",
  note: "Hakem Notu",
};

/** Splits a referee report into its canonical sections for card rendering. */
export function parseReport(report: string): ReportSection[] {
  if (!report.trim()) return [];
  const lines = report.split("\n");
  const sections: { title: string; body: string[] }[] = [];
  let current: { title: string; body: string[] } | null = null;

  for (const line of lines) {
    if (/^#{1,4}\s+/.test(line)) {
      if (current) sections.push(current);
      current = { title: line.replace(/^#{1,4}\s+/, "").trim(), body: [] };
    } else if (current) {
      current.body.push(line);
    }
  }
  if (current) sections.push(current);

  if (!sections.length) return [];

  const mapped: ReportSection[] = [];
  for (const section of sections) {
    const rule = SECTION_RULES.find((r) => r.match.test(section.title));
    if (!rule) continue;
    if (mapped.some((m) => m.key === rule.key)) {
      const existing = mapped.find((m) => m.key === rule.key)!;
      existing.body += `\n\n${section.body.join("\n").trim()}`;
      continue;
    }
    mapped.push({
      key: rule.key,
      tone: rule.tone,
      title: section.title.replace(/^[\p{Extended_Pictographic}\s✅⚠🎯📌]+/u, "").trim() ||
        FALLBACK_TITLES[rule.key],
      body: section.body.join("\n").trim(),
    });
  }
  return mapped;
}

export function reportToMarkdown(report: string, meta: { title?: string; model?: string } = {}) {
  const stamp = new Date().toLocaleString("tr-TR");
  const head = [
    `# ${meta.title || "KONSÜL AI · Nihai Hakem Raporu"}`,
    "",
    `_Hakem: ${meta.model || "—"} · Üretim: ${stamp}_`,
    "",
  ].join("\n");
  return `${head}${report.trim()}\n`;
}
