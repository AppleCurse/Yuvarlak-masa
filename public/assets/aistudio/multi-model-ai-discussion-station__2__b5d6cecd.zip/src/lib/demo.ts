import type { ChatMessage } from "./types";

/* Deterministic pseudo-random helpers so repeated runs feel coherent. */
function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i += 1) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function rng(seed: number) {
  let s = seed || 1;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

const pick = <T,>(arr: T[], rand: () => number): T => arr[Math.floor(rand() * arr.length) % arr.length];

function shorten(text: string, max = 140) {
  const clean = text.replace(/\s+/g, " ").trim();
  return clean.length > max ? `${clean.slice(0, max).trimEnd()}…` : clean;
}

function lastUser(messages: ChatMessage[]) {
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    if (messages[i].role === "user") return messages[i].content;
  }
  return messages[messages.length - 1]?.content ?? "";
}

function previousSpeakers(messages: ChatMessage[]): string[] {
  return messages
    .filter((m) => m.role === "assistant")
    .map((m) => m.content)
    .filter(Boolean);
}

function quoteFrom(text: string) {
  const line =
    text
      .split("\n")
      .map((l) => l.replace(/^[-*#>\d.\s]+/, "").trim())
      .find((l) => l.length > 25) ?? text.slice(0, 90);
  return shorten(line, 120);
}

const MODEL_PROFILE: Record<string, { label: string; tone: string }> = {
  "konsul-council-v1": { label: "stratejik çerçeve", tone: "Stratejist" },
  "konsul-coder-v1": { label: "teknik uygulama", tone: "Tekniker" },
  "konsul-critic-v1": { label: "risk denetimi", tone: "Eleştirmen" },
  "konsul-referee-v1": { label: "nihai sentez", tone: "Hakem" },
};

function profileFor(model: string, systemPrompt: string) {
  if (MODEL_PROFILE[model]) return MODEL_PROFILE[model];
  const prompt = systemPrompt.toLowerCase();
  if (prompt.includes("eleştirmen") || prompt.includes("critic"))
    return { label: "risk denetimi", tone: "Eleştirmen" };
  if (prompt.includes("tekniker") || prompt.includes("kod")) return { label: "teknik uygulama", tone: "Tekniker" };
  if (prompt.includes("hakem") || prompt.includes("sentez")) return { label: "nihai sentez", tone: "Hakem" };
  return { label: "stratejik çerçeve", tone: "Stratejist" };
}

/** Produces a plausible, well-structured Turkish answer for the offline simulator. */
export function demoCompletion(opts: {
  model: string;
  messages: ChatMessage[];
  systemPrompt?: string;
}): string {
  const { model, messages } = opts;
  const systemPrompt =
    opts.systemPrompt ?? messages.find((m) => m.role === "system")?.content ?? "";
  const question = lastUser(messages);
  const priors = previousSpeakers(messages);
  const rand = rng(hashString(`${model}|${question}|${priors.length}`));
  const profile = profileFor(model, systemPrompt);
  const topic = shorten(question, 110) || "tanımsız gündem";
  const roundNo = priors.length + 1;

  if (profile.tone === "Hakem") return refereeReport(topic, priors, question, rand);

  if (profile.tone === "Stratejist") {
    const options = [
      ["Kademeli pilot", "küçük bir kapsamda doğrula, sonra ölçekle"],
      ["Tek seferde tam geçiş", "hızlı kazanım, yüksek operasyonel risk"],
      ["Hibrit model", "çekirdeği elde tut, çevreyi dışa devret"],
    ];
    const chosen = pick(options, rand);
    return `## Stratejik Çerçeve — Tur ${roundNo}

**Gündem:** ${topic}

Masadaki asıl mesele teknik değil, **öncelik sırası**. Kaynak sınırlı olduğu için aynı anda hem hız hem mükemmellik istenemez.

### Kısıtlar
- Süre: karar ${pick(["48 saat", "1 hafta", "2 sprint"], rand)} içinde netleşmeli.
- Bütçe: mevcut ekip ve altyapıyla ilerlemek zorundayız.
- Bilgi: ${pick(["ölçüm verisi eksik", "kullanıcı geri bildirimi az", "rakip kıyası yok"], rand)}.

### Seçenekler
${options
  .map(
    (o, i) =>
      `${i + 1}. **${o[0]}** — ${o[1]}. Maliyet: ${pick(["düşük", "orta", "yüksek"], rand)}, kazanım: ${pick(["orta", "yüksek", "kademeli"], rand)}.`,
  )
  .join("\n")}

**Önerim:** ${chosen[0]}. İlk ${pick(["7 gün", "10 gün", "2 hafta"], rand)} içinde tek bir ölçülebilir hedefe bağlayalım: *${pick(["dönüşüm oranı", "hata bütçesi", "yanıt süresi", "elde tutma"], rand)}*.

> Bir sonraki konuşmacıdan beklentim: bu seçeneğin uygulama adımlarını ve teknik borcunu netleştirmesi.

\`[simülatör · ${profile.label} · ${model}]\``;
  }

  if (profile.tone === "Tekniker") {
    const prior = priors.length ? quoteFrom(priors[priors.length - 1]) : null;
    return `## Teknik Uygulama — Tur ${roundNo}

${prior ? `Stratejistin *"${prior}"* ifadesini teknik olarak doğruladım; uygulanabilir ama iki düzeltme gerekiyor.` : `Doğrudan uygulanabilir bir teknik plan çıkarıyorum.`}

### Uygulama adımları
1. **Veri katmanı:** şemayı tek yerde tanımla, migration'ları sürümle.
2. **Servis katmanı:** iş kurallarını HTTP katmanından ayır; ${pick(["route handler", "use-case servisi", "domain modülü"], rand)} içinde topla.
3. **Gözlemlenebilirlik:** her adıma yapılandırılmış log + gecikme metriği ekle.

\`\`\`ts
// Akışı durdurulabilir hale getiren minimal desen
export async function* streamAnswer(prompt: string, signal: AbortSignal) {
  const res = await fetch("/v1/chat/completions", {
    method: "POST",
    signal,
    body: JSON.stringify({ model: "${model}", stream: true, messages: [{ role: "user", content: prompt }] }),
  });
  const reader = res.body!.getReader();
  const dec = new TextDecoder();
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    yield dec.decode(value, { stream: true });
  }
}
\`\`\`

### Teknik açıklar
- **Yarış durumu:** paralel ${pick(["3 sütun", "çoklu model", "çoklu istek"], rand)} çağrısında aynı kaynağa yazılıyorsa son yazan kazanır → kilit veya tek yazıcı gerekir.
- **Zaman aşımı:** uzun üretimlerde istemci bağlantısı koparsa sunucu akışı iptal edilmeli, yoksa kaynak sızıntısı olur.
- **Maliyet:** \`max_tokens\` sınırsız bırakılırsa ${pick(["%40", "%60", "2 kat"], rand)} daha fazla token yakılır.

**Sonuç:** strateji uygulanabilir; önce iptal (abort) mekanizmasını, sonra ölçümü kuralım.

\`[simülatör · ${profile.label} · ${model}]\``;
  }

  const prior = priors.length ? quoteFrom(priors[priors.length - 1]) : null;
  return `## Eleştiri ve Risk Denetimi — Tur ${roundNo}

${prior ? `Önceki iddia: *"${prior}"*. Bu cümle **kanıtsız**; masada veri olarak sunuluyor ama ölçüm yok.` : `Masada henüz kanıtlanmış bir iddia yok, bu yüzden varsayımları denetliyorum.`}

### Açık noktalar
- **Gizli varsayım:** ekibin ve altyapının hazır olduğu varsayılıyor. Doğrulanmadı.
- **Tanımsız başarı ölçütü:** "iyileşme" deniyor ama eşik yok. Eşik yoksa karar verilemez.
- **Geri alma planı yok:** hata olursa ${pick(["30 dakika", "2 saat", "1 gün"], rand)} içinde nasıl dönüleceği yazılmamış.

### Riskler ve erken uyarı göstergeleri
| Risk | Etki | Erken uyarı göstergesi |
| --- | --- | --- |
| Kapsam büyümesi | Yüksek | İlk sprintte ≥ 2 ek istek |
| Veri kalitesi | Orta | Hatalı kayıt oranı > %${pick(["1", "3", "5"], rand)} |
| Ekip tükenmesi | Yüksek | Aynı kişide ≥ 3 acil müdahale |

### Çökme koşulu
${pick(["Canlı veri akışı gecikirse", "Paydaş onayı ertelenirse", "Test ortamı hazırlanmazsa"], rand)} bu plan **ilk haftada** çöker.

**Karşı önerim:** tam ölçekli geçiş yerine ${pick(["2 haftalık", "10 günlük", "tek sprintlik"], rand)} geri alınabilir bir deneme; çıkış kriteri baştan yazılsın.

\`[simülatör · ${profile.label} · ${model}]\``;
}

function refereeReport(topic: string, priors: string[], question: string, rand: () => number) {
  const count = priors.length || 3;
  return `## ✅ Ortaklaşılan Konular (Konsensüs)

- ${count} kaynak da gündemin *"${topic}"* olduğunu ve kararın ertelenmemesi gerektiğini doğruluyor.
- Kademeli, geri alınabilir bir ilerleme; tek seferde büyük geçişten daha güvenli bulunmuş.
- Ölçülebilir bir başarı kriteri tanımlanmadan uygulama başlatılmamalı.

## ⚠️ Anlaşmazlık ve Risk Noktaları

- **Hız ↔ güvenlik:** stratejik taraf erken kazanım istiyor, eleştirel taraf kanıt olmadan ilerlemeyi riskli buluyor. Ayrışma noktası *pilot kapsamı*.
- **Teknik borç:** tekniker iptal/abort ve gözlemlenebilirlik eksiklerini işaretledi; bu giderilmeden paralel çalışma yarış durumu üretir.
- **Veri boşluğu:** kaynaklarda eşik değeri ve geri alma planı yok. Bu iki alan raporda **eksik** olarak işaretlendi.

## 🎯 Operatör İçin En Mantıklı Eylem Planı (Nihai Karar)

1. **Bugün:** başarı ölçütünü tek cümleyle yaz, eşik değeri belirle (sorumlu: operatör, ${pick(["30 dk", "1 saat"], rand)}).
2. **1-2. gün:** ${pick(["10 günlük", "2 haftalık", "tek sprintlik"], rand)} geri alınabilir pilotu başlat; iptal ve gözlemlenebilirlik katmanını ekle (sorumlu: teknik ekip).
3. **3. gün:** erken uyarı göstergelerini panoya koy; eşik aşılırsa otomatik durdur.
4. **Pilot sonunda:** ölçümle karar ver — ölçekle, düzelt veya kapat.

## 📌 Hakem Notu

- **Güven düzeyi:** ${pick(["orta-yüksek", "orta", "yüksek"], rand)} (${count} kaynak karşılaştırıldı).
- **Eksik veri:** maliyet tahmini ve gerçek kullanıcı metriği kaynaklarda yok.
- **Takip sorusu:** pilot başarısız olursa geri alma maliyeti kimin bütçesinden karşılanacak?

\`[simülatör · nihai sentez · ${priors.length ? `${count} kaynak analiz edildi` : "örnek rapor"}]\``;
}

/** Streams a finished answer word-by-word, honouring an abort signal. */
export async function* demoStream(
  text: string,
  delayMs: number,
  signal?: AbortSignal,
): AsyncGenerator<string> {
  const tokens = text.split(/(\s+)/);
  for (const token of tokens) {
    if (signal?.aborted) return;
    if (!token) continue;
    yield token;
    if (delayMs > 0) await sleep(delayMs, signal);
  }
}

function sleep(ms: number, signal?: AbortSignal) {
  return new Promise<void>((resolve) => {
    const t = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    function onAbort() {
      clearTimeout(t);
      resolve();
    }
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}


