"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api } from "./client-api";
import { streamChat } from "./stream-client";
import { buildMessages, makeTitle } from "./prompts";
import { DEFAULT_PROVIDERS, DEFAULT_SEATS, DEFAULT_SETTINGS, uid } from "./defaults";
import { transcriptFrom } from "./format";
import type { Bootstrap, Message, Provider, Seat, Topic } from "./types";

export type View = "council" | "jury" | "synthesis" | "records" | "settings";
export type Tone = "info" | "ok" | "warn" | "bad";

export interface Toast {
  id: string;
  text: string;
  tone: Tone;
}

export interface ProbeState {
  status: "idle" | "probing" | "ok" | "bad";
  label: string;
  latencyMs: number;
  models: string[];
}

export interface ArchiveEntry {
  id: string;
  room: string;
  title: string;
  question: string;
  status: string;
  pinned: boolean;
  count: number;
  createdAt: string;
  updatedAt: string;
}

export type ColumnStatus = "idle" | "streaming" | "done" | "stopped" | "error";

export interface JuryColumn {
  key: string;
  seatId: string;
  model: string;
  message: Message | null;
  status: ColumnStatus;
  tokens: number;
  latencyMs: number;
  error: string;
}

export interface Settings {
  rounds: number;
  autoScroll: boolean;
  streamSpeedMs: number;
  showSystemLines: boolean;
  operatorName: string;
}

const asSettings = (raw: Record<string, unknown>): Settings => ({
  rounds: Number(raw.rounds ?? DEFAULT_SETTINGS.rounds) || 1,
  autoScroll: Boolean(raw.autoScroll ?? DEFAULT_SETTINGS.autoScroll),
  streamSpeedMs: Number(raw.streamSpeedMs ?? DEFAULT_SETTINGS.streamSpeedMs) || 16,
  showSystemLines: Boolean(raw.showSystemLines ?? DEFAULT_SETTINGS.showSystemLines),
  operatorName: String(raw.operatorName ?? DEFAULT_SETTINGS.operatorName),
});

export function useStation(initial: Bootstrap | null) {
  const offline = initial === null;
  const offlineRef = useRef(offline);

  const [ready, setReady] = useState(true);
  const [view, setView] = useState<View>("council");
  const [providers, setProviders] = useState<Provider[]>(initial?.providers ?? DEFAULT_PROVIDERS);
  const [seats, setSeats] = useState<Seat[]>(initial?.seats ?? DEFAULT_SEATS);
  const [settings, setSettings] = useState<Settings>(asSettings(initial?.settings ?? {}));
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [probes, setProbes] = useState<Record<string, ProbeState>>({});
  const [archive, setArchive] = useState<ArchiveEntry[]>([]);

  /* ------------------------------- council ------------------------------- */
  const [councilTopic, setCouncilTopic] = useState<Topic | null>(null);
  const [councilMessages, setCouncilMessagesState] = useState<Message[]>([]);
  const [councilRunning, setCouncilRunning] = useState(false);
  const [councilQueue, setCouncilQueue] = useState<string[]>([]);
  const [rounds, setRounds] = useState(settings.rounds);
  const councilRef = useRef<Message[]>([]);
  const turnRef = useRef(0);
  const seqRef = useRef(0);
  const cancelRef = useRef(false);
  const abortsRef = useRef<Map<string, AbortController>>(new Map());
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  const setCouncilMessages = useCallback(
    (updater: Message[] | ((prev: Message[]) => Message[])) => {
      const next =
        typeof updater === "function"
          ? (updater as (prev: Message[]) => Message[])(councilRef.current)
          : updater;
      councilRef.current = next;
      setCouncilMessagesState(next);
    },
    [],
  );

  /** Monotonic ordering key (bigint in Postgres) so transcripts reload in order. */
  const nextSeq = useCallback(() => {
    seqRef.current = (seqRef.current + 1) % 100;
    return Date.now() * 100 + seqRef.current;
  }, []);

  const updateMessage = useCallback(
    (id: string, patch: Partial<Message>) => {
      setCouncilMessages((prev) => prev.map((m) => (m.id === id ? { ...m, ...patch } : m)));
    },
    [setCouncilMessages],
  );

  /* -------------------------------- jury --------------------------------- */
  const [juryTopic, setJuryTopic] = useState<Topic | null>(null);
  const [juryQuestion, setJuryQuestion] = useState("");
  const [juryColumns, setJuryColumns] = useState<JuryColumn[]>([]);
  const [juryRunning, setJuryRunning] = useState(false);

  /* ------------------------------ synthesis ------------------------------ */
  const [synthTopic, setSynthTopic] = useState<Topic | null>(null);
  const [synthSource, setSynthSource] = useState("");
  const [synthOrigin, setSynthOrigin] = useState<"none" | "council" | "jury" | "archive" | "manual">(
    "none",
  );
  const [synthNote, setSynthNote] = useState("");
  const [synthReport, setSynthReport] = useState("");
  const [synthLive, setSynthLive] = useState(false);
  const [synthMeta, setSynthMeta] = useState({ tokens: 0, latencyMs: 0, model: "" });

  const providerMap = useMemo(() => {
    const map = new Map<string, Provider>();
    for (const p of providers) map.set(p.id, p);
    return map;
  }, [providers]);

  const councilSeats = useMemo(
    () => seats.filter((s) => s.active && s.slot !== "referee").sort((a, b) => a.sortIndex - b.sortIndex),
    [seats],
  );

  const refereeSeat = useMemo(
    () => seats.find((s) => s.slot === "referee") ?? seats[seats.length - 1] ?? null,
    [seats],
  );

  const providerFor = useCallback(
    (seat: Seat | null) => (seat ? providerMap.get(seat.providerId) ?? null : null),
    [providerMap],
  );

  /* -------------------------------- toasts -------------------------------- */
  const toast = useCallback((text: string, tone: Tone = "info") => {
    const id = uid("t");
    setToasts((prev) => [...prev.slice(-3), { id, text, tone }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 3800);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  /* --------------------------- persistence guard -------------------------- */
  const persist = useCallback(
    async <T,>(label: string, fn: () => Promise<T>): Promise<T | null> => {
      if (offlineRef.current) return null;
      try {
        return await fn();
      } catch (err) {
        toast(`${label}: ${err instanceof Error ? err.message : "kayıt hatası"}`, "warn");
        return null;
      }
    },
    [toast],
  );

  const refreshArchive = useCallback(async () => {
    if (offlineRef.current) return;
    try {
      const res = await api.archive();
      setArchive(res.entries);
    } catch {
      /* archive is optional */
    }
  }, []);

  useEffect(() => {
    void refreshArchive();
  }, [refreshArchive]);

  /* ------------------------------ jury setup ------------------------------ */
  useEffect(() => {
    if (juryColumns.length) return;
    const first = councilSeats.slice(0, 3);
    if (first.length < 3) return;
    setJuryColumns(
      first.map((seat, index) => ({
        key: `col_${index}`,
        seatId: seat.id,
        model: seat.model,
        message: null,
        status: "idle" as ColumnStatus,
        tokens: 0,
        latencyMs: 0,
        error: "",
      })),
    );
  }, [councilSeats, juryColumns.length]);

  /* -------------------------------- helpers ------------------------------- */
  const abort = useCallback((key: string) => {
    const controller = abortsRef.current.get(key);
    controller?.abort();
    abortsRef.current.delete(key);
  }, []);

  const newController = useCallback((key: string) => {
    abortsRef.current.get(key)?.abort();
    const controller = new AbortController();
    abortsRef.current.set(key, controller);
    return controller;
  }, []);

  const stopEverything = useCallback(() => {
    cancelRef.current = true;
    for (const controller of abortsRef.current.values()) controller.abort();
    abortsRef.current.clear();
    setCouncilRunning(false);
    setCouncilQueue([]);
    setJuryRunning(false);
    setSynthLive(false);
    setJuryColumns((prev) =>
      prev.map((c) =>
        c.status === "streaming"
          ? {
              ...c,
              status: "stopped",
              message: c.message ? { ...c.message, status: "stopped" } : c.message,
            }
          : c,
      ),
    );
    setCouncilMessages((prev) =>
      prev.map((m) => (m.status === "streaming" ? { ...m, status: "stopped" } : m)),
    );
    toast("Üretim durduruldu", "warn");
  }, [setCouncilMessages, toast]);

  const makeSeatMessage = useCallback(
    (topicId: string, seat: Seat, round: number, turnIndex: number): Message => {
      const provider = providerFor(seat);
      return {
        id: uid("msg"),
        topicId,
        speaker: "seat",
        seatId: seat.id,
        authorName: seat.name,
        roleTitle: seat.roleTitle,
        providerName: provider?.name ?? "—",
        model: seat.model,
        color: seat.color,
        avatar: seat.avatar,
        content: "",
        round,
        turnIndex,
        tokens: 0,
        latencyMs: 0,
        status: "streaming",
        error: "",
        createdAt: new Date().toISOString(),
      };
    },
    [providerFor],
  );

  const makeHumanMessage = useCallback(
    (topicId: string, text: string, turnIndex: number): Message => ({
      id: uid("msg"),
      topicId,
      speaker: "human",
      seatId: null,
      authorName: settings.operatorName || "Operatör",
      roleTitle: "İnsan Operatör",
      providerName: "yerel",
      model: "",
      color: "#f0f6fc",
      avatar: "◉",
      content: text,
      round: 0,
      turnIndex,
      tokens: 0,
      latencyMs: 0,
      status: "done",
      error: "",
      createdAt: new Date().toISOString(),
    }),
    [settings.operatorName],
  );

  /* -------------------------------- council ------------------------------- */
  const ensureCouncilTopic = useCallback(
    async (question: string): Promise<Topic | null> => {
      if (councilTopic) return councilTopic;
      const draft: Topic = {
        id: uid("top"),
        room: "council",
        title: makeTitle(question),
        question,
        status: "running",
        rounds,
        sourceIds: [],
        sourceText: "",
        report: "",
        pinned: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const saved = await persist("Oturum", () =>
        api.createTopic({ room: "council", title: draft.title, question, rounds }),
      );
      const topic = saved?.topic ?? draft;
      setCouncilTopic(topic);
      return topic;
    },
    [councilTopic, persist, rounds],
  );

  const speakSeat = useCallback(
    async (seat: Seat, topicId: string, question: string, round: number, turnIndex: number) => {
      const controller = newController("council");
      const message = makeSeatMessage(topicId, seat, round, turnIndex);
      setCouncilMessages((prev) => [...prev, message]);

      const provider = providerFor(seat);
      const payload = buildMessages({
        seat,
        providerName: provider?.name ?? "—",
        mode: "council",
        question,
        transcript: transcriptFrom(councilRef.current),
        round,
        totalRounds: rounds,
      });

      const result = await streamChat(
        {
          provider: provider
            ? { kind: provider.kind, baseUrl: provider.baseUrl, apiKey: provider.apiKey, name: provider.name }
            : undefined,
          providerId: provider ? undefined : seat.providerId,
          model: seat.model,
          messages: payload,
          temperature: seat.temperature,
          maxTokens: seat.maxTokens,
          demoDelayMs: settingsRef.current.streamSpeedMs,
        },
        {
          signal: controller.signal,
          onToken: (_delta, full) => updateMessage(message.id, { content: full }),
        },
      );

      abortsRef.current.delete("council");
      const finalStatus: Message["status"] = result.error ? "error" : result.stopped ? "stopped" : "done";
      const finalContent = result.content || (result.stopped ? "(üretim durduruldu)" : "");
      updateMessage(message.id, {
        content: finalContent,
        status: finalStatus,
        tokens: result.tokens,
        latencyMs: result.latencyMs,
        error: result.error ?? "",
      });

      const finished: Message = {
        ...message,
        content: finalContent,
        status: finalStatus,
        tokens: result.tokens,
        latencyMs: result.latencyMs,
        error: result.error ?? "",
      };

      await persist("Mesaj", () =>
        api.addMessage(topicId, {
          ...finished,
          createdAt: undefined as unknown as string,
        } as Partial<Message>),
      );

      if (result.error) toast(`${seat.name}: ${result.error}`, "bad");
      return finished;
    },
    [
      abortsRef,
      makeSeatMessage,
      newController,
      persist,
      providerFor,
      rounds,
      seats,
      setCouncilMessages,
      toast,
      updateMessage,
    ],
  );

  const nextSpeaker = useCallback(() => {
    const list = councilSeats;
    if (!list.length) return null;
    return list[turnRef.current % list.length];
  }, [councilSeats]);

  const speakNext = useCallback(async (): Promise<Message | null> => {
    const seat = nextSpeaker();
    const question = councilTopic?.question || councilRef.current.find((m) => m.speaker === "human")?.content || "";
    if (!seat) {
      toast("Masada aktif koltuk yok", "warn");
      return null;
    }
    const topic = councilTopic ?? (await ensureCouncilTopic(question));
    if (!topic) return null;
    const index = turnRef.current;
    const round = Math.floor(index / Math.max(1, councilSeats.length)) + 1;
    turnRef.current = index + 1;
    setCouncilQueue([]);
    return speakSeat(seat, topic.id, topic.question || question, round, nextSeq());
  }, [councilSeats.length, councilTopic, ensureCouncilTopic, nextSeq, nextSpeaker, speakSeat, toast]);

  const councilSend = useCallback(
    async (text: string) => {
      const question = text.trim();
      if (!question) {
        toast("Önce bir gündem yazın", "warn");
        return;
      }
      cancelRef.current = false;
      const topic = await ensureCouncilTopic(question);
      if (!topic) return;
      const human = makeHumanMessage(topic.id, question, nextSeq());
      setCouncilMessages((prev) => [...prev, human]);
      await persist("Mesaj", () => api.addMessage(topic.id, human));
      setCouncilRunning(true);
      await speakNext();
      setCouncilRunning(false);
      void refreshArchive();
    },
    [
      ensureCouncilTopic,
      makeHumanMessage,
      nextSeq,
      persist,
      refreshArchive,
      setCouncilMessages,
      speakNext,
      toast,
    ],
  );

  const councilInterject = useCallback(
    async (text: string) => {
      const content = text.trim();
      if (!content) return;
      const topic = councilTopic ?? (await ensureCouncilTopic(content));
      if (!topic) return;
      const human = makeHumanMessage(topic.id, content, nextSeq());
      setCouncilMessages((prev) => [...prev, human]);
      await persist("Mesaj", () => api.addMessage(topic.id, human));
      if (!councilRunning) toast("Operatör sözü tutanağa işlendi", "ok");
    },
    [
      councilRunning,
      councilTopic,
      ensureCouncilTopic,
      makeHumanMessage,
      nextSeq,
      persist,
      setCouncilMessages,
      toast,
    ],
  );

  const autoDebate = useCallback(async () => {
    const topic = councilTopic;
    const question = topic?.question?.trim();
    if (!topic || !question) {
      toast("Otomatik tartışma için önce bir gündem gönderin", "warn");
      return;
    }
    cancelRef.current = false;
    setCouncilRunning(true);
    const total = councilSeats.length * Math.max(1, rounds);
    const queue: string[] = [];
    for (let i = 0; i < total; i += 1) {
      const seat = councilSeats[i % councilSeats.length];
      if (seat) queue.push(seat.id);
    }
    setCouncilQueue(queue);

    for (let i = 0; i < total; i += 1) {
      if (cancelRef.current) break;
      const seat = councilSeats[i % councilSeats.length];
      if (!seat) continue;
      setCouncilQueue(queue.slice(i + 1));
      const index = turnRef.current;
      const round = Math.floor(index / Math.max(1, councilSeats.length)) + 1;
      turnRef.current = index + 1;
      // eslint-disable-next-line no-await-in-loop
      await speakSeat(seat, topic.id, question, round, nextSeq());
      if (cancelRef.current) break;
    }

    setCouncilQueue([]);
    setCouncilRunning(false);
    if (!cancelRef.current) {
      await persist("Oturum", () => api.patchTopic(topic.id, { status: "done" }));
      setCouncilTopic((prev) => (prev ? { ...prev, status: "done" } : prev));
      toast("Tartışma tamamlandı — Sentez odasına aktarabilirsiniz", "ok");
    }
    void refreshArchive();
  }, [councilSeats, councilTopic, nextSeq, persist, refreshArchive, rounds, speakSeat, toast]);

  const clearCouncil = useCallback(async () => {
    cancelRef.current = true;
    abort("council");
    if (councilTopic) await persist("Oturum", () => api.deleteTopic(councilTopic.id));
    setCouncilTopic(null);
    setCouncilMessages([]);
    turnRef.current = 0;
    setCouncilRunning(false);
    setCouncilQueue([]);
    void refreshArchive();
  }, [abort, councilTopic, persist, refreshArchive, setCouncilMessages]);

  const newCouncilTopic = useCallback(async () => {
    if (councilTopic) await persist("Oturum", () => api.patchTopic(councilTopic.id, { status: "done" }));
    setCouncilTopic(null);
    setCouncilMessages([]);
    turnRef.current = 0;
    void refreshArchive();
  }, [councilTopic, persist, refreshArchive, setCouncilMessages]);

  /* --------------------------------- jury --------------------------------- */
  const ensureJuryTopic = useCallback(
    async (question: string): Promise<Topic | null> => {
      const saved = await persist("Jüri oturumu", () =>
        api.createTopic({ room: "jury", question, title: makeTitle(question) }),
      );
      const topic: Topic =
        saved?.topic ?? {
          id: uid("top"),
          room: "jury",
          title: makeTitle(question),
          question,
          status: "running",
          rounds: 1,
          sourceIds: [],
          sourceText: "",
          report: "",
          pinned: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
      setJuryTopic(topic);
      return topic;
    },
    [persist],
  );

  const runJury = useCallback(
    async (rawQuestion?: string) => {
      const question = (rawQuestion ?? juryQuestion).trim();
      if (!question) {
        toast("Jüri için bir soru yazın", "warn");
        return;
      }
      cancelRef.current = false;
      setJuryQuestion(question);
      const topic = await ensureJuryTopic(question);
      if (!topic) return;
      setJuryRunning(true);

      const columns = juryColumns.length
        ? juryColumns
        : councilSeats.slice(0, 3).map((seat, index) => ({
            key: `col_${index}`,
            seatId: seat.id,
            model: seat.model,
            message: null,
            status: "idle" as ColumnStatus,
            tokens: 0,
            latencyMs: 0,
            error: "",
          }));

      setJuryColumns(
        columns.map((c) => ({ ...c, message: null, status: "streaming", tokens: 0, latencyMs: 0, error: "" })),
      );

      await Promise.all(
        columns.map(async (column) => {
          const seat = seats.find((s) => s.id === column.seatId);
          if (!seat) return;
          const provider = providerFor(seat);
          const runSeat: Seat = { ...seat, model: column.model || seat.model };
          const message = makeSeatMessage(topic.id, runSeat, 1, nextSeq());
          setJuryColumns((prev) =>
            prev.map((c) => (c.key === column.key ? { ...c, message } : c)),
          );

          const controller = newController(`jury_${column.key}`);
          const result = await streamChat(
            {
              provider: provider
                ? {
                    kind: provider.kind,
                    baseUrl: provider.baseUrl,
                    apiKey: provider.apiKey,
                    name: provider.name,
                  }
                : undefined,
              providerId: provider ? undefined : seat.providerId,
              model: runSeat.model,
              messages: buildMessages({
                seat: runSeat,
                providerName: provider?.name ?? "—",
                mode: "jury",
                question,
                blindIndex: 0,
              }),
              temperature: seat.temperature,
              maxTokens: seat.maxTokens,
              demoDelayMs: settingsRef.current.streamSpeedMs,
            },
            {
              signal: controller.signal,
              onToken: (_d, full) =>
                setJuryColumns((prev) =>
                  prev.map((c) =>
                    c.key === column.key && c.message
                      ? { ...c, message: { ...c.message, content: full } }
                      : c,
                  ),
                ),
            },
          );

          abortsRef.current.delete(`jury_${column.key}`);
          const status: ColumnStatus = result.error ? "error" : result.stopped ? "stopped" : "done";
          const content = result.content || (result.stopped ? "(üretim durduruldu)" : "");

          setJuryColumns((prev) =>
            prev.map((c) =>
              c.key === column.key
                ? {
                    ...c,
                    status,
                    tokens: result.tokens,
                    latencyMs: result.latencyMs,
                    error: result.error ?? "",
                    message: c.message
                      ? {
                          ...c.message,
                          content,
                          status,
                          tokens: result.tokens,
                          latencyMs: result.latencyMs,
                          error: result.error ?? "",
                        }
                      : c.message,
                  }
                : c,
            ),
          );

          await persist("Jüri yanıtı", () =>
            api.addMessage(topic.id, {
              speaker: "seat",
              seatId: seat.id,
              authorName: runSeat.name,
              roleTitle: runSeat.roleTitle,
              providerName: provider?.name ?? "",
              model: runSeat.model,
              color: runSeat.color,
              avatar: runSeat.avatar,
              content,
              round: 1,
              turnIndex: message.turnIndex,
              tokens: result.tokens,
              latencyMs: result.latencyMs,
              status,
              error: result.error ?? "",
            }),
          );
          if (result.error) toast(`${runSeat.name}: ${result.error}`, "bad");
        }),
      );

      setJuryRunning(false);
      await persist("Jüri oturumu", () => api.patchTopic(topic.id, { status: "done" }));
      setJuryTopic((prev) => (prev ? { ...prev, status: "done", question } : prev));
      void refreshArchive();
      if (!cancelRef.current) toast("Kör jüri tamamlandı — 3 bağımsız yanıt hazır", "ok");
    },
    [
      abortsRef,
      councilSeats,
      ensureJuryTopic,
      juryColumns,
      juryQuestion,
      makeSeatMessage,
      newController,
      nextSeq,
      persist,
      providerFor,
      refreshArchive,
      seats,
      toast,
    ],
  );

  const clearJury = useCallback(async () => {
    for (const column of juryColumns) abort(`jury_${column.key}`);
    if (juryTopic) await persist("Jüri", () => api.deleteTopic(juryTopic.id));
    setJuryTopic(null);
    setJuryQuestion("");
    setJuryColumns((prev) =>
      prev.map((c) => ({ ...c, message: null, status: "idle", tokens: 0, latencyMs: 0, error: "" })),
    );
    setJuryRunning(false);
    void refreshArchive();
  }, [abort, juryColumns, juryTopic, persist, refreshArchive]);

  const setColumnSeat = useCallback((key: string, seatId: string) => {
    setJuryColumns((prev) =>
      prev.map((c) => (c.key === key ? { ...c, seatId } : c)),
    );
  }, []);

  const setColumnModel = useCallback((key: string, model: string) => {
    setJuryColumns((prev) => prev.map((c) => (c.key === key ? { ...c, model } : c)));
  }, []);

  /* ------------------------------- synthesis ------------------------------ */
  const ensureSynthTopic = useCallback(
    async (origin: string, sourceIds: string[]): Promise<Topic | null> => {
      const saved = await persist("Sentez oturumu", () =>
        api.createTopic({
          room: "synthesis",
          title: `Sentez · ${origin}`,
          question: origin,
          sourceIds,
        }),
      );
      const topic: Topic =
        saved?.topic ?? {
          id: uid("top"),
          room: "synthesis",
          title: `Sentez · ${origin}`,
          question: origin,
          status: "running",
          rounds: 1,
          sourceIds,
          sourceText: "",
          report: "",
          pinned: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
      setSynthTopic(topic);
      return topic;
    },
    [persist],
  );

  const pullFromCouncil = useCallback(async () => {
    if (!councilTopic || councilRef.current.length === 0) {
      toast("Konsey tutanağı boş", "warn");
      return;
    }
    const text = [
      `KAYNAK: Açık Konsey Odası — "${councilTopic.title}"`,
      `GÜNDEM: ${councilTopic.question}`,
      "",
      transcriptFrom(councilRef.current),
    ].join("\n");
    setSynthSource(text);
    setSynthOrigin("council");
    setSynthReport("");
    await ensureSynthTopic("Açık Konsey", [councilTopic.id]);
    setView("synthesis");
    toast("Konsey tutanağı sentez odasına çekildi", "ok");
  }, [councilTopic, ensureSynthTopic, toast]);

  const pullFromJury = useCallback(async () => {
    const answered = juryColumns.filter((c) => c.message?.content?.trim());
    if (!answered.length) {
      toast("Kör jüride yanıt yok", "warn");
      return;
    }
    const blocks = answered.map((c) => {
      const seat = seats.find((s) => s.id === c.seatId);
      const head = `${seat?.name ?? "Model"} · ${seat?.roleTitle ?? ""} [${c.model}]`;
      return `--- ${head} ---\n${(c.message?.content ?? "").trim()}`;
    });
    const text = [
      `KAYNAK: Kör Jüri Odası — "${juryTopic?.title ?? makeTitle(juryQuestion)}"`,
      `SORU: ${juryTopic?.question ?? juryQuestion}`,
      "",
      blocks.join("\n\n"),
    ].join("\n");
    setSynthSource(text);
    setSynthOrigin("jury");
    setSynthReport("");
    await ensureSynthTopic("Kör Jüri", juryTopic ? [juryTopic.id] : []);
    setView("synthesis");
    toast("Kör jüri yanıtları sentez odasına çekildi", "ok");
  }, [ensureSynthTopic, juryColumns, juryQuestion, juryTopic, seats, toast]);

  const runSynthesis = useCallback(async () => {
    const source = synthSource.trim();
    if (!source) {
      toast("Önce kaynak metni çekin veya yapıştırın", "warn");
      return;
    }
    if (!refereeSeat) {
      toast("Hakem koltuğu tanımlı değil", "warn");
      return;
    }
    cancelRef.current = false;
    const topic = synthTopic ?? (await ensureSynthTopic("Elle giriş", []));
    if (!topic) return;

    const controller = newController("synth");
    const provider = providerFor(refereeSeat);
    setSynthLive(true);
    setSynthReport("");
    setSynthMeta({ tokens: 0, latencyMs: 0, model: refereeSeat.model });

    const result = await streamChat(
      {
        provider: provider
          ? { kind: provider.kind, baseUrl: provider.baseUrl, apiKey: provider.apiKey, name: provider.name }
          : undefined,
        providerId: provider ? undefined : refereeSeat.providerId,
        model: refereeSeat.model,
        messages: buildMessages({
          seat: refereeSeat,
          providerName: provider?.name ?? "—",
          mode: "synthesis",
          question: topic.question,
          transcript: source,
          operatorNote: synthNote,
        }),
        temperature: refereeSeat.temperature,
        maxTokens: refereeSeat.maxTokens,
        demoDelayMs: settingsRef.current.streamSpeedMs,
      },
      { signal: controller.signal, onToken: (_d, full) => setSynthReport(full) },
    );

    abortsRef.current.delete("synth");
    setSynthLive(false);
    const content = result.content || (result.stopped ? "(rapor üretimi durduruldu)" : "");
    setSynthReport(content);
    setSynthMeta({ tokens: result.tokens, latencyMs: result.latencyMs, model: refereeSeat.model });

    if (result.error) {
      toast(`Hakem: ${result.error}`, "bad");
    } else {
      await persist("Rapor", () =>
        api.patchTopic(topic.id, {
          report: content,
          sourceText: source,
          status: result.stopped ? "stopped" : "done",
        }),
      );
      await persist("Rapor", () =>
        api.addMessage(topic.id, {
          speaker: "seat",
          seatId: refereeSeat.id,
          authorName: refereeSeat.name,
          roleTitle: refereeSeat.roleTitle,
          providerName: provider?.name ?? "",
          model: refereeSeat.model,
          color: refereeSeat.color,
          avatar: refereeSeat.avatar,
          content,
          round: 1,
          turnIndex: nextSeq(),
          tokens: result.tokens,
          latencyMs: result.latencyMs,
          status: result.stopped ? "stopped" : "done",
        }),
      );
      setSynthTopic((prev) => (prev ? { ...prev, report: content, status: "done" } : prev));
      if (!result.stopped) toast("Nihai rapor hazır", "ok");
    }
    void refreshArchive();
  }, [
    abortsRef,
    ensureSynthTopic,
    newController,
    nextSeq,
    persist,
    providerFor,
    refereeSeat,
    refreshArchive,
    synthNote,
    synthSource,
    synthTopic,
    toast,
  ]);

  const clearSynthesis = useCallback(async () => {
    abort("synth");
    if (synthTopic) await persist("Sentez", () => api.deleteTopic(synthTopic.id));
    setSynthTopic(null);
    setSynthSource("");
    setSynthReport("");
    setSynthOrigin("none");
    setSynthNote("");
    setSynthLive(false);
    void refreshArchive();
  }, [abort, persist, refreshArchive, synthTopic]);

  /* -------------------------------- records ------------------------------- */
  const openTopic = useCallback(
    async (entry: ArchiveEntry) => {
      let topic: Topic | null = null;
      let list: Message[] = [];
      if (!offlineRef.current) {
        try {
          const res = await api.getTopic(entry.id);
          topic = res.topic;
          list = res.messages;
        } catch (err) {
          toast(err instanceof Error ? err.message : "Oturum açılamadı", "bad");
          return;
        }
      }
      if (!topic) return;

      if (topic.room === "council") {
        cancelRef.current = true;
        abort("council");
        setCouncilTopic(topic);
        setCouncilMessages(list);
        turnRef.current = list.filter((m) => m.speaker === "seat").length;
        setView("council");
      } else if (topic.room === "jury") {
        setJuryTopic(topic);
        setJuryQuestion(topic.question);
        setJuryColumns((prev) => {
          const base = prev.length ? prev : councilSeats.slice(0, 3).map((seat, index) => ({
            key: `col_${index}`,
            seatId: seat.id,
            model: seat.model,
            message: null,
            status: "idle" as ColumnStatus,
            tokens: 0,
            latencyMs: 0,
            error: "",
          }));
          return base.map((column, index) => {
            const message =
              list.find((m) => m.seatId && m.seatId === column.seatId) ?? list[index] ?? null;
            return {
              ...column,
              seatId: message?.seatId ?? column.seatId,
              model: message?.model || column.model,
              message,
              status: message ? ((message.status as ColumnStatus) ?? "done") : "idle",
              tokens: message?.tokens ?? 0,
              latencyMs: message?.latencyMs ?? 0,
              error: message?.error ?? "",
            };
          });
        });
        setView("jury");
      } else {
        setSynthTopic(topic);
        setSynthSource(topic.sourceText);
        setSynthReport(topic.report);
        setSynthOrigin("archive");
        setView("synthesis");
      }
      toast(`"${topic.title}" yüklendi`, "ok");
    },
    [abort, councilSeats, setCouncilMessages, toast],
  );

  const deleteTopic = useCallback(
    async (id: string) => {
      await persist("Silme", () => api.deleteTopic(id));
      if (councilTopic?.id === id) {
        setCouncilTopic(null);
        setCouncilMessages([]);
        turnRef.current = 0;
      }
      if (juryTopic?.id === id) setJuryTopic(null);
      if (synthTopic?.id === id) {
        setSynthTopic(null);
        setSynthReport("");
      }
      setArchive((prev) => prev.filter((e) => e.id !== id));
      void refreshArchive();
    },
    [councilTopic?.id, juryTopic?.id, persist, refreshArchive, setCouncilMessages, synthTopic?.id],
  );

  const togglePin = useCallback(
    async (entry: ArchiveEntry) => {
      const next = !entry.pinned;
      setArchive((prev) => prev.map((e) => (e.id === entry.id ? { ...e, pinned: next } : e)));
      await persist("Sabitleme", () => api.patchTopic(entry.id, { pinned: next }));
      if (councilTopic?.id === entry.id) setCouncilTopic((p) => (p ? { ...p, pinned: next } : p));
      void refreshArchive();
    },
    [councilTopic?.id, persist, refreshArchive],
  );

  /* ------------------------------- settings ------------------------------- */
  const saveProvider = useCallback(
    async (draft: Partial<Provider> & { id?: string }) => {
      if (draft.id) {
        const res = await persist("Sağlayıcı", () => api.updateProvider(draft.id as string, draft));
        if (res) {
          setProviders((prev) => prev.map((p) => (p.id === res.provider.id ? res.provider : p)));
          toast(`${res.provider.name} güncellendi`, "ok");
        } else {
          setProviders((prev) => prev.map((p) => (p.id === draft.id ? { ...p, ...draft } as Provider : p)));
        }
      } else {
        const res = await persist("Sağlayıcı", () => api.createProvider(draft));
        if (res) {
          setProviders((prev) => [...prev, res.provider]);
          toast(`${res.provider.name} eklendi`, "ok");
        } else {
          const local: Provider = {
            id: uid("prov"),
            name: draft.name || "Yeni sağlayıcı",
            kind: draft.kind ?? "openai",
            baseUrl: draft.baseUrl || "",
            apiKey: draft.apiKey || "",
            color: draft.color || "#8b5cf6",
            models: draft.models || [],
            enabled: draft.enabled ?? true,
            sortIndex: providers.length + 100,
            note: draft.note || "",
          };
          setProviders((prev) => [...prev, local]);
        }
      }
    },
    [persist, providers, toast],
  );

  const removeProvider = useCallback(
    async (id: string) => {
      const res = await persist("Silme", () => api.deleteProvider(id));
      if (res || offlineRef.current) {
        setProviders((prev) => prev.filter((p) => p.id !== id));
        toast("Sağlayıcı silindi", "ok");
      }
    },
    [persist, toast],
  );

  const probeProvider = useCallback(
    async (id: string, opts?: { silent?: boolean }) => {
      const provider = providerMap.get(id);
      if (!provider) return;
      const silent = Boolean(opts?.silent);
      setProbes((prev) => ({ ...prev, [id]: { status: "probing", label: "test…", latencyMs: 0, models: [] } }));
      if (provider.kind === "demo") {
        setProbes((prev) => ({
          ...prev,
          [id]: { status: "ok", label: "yerel simülatör", latencyMs: 0, models: provider.models },
        }));
        return;
      }
      if (offlineRef.current) {
        setProbes((prev) => ({ ...prev, [id]: { status: "bad", label: "çevrimdışı", latencyMs: 0, models: [] } }));
        return;
      }
      try {
        const res = await api.probeProvider(id);
        setProbes((prev) => ({
          ...prev,
          [id]: {
            status: res.ok ? "ok" : "bad",
            label: res.ok ? `${res.models.length || provider.models.length} model · ${res.latencyMs} ms` : res.label,
            latencyMs: res.latencyMs,
            models: res.models.length ? res.models : provider.models,
          },
        }));
        if (res.provider) setProviders((prev) => prev.map((p) => (p.id === id ? res.provider : p)));
        if (!silent)
          toast(res.ok ? `${provider.name} erişilebilir` : `${provider.name}: ${res.label}`, res.ok ? "ok" : "bad");
      } catch (err) {
        const label = err instanceof Error ? err.message : "Hata";
        setProbes((prev) => ({ ...prev, [id]: { status: "bad", label, latencyMs: 0, models: [] } }));
        if (!silent) toast(`${provider.name}: ${label}`, "bad");
      }
    },
    [providerMap, toast],
  );

  /** Silent reachability sweep so the sidebar shows live endpoint state. */
  useEffect(() => {
    let cancelled = false;
    const sweep = async () => {
      for (const provider of providers) {
        if (cancelled) return;
        if (!provider.enabled) continue;
        // eslint-disable-next-line no-await-in-loop
        await probeProvider(provider.id, { silent: true });
      }
    };
    void sweep();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const moveSeatsToProvider = useCallback(
    async (providerId: string, model?: string) => {
      const provider = providerMap.get(providerId);
      if (!provider) return;
      const fallback = provider.models[0] ?? "";
      const next = seats.map((seat) => ({
        ...seat,
        providerId,
        model:
          model ??
          provider.models.find((m) => m.toLowerCase().includes(seat.slot.slice(0, 4))) ??
          (provider.models.length ? provider.models[Math.min(seat.sortIndex, provider.models.length - 1)] : seat.model) ??
          fallback,
      }));
      setSeats(next);
      const saved = await persist("Koltuklar", () => api.saveSeats(next));
      if (saved) setSeats(saved.seats);
      toast(`Tüm koltuklar ${provider.name} sağlayıcısına bağlandı`, "ok");
    },
    [persist, providerMap, seats, toast],
  );

  const saveSeats = useCallback(
    async (next: Seat[]) => {
      setSeats(next);
      const saved = await persist("Koltuklar", () => api.saveSeats(next));
      if (saved) setSeats(saved.seats);
      else toast("Koltuklar güncellendi", "ok");
    },
    [persist, toast],
  );

  const saveSettings = useCallback(
    async (patch: Partial<Settings>) => {
      const next = { ...settings, ...patch };
      setSettings(next);
      settingsRef.current = next;
      const saved = await persist("Ayarlar", () => api.saveSettings(next as unknown as Record<string, unknown>));
      if (saved) setSettings(asSettings(saved.settings));
      toast("Ayarlar kaydedildi", "ok");
    },
    [persist, settings, toast],
  );

  const resetDefaults = useCallback(async () => {
    setProviders(DEFAULT_PROVIDERS);
    setSeats(DEFAULT_SEATS);
    setSettings(asSettings(DEFAULT_SETTINGS as unknown as Record<string, unknown>));
    if (!offlineRef.current) {
      await persist("Sıfırlama", async () => {
        await api.saveSeats(DEFAULT_SEATS);
        for (const p of DEFAULT_PROVIDERS) {
          await api.updateProvider(p.id, p).catch(() => api.createProvider(p));
        }
        return null;
      });
    }
    toast("Varsayılan yapılandırma geri yüklendi", "ok");
  }, [persist, toast]);

  useEffect(() => () => abortsRef.current.clear(), []);

  return {
    ready,
    offline,
    view,
    setView,
    providers,
    providerMap,
    seats,
    councilSeats,
    refereeSeat,
    settings,
    toasts,
    toast,
    dismissToast,
    probes,
    archive,
    refreshArchive,
    rounds,
    setRounds,
    // council
    councilTopic,
    councilMessages,
    councilRunning,
    councilQueue,
    nextSpeaker,
    councilSend,
    councilInterject,
    speakNext,
    autoDebate,
    clearCouncil,
    newCouncilTopic,
    // jury
    juryTopic,
    juryQuestion,
    setJuryQuestion,
    juryColumns,
    juryRunning,
    runJury,
    clearJury,
    setColumnSeat,
    setColumnModel,
    // synthesis
    synthTopic,
    synthSource,
    setSynthSource,
    synthOrigin,
    synthNote,
    setSynthNote,
    synthReport,
    synthLive,
    synthMeta,
    pullFromCouncil,
    pullFromJury,
    runSynthesis,
    clearSynthesis,
    // records
    openTopic,
    deleteTopic,
    togglePin,
    // settings
    saveProvider,
    removeProvider,
    probeProvider,
    saveSeats,
    saveSettings,
    moveSeatsToProvider,
    resetDefaults,
    stopEverything,
    providerFor,
  };
}

export type Station = ReturnType<typeof useStation>;
