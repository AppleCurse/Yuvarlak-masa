import {
  bigint,
  boolean,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * A model endpoint (9Router, Ollama, LM Studio, OpenAI, DeepSeek, Groq, ...).
 * `kind = "demo"` uses the built-in local simulator so the station always works
 * even when no inference router is reachable.
 */
export const providers = pgTable("providers", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull().default("openai"), // openai | demo
  baseUrl: text("base_url").notNull(),
  apiKey: text("api_key").notNull().default(""),
  color: text("color").notNull().default("#8b5cf6"),
  models: jsonb("models").$type<string[]>().notNull().default([]),
  enabled: boolean("enabled").notNull().default(true),
  sortIndex: integer("sort_index").notNull().default(0),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** A chair at the table: strategist, engineer, critic, referee or a custom seat. */
export const seats = pgTable("seats", {
  id: text("id").primaryKey(),
  slot: text("slot").notNull(), // strategist | engineer | critic | referee | custom
  name: text("name").notNull(),
  roleTitle: text("role_title").notNull(),
  avatar: text("avatar").notNull().default("A"),
  systemPrompt: text("system_prompt").notNull().default(""),
  providerId: text("provider_id").notNull(),
  model: text("model").notNull(),
  color: text("color").notNull().default("#8b5cf6"),
  temperature: doublePrecision("temperature").notNull().default(0.7),
  maxTokens: integer("max_tokens").notNull().default(900),
  active: boolean("active").notNull().default(true),
  sortIndex: integer("sort_index").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** One discussion / jury run / synthesis job. */
export const topics = pgTable("topics", {
  id: text("id").primaryKey(),
  room: text("room").notNull(), // council | jury | synthesis
  title: text("title").notNull().default("Yeni oturum"),
  question: text("question").notNull().default(""),
  status: text("status").notNull().default("idle"), // idle | running | done | stopped | error
  rounds: integer("rounds").notNull().default(1),
  sourceIds: jsonb("source_ids").$type<string[]>().notNull().default([]),
  sourceText: text("source_text").notNull().default(""),
  report: text("report").notNull().default(""),
  pinned: boolean("pinned").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** A single utterance inside a topic. */
export const messages = pgTable("messages", {
  id: text("id").primaryKey(),
  topicId: text("topic_id")
    .notNull()
    .references(() => topics.id, { onDelete: "cascade" }),
  speaker: text("speaker").notNull(), // human | seat | system
  seatId: text("seat_id"),
  authorName: text("author_name").notNull().default("Operatör"),
  roleTitle: text("role_title").notNull().default(""),
  providerName: text("provider_name").notNull().default(""),
  model: text("model").notNull().default(""),
  color: text("color").notNull().default("#ffffff"),
  avatar: text("avatar").notNull().default("◈"),
  content: text("content").notNull().default(""),
  round: integer("round").notNull().default(0),
  /** Ordering key inside a topic — millisecond stamps need bigint. */
  turnIndex: bigint("turn_index", { mode: "number" }).notNull().default(0),
  tokens: integer("tokens").notNull().default(0),
  latencyMs: integer("latency_ms").notNull().default(0),
  status: text("status").notNull().default("done"), // done | stopped | error
  error: text("error").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Loose key/value app settings (rounds, streaming speed, theme accents...). */
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type ProviderRow = typeof providers.$inferSelect;
export type SeatRow = typeof seats.$inferSelect;
export type TopicRow = typeof topics.$inferSelect;
export type MessageRow = typeof messages.$inferSelect;
