import { db } from "@/db";
import { appSettings, providers, seats } from "@/db/schema";
import { DEFAULT_PROMPTS } from "@/lib/prompts";

const DEFAULT_PROVIDERS = [
  {
    id: "provider-9router",
    name: "9Router",
    baseUrl: "http://127.0.0.1:20128/v1",
    apiKey: "",
  },
  {
    id: "provider-ollama",
    name: "Ollama",
    baseUrl: "http://127.0.0.1:11434/v1",
    apiKey: "",
  },
  {
    id: "provider-lmstudio",
    name: "LM Studio",
    baseUrl: "http://127.0.0.1:1234/v1",
    apiKey: "",
  },
  {
    id: "provider-openai",
    name: "OpenAI",
    baseUrl: "https://api.openai.com/v1",
    apiKey: "",
  },
  {
    id: "provider-groq",
    name: "Groq",
    baseUrl: "https://api.groq.com/openai/v1",
    apiKey: "",
  },
  {
    id: "provider-deepseek",
    name: "DeepSeek",
    baseUrl: "https://api.deepseek.com/v1",
    apiKey: "",
  },
];

const DEFAULT_SEATS = [
  {
    id: "seat-a",
    slot: "A",
    name: "Lyra",
    role: "Stratejist",
    systemPrompt: DEFAULT_PROMPTS.A,
    modelId: "pineal-general-reasoning",
    providerId: "provider-9router",
    color: "#c084fc",
  },
  {
    id: "seat-b",
    slot: "B",
    name: "Hex",
    role: "Tekniker",
    systemPrompt: DEFAULT_PROMPTS.B,
    modelId: "pineal-fast-extract",
    providerId: "provider-9router",
    color: "#34d399",
  },
  {
    id: "seat-c",
    slot: "C",
    name: "Vesper",
    role: "Eleştirmen",
    systemPrompt: DEFAULT_PROMPTS.C,
    modelId: "asistan-ultra",
    providerId: "provider-9router",
    color: "#60a5fa",
  },
  {
    id: "seat-judge",
    slot: "judge",
    name: "Aurelia",
    role: "Hakem / Sentez",
    systemPrompt: DEFAULT_PROMPTS.judge,
    modelId: "pineal-general-reasoning",
    providerId: "provider-9router",
    color: "#fbbf24",
  },
];

export async function ensureSeeded() {
  await db.insert(providers).values(DEFAULT_PROVIDERS).onConflictDoNothing();
  await db.insert(seats).values(DEFAULT_SEATS).onConflictDoNothing();
  await db
    .insert(appSettings)
    .values({
      id: "global",
      demoMode: false,
      autoFallback: true,
      debateRounds: 3,
    })
    .onConflictDoNothing();
}
