export type RoomId = "council" | "jury" | "synthesis";

export type SeatSlot = "A" | "B" | "C" | "judge";

export type ProviderRecord = {
  id: string;
  name: string;
  baseUrl: string;
  apiKey: string;
};

export type SeatRecord = {
  id: string;
  slot: SeatSlot;
  name: string;
  role: string;
  systemPrompt: string;
  modelId: string;
  providerId: string;
  color: string;
};

export type SettingsRecord = {
  id: string;
  demoMode: boolean;
  autoFallback: boolean;
  debateRounds: number;
};

export type SessionRecord = {
  id: string;
  mode: RoomId;
  title: string;
  topic: string;
  status: string;
  autoRounds: number;
  createdAt: string;
};

export type MessageRecord = {
  id: string;
  sessionId: string;
  seatId: string | null;
  speaker: string;
  name: string;
  roleLabel: string;
  content: string;
  round: number;
  createdAt: string;
};

export type ChatTurn = {
  id: string;
  speaker: string;
  seatId?: string | null;
  name: string;
  roleLabel: string;
  content: string;
  color?: string;
  avatar?: string;
  streaming?: boolean;
  error?: boolean;
  round?: number;
  createdAt: string;
};

export type BootstrapPayload = {
  providers: ProviderRecord[];
  seats: SeatRecord[];
  settings: SettingsRecord;
  sessions: SessionRecord[];
};
