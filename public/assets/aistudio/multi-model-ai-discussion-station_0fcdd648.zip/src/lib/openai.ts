export type OpenAiChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

export function joinUrl(base: string, path: string): string {
  const trimmedBase = base.replace(/\/+$/, "");
  const trimmedPath = path.replace(/^\/+/, "");
  return `${trimmedBase}/${trimmedPath}`;
}

export function resolveApiKey(baseUrl: string, storedKey: string): string {
  const key = storedKey.trim();
  if (key) return key;
  const url = baseUrl.toLowerCase();
  if (url.includes("openai.com")) return process.env.OPENAI_API_KEY ?? "";
  if (url.includes("groq.com")) return process.env.GROQ_API_KEY ?? "";
  if (url.includes("deepseek.com")) return process.env.DEEPSEEK_API_KEY ?? "";
  if (url.includes("openrouter.ai")) return process.env.OPENROUTER_API_KEY ?? "";
  if (url.includes("googleapis.com") || url.includes("generativelanguage")) {
    return process.env.GOOGLE_API_KEY ?? process.env.GEMINI_API_KEY ?? "";
  }
  return "";
}

export function extractDelta(payload: unknown): string {
  if (!payload || typeof payload !== "object") return "";
  const data = payload as Record<string, unknown>;

  const choices = data.choices;
  if (Array.isArray(choices) && choices[0] && typeof choices[0] === "object") {
    const choice = choices[0] as Record<string, unknown>;
    const delta = choice.delta;
    if (delta && typeof delta === "object") {
      const content = (delta as Record<string, unknown>).content;
      if (typeof content === "string") return content;
    }
    const message = choice.message;
    if (message && typeof message === "object") {
      const content = (message as Record<string, unknown>).content;
      if (typeof content === "string") return content;
    }
    if (typeof choice.text === "string") return choice.text;
  }

  if (typeof data.content === "string") return data.content;
  if (typeof data.response === "string") return data.response;
  return "";
}

export async function listRemoteModels(baseUrl: string, apiKey: string) {
  const url = joinUrl(baseUrl, "models");
  const headers: Record<string, string> = { Accept: "application/json" };
  const resolved = resolveApiKey(baseUrl, apiKey);
  if (resolved) headers.Authorization = `Bearer ${resolved}`;

  const response = await fetch(url, {
    headers,
    cache: "no-store",
    signal: AbortSignal.timeout(4000),
  });
  if (!response.ok) {
    throw new Error(`Model listesi alınamadı (${response.status})`);
  }
  const json = (await response.json()) as {
    data?: { id?: string }[];
    models?: { name?: string; id?: string }[];
  };
  const ids = new Set<string>();
  for (const item of json.data ?? []) {
    if (item.id) ids.add(item.id);
  }
  for (const item of json.models ?? []) {
    if (item.id) ids.add(item.id);
    if (item.name) ids.add(item.name);
  }
  return [...ids];
}
