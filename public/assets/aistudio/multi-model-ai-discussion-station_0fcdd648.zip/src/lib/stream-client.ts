export type StreamEvent = {
  type: string;
  text?: string;
  message?: string;
  demo?: boolean;
  model?: string;
};

export async function consumeSse(
  response: Response,
  onEvent: (event: StreamEvent) => void,
): Promise<void> {
  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error("Akış gövdesi yok");
  }
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const parts = buffer.split("\n\n");
    buffer = parts.pop() ?? "";
    for (const part of parts) {
      const line = part
        .split("\n")
        .map((item) => item.trim())
        .find((item) => item.startsWith("data:"));
      if (!line) continue;
      const raw = line.slice(5).trim();
      if (!raw || raw === "[DONE]") {
        onEvent({ type: "done" });
        continue;
      }
      try {
        onEvent(JSON.parse(raw) as StreamEvent);
      } catch {
        onEvent({ type: "delta", text: raw });
      }
    }
  }
}

export async function streamChat(params: {
  seatId: string;
  messages: { role: "system" | "user" | "assistant"; content: string }[];
  temperature?: number;
  signal: AbortSignal;
  onEvent: (event: StreamEvent) => void;
}): Promise<void> {
  const response = await fetch("/api/chat/stream", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      seatId: params.seatId,
      messages: params.messages,
      temperature: params.temperature ?? 0.7,
    }),
    signal: params.signal,
  });

  if (!response.ok) {
    let message = `İstek başarısız (${response.status})`;
    try {
      const json = (await response.json()) as { error?: string };
      if (json.error) message = json.error;
    } catch {
      /* ignore */
    }
    throw new Error(message);
  }

  await consumeSse(response, params.onEvent);
}
