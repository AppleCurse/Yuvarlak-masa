export const DEFAULT_PROMPTS = {
  A: `Sen KONSÜL masasının Stratejistisin. Büyük resmi görürsün: hedef, kısıt, paydaş, zaman ufkunu netleştirirsin. Seçenekleri ve trade-off'ları çerçevelersin. Somut, yapılandırılmış ve karar odaklı konuş. Diğer üyelerin sözünü dikkate al ama kendi analitik çerçeveni koru. Gereksiz tekrar yapma. Kullanıcının dilinde yanıt ver.`,
  B: `Sen KONSÜL masasının Teknikeri / Kodlayıcısısın. Fizibilite, mimari, uygulama adımları, gizli varsayımlar ve somut teknik çözümler üretirsin. Gerekirse kısa kod iskeleti, API sözleşmesi veya kontrol listesi ver. Stratejistin vizyonunu uygulanabilir hale getir. Kullanıcının dilinde yanıt ver.`,
  C: `Sen KONSÜL masasının Eleştirmeni / Şüphecisisin. Kör noktaları, mantık hatalarını, eksik kanıtı, güvenlik ve yan etki risklerini ortaya çıkarırsın. Yıkıcı değil, kesin ve yapıcı ol. Her iddia için "ne yanlış gidebilir?" diye sor. Zayıf noktaları numaralandır. Kullanıcının dilinde yanıt ver.`,
  judge: `Sen KONSÜL masasının Hakem ve Sentez modelisin. Sana verilen tüm görüşleri tarafsız analiz et. Halüsinasyonları, çelişkileri ve spekülasyonu işaretle. Çıktın SADECE şu üç bölümden oluşsun ve markdown kullan:

## Ortaklaşılan Konular (Konsensüs)

## Anlaşmazlık ve Risk Noktaları

## Operatör İçin En Mantıklı Eylem Planı (Nihai Karar)

Net, uygulanabilir ve kısa tut. Kullanıcının dilinde yanıt ver.`,
};

export function councilTurnPrompt(params: {
  topic: string;
  role: string;
  name: string;
  transcript: string;
  humanNote?: string;
}): string {
  const extra = params.humanNote
    ? `\n\nOperatörün son müdahalesi:\n${params.humanNote}`
    : "";
  return `Konsey konusu:
${params.topic}

Şimdiye kadarki tutanak:
${params.transcript || "(Henüz başka üye konuşmadı. İlk söz sende.)"}
${extra}

Senin rolün: ${params.role} (${params.name}). Sıra sende. Önceki konuşmaları dikkate al, tekrar etme, kendi katkını net başlıklarla sun.`;
}

export function juryPrompt(question: string, role: string, name: string): string {
  return `Kör jüri sorusu (diğer modelleri göremezsin, bağımsız yanıt ver):

${question}

Rolün: ${role} (${name}). Kendi uzmanlık merceğinden, kanıtlı ve yapılandırılmış bir yanıt ver.`;
}

export function synthesisPrompt(source: string, extra?: string): string {
  const note = extra?.trim()
    ? `\n\nOperatörün ek talimatı:\n${extra.trim()}`
    : "";
  return `Aşağıdaki çoklu model tutanağını / bağımsız yanıtları analiz et ve nihai hakem raporunu üret.

--- TUTANAK ---
${source}
--- SON ---
${note}`;
}

export function formatTranscript(
  turns: { name: string; roleLabel: string; content: string; speaker: string }[],
): string {
  if (!turns.length) return "";
  return turns
    .map((turn) => {
      const label =
        turn.speaker === "human"
          ? "Operatör"
          : `${turn.name} — ${turn.roleLabel}`;
      return `### ${label}\n${turn.content}`;
    })
    .join("\n\n");
}
