function isTurkish(text: string): boolean {
  return /[çğıöşüÇĞİÖŞÜ]/.test(text) || /\b(ve|bir|bu|için|nedir|nasıl|neden|ile)\b/i.test(text);
}

function clip(text: string, max = 220): string {
  const cleaned = text.replace(/\s+/g, " ").trim();
  if (cleaned.length <= max) return cleaned || "konu";
  return `${cleaned.slice(0, max - 1)}…`;
}

export function buildDemoAnswer(params: {
  slot: string;
  name: string;
  role: string;
  topic: string;
  transcript?: string;
}): string {
  const tr = isTurkish(params.topic);
  const topic = clip(params.topic);
  const others = (params.transcript ?? "").trim();

  if (params.slot === "judge") {
    return tr
      ? `## Ortaklaşılan Konular (Konsensüs)

- Masa **${topic}** üzerinde aynı hedefi paylaşıyor: belirsizliği azaltmak, uygulanabilir bir yol seçmek ve operatörü tek bir karara götürmek.
- Üyeler; ölçülebilir başarı tanımı, aşamalı teslim ve geri dönüş kapısı (rollback) konusunda fiilen hizalı.
- Kanıta dayalı ilerlemek — varsayımı gerçek sanmamak — ortak zemin.

## Anlaşmazlık ve Risk Noktaları

- **Tempo vs. güvenlik:** Strateji hız isterken eleştirmen doğrulama katmanında ısrar ediyor.
- **Kapsam şişmesi:** Tekniker somut iskelet öneriyor; bu, görünmeyen bağımlılıkları erken kilitleyebilir.
- **Tek kaynak yanılgısı:** Tutanakta henüz dış doğrulama yok; halüsinasyon zinciri riski duruyor.
${others ? "- Önceki turların tekrar eden iddiaları, yeni kanıt eklenmeden güçlenmiş görünüyor — bunu spekülasyon olarak işaretliyorum." : ""}

## Operatör İçin En Mantıklı Eylem Planı (Nihai Karar)

1. **Tek cümlelik hedef** yazın (kimin için, hangi başarı, hangi süre).
2. **48 saatlik dilim:** en küçük doğrulanabilir parça + bir metrik + bir durdurma koşulu.
3. **Kırmızı bayrak listesi:** güvenlik, veri, geri alınamaz kararlar — bunları eleştirmenin veto alanına bırakın.
4. **Sentezi kilitleyin:** bu rapordaki 3 maddeyi görev kartına çevirin; yeni tartışma ancak yeni kanıtla açılsın.

Hakem kararı: hız ile ihtiyatı **ardışık** bağlayın — önce dar bir kanıt, sonra ölçek.`
      : `## Consensus

- The table shares one aim on **${topic}**: reduce uncertainty and give the operator a single actionable path.
- Success definition, staged delivery, and a rollback gate are common ground.
- Evidence before narrative.

## Disagreements & Risks

- Speed versus verification.
- Premature architecture lock-in.
- No external validation yet — hallucination chain risk remains.

## Action Plan (Final Decision)

1. Write a one-sentence objective.
2. Ship a 48-hour thinnest slice with one metric and a kill-switch.
3. Keep irreversible/security items on the critic's veto list.
4. Freeze this synthesis; reopen only with new evidence.`;
  }

  if (params.slot === "A") {
    return tr
      ? `**${params.name} · Stratejik çerçeve**

Konuyu tek cümlede sıkıştırıyorum: *${topic}* için önce belirsizliği, sonra hızı optimize edin.

### 1. Kuzey yıldızı
- **Kimin sorunu?** Operatörün karar yükü.
- **Ne değişmeli?** 72 saat içinde ölçülebilir bir çıktı.
- **Ne değişmemeli?** Güven, geri alınabilirlik, tek kaynaklı gerçek.

### 2. Üç seçenek
| Yol | Kazanç | Bedel |
|---|---|---|
| Dar dilim | Hızlı öğrenme | Eksik his |
| Büyük mimari | Ölçek vaadi | Geç doğrulama |
| Bekle-gör | Risk düşer | Fırsat maliyeti |

**Tavsiyem:** Dar dilim. Büyük bahsi, kanıt geldikten sonra büyütün.

### 3. Karar kuralı
Eğer 48 saatte bir sinyal yoksa pivot. Sinyal varsa teknikerin iskeletini 2. faza alın.

Eleştirmenin itirazını davet ediyorum — özellikle *geri dönüşsüz* adımlarda veto hakkı tanıyın.`
      : `**${params.name} · Strategy**

Compressing **${topic}** to a north star: optimize uncertainty first, speed second.

Pick the thinnest slice that teaches us something in 48 hours. Scale only after a signal. Give the critic veto on irreversible steps.`;
  }

  if (params.slot === "B") {
    return tr
      ? `**${params.name} · Teknik iskelet**

Stratejistin "dar dilim"ini çalışır hale getiriyorum. Konu: *${topic}*

### Mimari (bilinçli sade)
\`\`\`
Operatör UI  →  Konsey/Jüri/Hakem oturumları
              →  OpenAI-uyumlu proxy (SSE)
              →  9Router / Ollama / LM Studio / bulut
              →  PostgreSQL tutanak
\`\`\`

### 48 saatlik teslim
1. Tek giriş kutusu, üç koltuk, durdurma.
2. Akış (SSE) + iptal (\`AbortController\`).
3. Tutanak kaydı; sentez "Metni Çek" ile taşınır.

### Sözleşme
\`\`\`ts
POST /api/chat/stream
{ seatId, messages, temperature }
// SSE: { type: "delta", text } | { type: "done" }
\`\`\`

### Teknik riskler
- Yerel sağlayıcı kapalıysa zaman aşımı — **demo fallback** şart.
- Model kimlikleri sağlayıcıya özel; koltuk bazında tutulmalı.
- Paralel jüri: 3 abort sinyali, 3 bağımsız bağlam.

Eleştirmenin listesini bekliyorum; güvenlik ve veri sızıntısını orada kilitleriz.`
      : `**${params.name} · Technical spine**

Turning the thin slice for **${topic}** into a contract: SSE proxy, abort, persisted transcript, demo fallback if the local router is down.`;
  }

  return tr
    ? `**${params.name} · Şüpheci denetim**

Masayı sevdim, ama birkaç iddia henüz kanıt değil. Konu: *${topic}*

### Kırmızı bayraklar
1. **Hedef bulanık.** "İyi karar" ölçülmüyor. Kimin için iyi? Hangi metrik?
2. **Tek sağlayıcı yanılgısı.** 9Router yoksa tüm masa susar. Fallback bir lüks değil, güvenlik kemeridir.
3. **Zincirleme halüsinasyon.** Konseyde B, A'yı tekrar ederse hata çoğalır. Kör jüri tam da bu yüzden var — bağımsız ölçüm yapın.
4. **Kapsam tuzağı.** Teknikerin güzel iskeleti, 48 saatlik dilimi sessizce 3 haftaya çevirebilir.
5. **Operatör körlüğü.** Şık UI, yanlış eminliği gizler. Durdur düğmesi ve kaynak gösterimi şart.

### Ne isterim
- Her turda *yeni* bilgi. Tekrar = zayıflık.
- Geri alınamaz adımlar için açık veto.
- Sentezden önce kör jüri kolonu: aynı soru, sıfır bakışma.

Onay vermiyorum; **koşullu geçiş** veriyorum: metrik, fallback ve veto yazılmadan ölçek yok.`
    : `**${params.name} · Critique**

On **${topic}**: the goal is still fuzzy, a single local provider is a single point of failure, and council chatter can amplify hallucinations. Use the blind jury before you lock a decision. Conditional pass only.`;
}

export function chunkText(text: string, size = 12): string[] {
  const parts: string[] = [];
  let i = 0;
  while (i < text.length) {
    parts.push(text.slice(i, i + size));
    i += size;
  }
  return parts.length ? parts : [text];
}
