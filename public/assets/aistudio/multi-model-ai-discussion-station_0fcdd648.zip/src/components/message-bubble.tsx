import { MarkdownView } from "@/lib/markdown";
import type { ChatTurn } from "@/lib/types";

function formatTime(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString("tr-TR", {
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return "";
  }
}

export function MessageBubble({
  turn,
  compact = false,
}: {
  turn: ChatTurn;
  compact?: boolean;
}) {
  const isHuman = turn.speaker === "human";
  const color = turn.color ?? (isHuman ? "#e6edf3" : "#c084fc");

  return (
    <article
      className={`rise flex gap-3 ${compact ? "p-2" : "p-3"} ${isHuman ? "flex-row-reverse" : ""}`}
    >
      <img
        src={turn.avatar ?? "/images/seat-human.png"}
        alt=""
        className={`h-10 w-10 shrink-0 rounded-full object-cover ring-2 ${turn.streaming ? "speaking" : ""}`}
        style={{
          ["--seat" as string]: color,
          ["--tw-ring-color" as string]: color,
        }}
      />
      <div className={`min-w-0 flex-1 ${isHuman ? "text-right" : ""}`}>
        <div
          className={`mb-1 flex items-baseline gap-2 ${isHuman ? "justify-end" : ""}`}
        >
          <span className="font-display text-sm tracking-wide" style={{ color }}>
            {turn.name}
          </span>
          {turn.roleLabel ? (
            <span className="text-[10px] uppercase tracking-[0.16em] text-mute">
              {turn.roleLabel}
            </span>
          ) : null}
          {typeof turn.round === "number" && turn.round > 0 ? (
            <span className="text-[10px] text-mute">Tur {turn.round}</span>
          ) : null}
          <span className="text-[10px] text-mute">{formatTime(turn.createdAt)}</span>
        </div>
        <div
          className={`rounded-2xl border px-4 py-3 ${isHuman ? "ml-auto" : ""}`}
          style={{
            borderColor: `${color}33`,
            background: isHuman
              ? "linear-gradient(180deg, rgba(230,237,243,0.06), rgba(22,27,34,0.9))"
              : "linear-gradient(180deg, rgba(28,35,48,0.95), rgba(13,17,23,0.92))",
            boxShadow: `inset 3px 0 0 ${color}`,
            maxWidth: compact ? "100%" : "min(100%, 720px)",
            textAlign: "left",
          }}
        >
          {turn.error ? (
            <p className="text-sm text-red-300">{turn.content}</p>
          ) : (
            <MarkdownView content={turn.content || (turn.streaming ? "" : "…")} />
          )}
          {turn.streaming ? <span className="caret" style={{ color }} /> : null}
        </div>
      </div>
    </article>
  );
}
