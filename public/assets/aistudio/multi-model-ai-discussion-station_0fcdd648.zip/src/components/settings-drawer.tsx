"use client";

import { useState } from "react";
import type { ProviderRecord, SeatRecord, SettingsRecord } from "@/lib/types";

const SUGGESTED_MODELS = [
  "pineal-general-reasoning",
  "pineal-fast-extract",
  "asistan-ultra",
  "llama3.2",
  "qwen2.5-coder",
  "gpt-4o-mini",
  "deepseek-chat",
  "llama-3.3-70b-versatile",
];

export function SettingsDrawer({
  open,
  onClose,
  providers,
  seats,
  settings,
  onSaveProvider,
  onSaveSeat,
  onSaveSettings,
  onProbe,
}: {
  open: boolean;
  onClose: () => void;
  providers: ProviderRecord[];
  seats: SeatRecord[];
  settings: SettingsRecord;
  onSaveProvider: (id: string, patch: Partial<ProviderRecord>) => Promise<void>;
  onSaveSeat: (id: string, patch: Partial<SeatRecord>) => Promise<void>;
  onSaveSettings: (patch: Partial<SettingsRecord>) => Promise<void>;
  onProbe: (id: string) => Promise<string[]>;
}) {
  const [busy, setBusy] = useState<string | null>(null);
  const [models, setModels] = useState<Record<string, string[]>>({});
  const [notice, setNotice] = useState<string>("");

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <button className="absolute inset-0 bg-black/55" onClick={onClose} aria-label="Kapat" />
      <aside className="glass relative h-full w-full max-w-xl overflow-y-auto p-6">
        <div className="mb-6 flex items-start justify-between gap-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.22em] text-mute">Konfigürasyon</p>
            <h2 className="font-display text-2xl">Masa ayarları</h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-full border border-line px-3 py-1 text-sm text-mute hover:text-ink"
          >
            Kapat
          </button>
        </div>

        <section className="mb-8 space-y-3">
          <h3 className="font-display text-lg">Çalışma modu</h3>
          <label className="seat-chip flex items-center justify-between rounded-xl px-4 py-3">
            <span>
              <strong>Demo / simülasyon</strong>
              <p className="text-xs text-mute">Yerel model yoksa masayı yine de çalıştırır.</p>
            </span>
            <input
              type="checkbox"
              checked={settings.demoMode}
              onChange={(e) => onSaveSettings({ demoMode: e.target.checked })}
            />
          </label>
          <label className="seat-chip flex items-center justify-between rounded-xl px-4 py-3">
            <span>
              <strong>Otomatik düşüş</strong>
              <p className="text-xs text-mute">
                9Router / Ollama yanıt vermezse demo moda geç.
              </p>
            </span>
            <input
              type="checkbox"
              checked={settings.autoFallback}
              onChange={(e) => onSaveSettings({ autoFallback: e.target.checked })}
            />
          </label>
          <label className="seat-chip flex items-center justify-between rounded-xl px-4 py-3">
            <span>
              <strong>Otomatik tartışma turu</strong>
            </span>
            <input
              type="number"
              min={1}
              max={12}
              value={settings.debateRounds}
              onChange={(e) =>
                onSaveSettings({ debateRounds: Number(e.target.value) || 3 })
              }
              className="w-20 rounded-lg border border-line bg-void px-2 py-1 text-right"
            />
          </label>
        </section>

        <section className="mb-8">
          <h3 className="font-display mb-3 text-lg">Sağlayıcılar</h3>
          <div className="space-y-4">
            {providers.map((provider) => (
              <div key={provider.id} className="seat-chip rounded-2xl p-4">
                <div className="mb-3 flex items-center justify-between">
                  <input
                    defaultValue={provider.name}
                    onBlur={(e) =>
                      onSaveProvider(provider.id, { name: e.target.value })
                    }
                    className="bg-transparent font-display text-base"
                  />
                  <button
                    className="rounded-full border border-line px-3 py-1 text-xs text-mute hover:text-ink"
                    onClick={async () => {
                      setBusy(provider.id);
                      setNotice("");
                      try {
                        const list = await onProbe(provider.id);
                        setModels((prev) => ({ ...prev, [provider.id]: list }));
                        setNotice(
                          list.length
                            ? `${list.length} model bulundu.`
                            : "Bağlandı ama model listesi boş.",
                        );
                      } catch (error) {
                        setNotice(
                          error instanceof Error
                            ? error.message
                            : "Bağlantı kurulamadı.",
                        );
                      } finally {
                        setBusy(null);
                      }
                    }}
                  >
                    {busy === provider.id ? "Sınanıyor…" : "Bağlantıyı sına"}
                  </button>
                </div>
                <label className="mb-2 block text-[11px] uppercase tracking-widest text-mute">
                  Base URL
                </label>
                <input
                  defaultValue={provider.baseUrl}
                  onBlur={(e) =>
                    onSaveProvider(provider.id, { baseUrl: e.target.value })
                  }
                  className="mb-3 w-full rounded-xl border border-line bg-void px-3 py-2 font-mono text-xs"
                />
                <label className="mb-2 block text-[11px] uppercase tracking-widest text-mute">
                  API Key
                </label>
                <input
                  type="password"
                  defaultValue={provider.apiKey}
                  placeholder="Yerel sunucular için boş bırakılabilir"
                  onBlur={(e) =>
                    onSaveProvider(provider.id, { apiKey: e.target.value })
                  }
                  className="w-full rounded-xl border border-line bg-void px-3 py-2 font-mono text-xs"
                />
                {models[provider.id]?.length ? (
                  <p className="mt-2 font-mono text-[11px] text-mute">
                    {models[provider.id].slice(0, 8).join(" · ")}
                  </p>
                ) : null}
              </div>
            ))}
          </div>
          {notice ? <p className="mt-3 text-sm text-gold">{notice}</p> : null}
        </section>

        <section>
          <h3 className="font-display mb-3 text-lg">Koltuklar</h3>
          <div className="space-y-4">
            {seats.map((seat) => (
              <div key={seat.id} className="seat-chip rounded-2xl p-4">
                <div className="mb-3 flex items-center gap-3">
                  <span
                    className="h-3 w-3 rounded-full"
                    style={{ background: seat.color }}
                  />
                  <input
                    defaultValue={seat.name}
                    onBlur={(e) => onSaveSeat(seat.id, { name: e.target.value })}
                    className="bg-transparent font-display text-base"
                  />
                  <input
                    defaultValue={seat.role}
                    onBlur={(e) => onSaveSeat(seat.id, { role: e.target.value })}
                    className="flex-1 bg-transparent text-sm text-mute"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1 block text-[11px] uppercase tracking-widest text-mute">
                      Sağlayıcı
                    </label>
                    <select
                      value={seat.providerId}
                      onChange={(e) =>
                        onSaveSeat(seat.id, { providerId: e.target.value })
                      }
                      className="w-full rounded-xl border border-line bg-void px-3 py-2 text-sm"
                    >
                      {providers.map((provider) => (
                        <option key={provider.id} value={provider.id}>
                          {provider.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] uppercase tracking-widest text-mute">
                      Model ID
                    </label>
                    <input
                      list={`models-${seat.id}`}
                      defaultValue={seat.modelId}
                      onBlur={(e) =>
                        onSaveSeat(seat.id, { modelId: e.target.value })
                      }
                      className="w-full rounded-xl border border-line bg-void px-3 py-2 font-mono text-xs"
                    />
                    <datalist id={`models-${seat.id}`}>
                      {(models[seat.providerId] ?? SUGGESTED_MODELS).map((id) => (
                        <option key={id} value={id} />
                      ))}
                    </datalist>
                  </div>
                </div>
                <label className="mt-3 mb-1 block text-[11px] uppercase tracking-widest text-mute">
                  Sistem istemi / rol
                </label>
                <textarea
                  defaultValue={seat.systemPrompt}
                  onBlur={(e) =>
                    onSaveSeat(seat.id, { systemPrompt: e.target.value })
                  }
                  rows={5}
                  className="w-full rounded-xl border border-line bg-void px-3 py-2 text-sm leading-relaxed"
                />
              </div>
            ))}
          </div>
        </section>
      </aside>
    </div>
  );
}
