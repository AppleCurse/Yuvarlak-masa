"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MessageBubble } from "@/components/message-bubble";
import { SettingsDrawer } from "@/components/settings-drawer";
import { createId } from "@/lib/ids";
import {
  councilTurnPrompt,
  formatTranscript,
  juryPrompt,
  synthesisPrompt,
} from "@/lib/prompts";
import { streamChat } from "@/lib/stream-client";
import type {
  BootstrapPayload,
  ChatTurn,
  ProviderRecord,
  RoomId,
  SeatRecord,
  SeatSlot,
  SessionRecord,
  SettingsRecord,
} from "@/lib/types";

const COUNCIL_ORDER: SeatSlot[] = ["A", "B", "C"];

function avatarFor(slot: string): string {
  if (slot === "A") return "/images/seat-a.png";
  if (slot === "B") return "/images/seat-b.png";
  if (slot === "C") return "/images/seat-c.png";
  if (slot === "judge") return "/images/seat-judge.png";
  return "/images/seat-human.png";
}

function humanTurn(content: string): ChatTurn {
  return {
    id: createId("msg"),
    speaker: "human",
    name: "Operatör",
    roleLabel: "İnsan",
    content,
    color: "#e6edf3",
    avatar: avatarFor("human"),
    createdAt: new Date().toISOString(),
  };
}

function emptySettings(): SettingsRecord {
  return {
    id: "global",
    demoMode: false,
    autoFallback: true,
    debateRounds: 3,
  };
}

export function KonsulApp() {
  const [room, setRoom] = useState<RoomId>("council");
  const [boot, setBoot] = useState(true);
  const [providers, setProviders] = useState<ProviderRecord[]>([]);
  const [seats, setSeats] = useState<SeatRecord[]>([]);
  const [settings, setSettings] = useState<SettingsRecord>(emptySettings);
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [banner, setBanner] = useState<string | null>(null);

  const [councilSessionId, setCouncilSessionId] = useState<string | null>(null);
  const [councilTurns, setCouncilTurns] = useState<ChatTurn[]>([]);
  const [councilInput, setCouncilInput] = useState("");
  const [speakerIndex, setSpeakerIndex] = useState(0);
  const [round, setRound] = useState(1);
  const [councilBusy, setCouncilBusy] = useState(false);
  const [autoRunning, setAutoRunning] = useState(false);

  const [jurySessionId, setJurySessionId] = useState<string | null>(null);
  const [juryQuestion, setJuryQuestion] = useState("");
  const [juryCols, setJuryCols] = useState<Record<"A" | "B" | "C", ChatTurn | null>>({
    A: null,
    B: null,
    C: null,
  });
  const [juryBusy, setJuryBusy] = useState(false);

  const [synthSessionId, setSynthSessionId] = useState<string | null>(null);
  const [synthSource, setSynthSource] = useState("");
  const [synthNote, setSynthNote] = useState("");
  const [synthReport, setSynthReport] = useState<ChatTurn | null>(null);
  const [synthBusy, setSynthBusy] = useState(false);

  const abortRef = useRef<AbortController | null>(null);
  const stopRef = useRef(false);
  const autoRef = useRef(false);
  const speakerIndexRef = useRef(0);
  const roundRef = useRef(1);
  const councilTurnsRef = useRef<ChatTurn[]>([]);
  const councilSessionRef = useRef<string | null>(null);

  useEffect(() => {
    speakerIndexRef.current = speakerIndex;
  }, [speakerIndex]);
  useEffect(() => {
    roundRef.current = round;
  }, [round]);
  useEffect(() => {
    councilTurnsRef.current = councilTurns;
  }, [councilTurns]);
  useEffect(() => {
    councilSessionRef.current = councilSessionId;
  }, [councilSessionId]);

  const seatMap = useMemo(() => {
    const map = new Map<string, SeatRecord>();
    for (const seat of seats) map.set(seat.slot, seat);
    return map;
  }, [seats]);

  const providerName = useCallback(
    (id: string) => providers.find((item) => item.id === id)?.name ?? "Sağlayıcı",
    [providers],
  );

  const showToast = useCallback((text: string) => {
    setToast(text);
    window.setTimeout(() => setToast(null), 2800);
  }, []);

  const persist = useCallback(
    async (
      sessionId: string,
      turn: ChatTurn,
      extra?: { round?: number },
    ) => {
      await fetch(`/api/sessions/${sessionId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          seatId: turn.seatId ?? null,
          speaker: turn.speaker,
          name: turn.name,
          roleLabel: turn.roleLabel,
          content: turn.content,
          round: extra?.round ?? turn.round ?? 0,
        }),
      });
    },
    [],
  );

  const createSession = useCallback(async (mode: RoomId, topic: string) => {
    const response = await fetch("/api/sessions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        mode,
        topic,
        autoRounds: settings.debateRounds,
      }),
    });
    const row = (await response.json()) as SessionRecord;
    setSessions((prev) => [row, ...prev]);
    return row.id;
  }, [settings.debateRounds]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const response = await fetch("/api/bootstrap");
        const data = (await response.json()) as BootstrapPayload;
        if (cancelled) return;
        setProviders(data.providers);
        setSeats(data.seats as SeatRecord[]);
        setSettings(data.settings);
        setSessions(data.sessions);
      } catch {
        if (!cancelled) showToast("Başlangıç verisi alınamadı.");
      } finally {
        if (!cancelled) setBoot(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [showToast]);

  const stopAll = useCallback(() => {
    stopRef.current = true;
    autoRef.current = false;
    setAutoRunning(false);
    abortRef.current?.abort();
    abortRef.current = null;
    setCouncilBusy(false);
    setJuryBusy(false);
    setSynthBusy(false);
  }, []);

  const runSeat = useCallback(
    async (params: {
      seat: SeatRecord;
      userContent: string;
      round?: number;
      onLive: (turn: ChatTurn) => void;
    }): Promise<ChatTurn> => {
      const controller = abortRef.current ?? new AbortController();
      abortRef.current = controller;
      const id = createId("msg");
      let live: ChatTurn = {
        id,
        speaker: params.seat.slot,
        seatId: params.seat.id,
        name: params.seat.name,
        roleLabel: params.seat.role,
        content: "",
        color: params.seat.color,
        avatar: avatarFor(params.seat.slot),
        streaming: true,
        round: params.round,
        createdAt: new Date().toISOString(),
      };
      params.onLive(live);

      try {
        await streamChat({
          seatId: params.seat.id,
          messages: [{ role: "user", content: params.userContent }],
          signal: controller.signal,
          onEvent: (event) => {
            if (event.type === "meta" && event.demo) {
              setBanner(
                event.message ??
                  "Yerel model yok — masa demo / simülasyon akışında.",
              );
            }
            if (event.type === "delta" && event.text) {
              live = { ...live, content: live.content + event.text };
              params.onLive(live);
            }
            if (event.type === "error" && event.message) {
              live = { ...live, content: event.message, error: true };
              params.onLive(live);
            }
          },
        });
      } catch (error) {
        if ((error as Error).name === "AbortError") {
          live = { ...live, streaming: false };
          params.onLive(live);
          return live;
        }
        live = {
          ...live,
          error: true,
          content:
            error instanceof Error
              ? error.message
              : "Üretim kesildi veya bağlanılamadı.",
        };
        params.onLive(live);
      }

      live = { ...live, streaming: false };
      params.onLive(live);
      return live;
    },
    [],
  );

  const passFloor = useCallback(
    async (injected?: string) => {
      const index = speakerIndexRef.current;
      const currentRound = roundRef.current;
      const seat = seatMap.get(COUNCIL_ORDER[index]);
      if (!seat) return false;
      const historyStart = councilTurnsRef.current;
      const topic =
        injected?.trim() ||
        historyStart.find((item) => item.speaker === "human")?.content ||
        councilInput.trim();
      if (!topic) {
        showToast("Önce masaya bir konu bırakın.");
        return false;
      }

      stopRef.current = false;
      setCouncilBusy(true);
      let sessionId = councilSessionRef.current;
      let history = historyStart;

      if (injected?.trim()) {
        const human = humanTurn(injected.trim());
        history = [...history, human];
        councilTurnsRef.current = history;
        setCouncilTurns(history);
        setCouncilInput("");
        if (!sessionId) sessionId = await createSession("council", injected.trim());
        councilSessionRef.current = sessionId;
        setCouncilSessionId(sessionId);
        await persist(sessionId, human, { round: currentRound });
      } else if (!history.some((item) => item.speaker === "human")) {
        const human = humanTurn(topic);
        history = [human];
        councilTurnsRef.current = history;
        setCouncilTurns(history);
        setCouncilInput("");
        sessionId = sessionId ?? (await createSession("council", topic));
        councilSessionRef.current = sessionId;
        setCouncilSessionId(sessionId);
        await persist(sessionId, human, { round: 1 });
      } else if (!sessionId) {
        sessionId = await createSession("council", topic);
        councilSessionRef.current = sessionId;
        setCouncilSessionId(sessionId);
      }

      const prompt = councilTurnPrompt({
        topic,
        role: seat.role,
        name: seat.name,
        transcript: formatTranscript(history),
        humanNote: injected?.trim(),
      });

      const finished = await runSeat({
        seat,
        userContent: prompt,
        round: currentRound,
        onLive: (turn) => {
          setCouncilTurns((prev) => {
            const exists = prev.some((item) => item.id === turn.id);
            if (!exists) {
              const nextTurns = [...prev, turn];
              councilTurnsRef.current = nextTurns;
              return nextTurns;
            }
            const nextTurns = prev.map((item) => (item.id === turn.id ? turn : item));
            councilTurnsRef.current = nextTurns;
            return nextTurns;
          });
        },
      });

      if (sessionId && finished.content) {
        await persist(sessionId, finished, { round: currentRound });
      }

      const next = (index + 1) % COUNCIL_ORDER.length;
      speakerIndexRef.current = next;
      setSpeakerIndex(next);
      if (next === 0) {
        roundRef.current = currentRound + 1;
        setRound(currentRound + 1);
      }
      setCouncilBusy(false);
      abortRef.current = null;
      return true;
    },
    [councilInput, createSession, persist, runSeat, seatMap, showToast],
  );

  const autoDebate = useCallback(async () => {
    if (autoRef.current) return;
    autoRef.current = true;
    setAutoRunning(true);
    stopRef.current = false;
    const total = settings.debateRounds * 3;
    for (let i = 0; i < total; i += 1) {
      if (stopRef.current || !autoRef.current) break;
      const ok = await passFloor(i === 0 ? councilInput : undefined);
      if (!ok) break;
    }
    autoRef.current = false;
    setAutoRunning(false);
  }, [councilInput, passFloor, settings.debateRounds]);

  const sendHuman = useCallback(async () => {
    const text = councilInput.trim();
    if (!text) return;
    if (councilBusy) {
      const human = humanTurn(text);
      setCouncilTurns((prev) => [...prev, human]);
      setCouncilInput("");
      if (councilSessionId) await persist(councilSessionId, human, { round });
      return;
    }
    await passFloor(text);
  }, [councilBusy, councilInput, councilSessionId, passFloor, persist, round]);

  const startJury = useCallback(async () => {
    const question = juryQuestion.trim();
    if (!question) {
      showToast("Jüriye bir soru yazın.");
      return;
    }
    stopRef.current = false;
    setJuryBusy(true);
    setJuryCols({ A: null, B: null, C: null });
    const sessionId = await createSession("jury", question);
    setJurySessionId(sessionId);
    const human = humanTurn(question);
    await persist(sessionId, human);

    const controller = new AbortController();
    abortRef.current = controller;

    await Promise.all(
      (["A", "B", "C"] as const).map(async (slot) => {
        const seat = seatMap.get(slot);
        if (!seat) return;
        const finished = await runSeat({
          seat,
          userContent: juryPrompt(question, seat.role, seat.name),
          onLive: (turn) => {
            setJuryCols((prev) => ({ ...prev, [slot]: turn }));
          },
        });
        if (finished.content) await persist(sessionId, finished);
      }),
    );
    abortRef.current = null;
    setJuryBusy(false);
  }, [createSession, juryQuestion, persist, runSeat, seatMap, showToast]);

  const pullCouncil = useCallback(() => {
    const text = formatTranscript(councilTurns);
    if (!text) {
      showToast("Konsey tutanağı boş.");
      return;
    }
    setSynthSource(text);
    setRoom("synthesis");
    showToast("Konsey tutanağı hakem masasına çekildi.");
  }, [councilTurns, showToast]);

  const pullJury = useCallback(() => {
    const turns = (["A", "B", "C"] as const)
      .map((slot) => juryCols[slot])
      .filter((item): item is ChatTurn => Boolean(item?.content));
    if (!turns.length) {
      showToast("Jüri kolonları boş.");
      return;
    }
    const header = juryQuestion ? `Soru: ${juryQuestion}\n\n` : "";
    setSynthSource(header + formatTranscript(turns));
    setRoom("synthesis");
    showToast("Kör jüri yanıtları hakem masasına çekildi.");
  }, [juryCols, juryQuestion, showToast]);

  const runJudge = useCallback(async () => {
    const seat = seatMap.get("judge");
    if (!seat) return;
    if (!synthSource.trim()) {
      showToast("Önce tutanak çekin veya yapıştırın.");
      return;
    }
    setSynthBusy(true);
    const sessionId = synthSessionId ?? (await createSession("synthesis", "Hakem raporu"));
    setSynthSessionId(sessionId);
    const finished = await runSeat({
      seat,
      userContent: synthesisPrompt(synthSource, synthNote),
      onLive: (turn) => setSynthReport(turn),
    });
    if (finished.content) await persist(sessionId, finished);
    abortRef.current = null;
    setSynthBusy(false);
  }, [
    createSession,
    persist,
    runSeat,
    seatMap,
    showToast,
    synthNote,
    synthSessionId,
    synthSource,
  ]);

  const resetCouncil = () => {
    stopAll();
    setCouncilSessionId(null);
    setCouncilTurns([]);
    setSpeakerIndex(0);
    setRound(1);
    setCouncilInput("");
  };

  const resetJury = () => {
    stopAll();
    setJurySessionId(null);
    setJuryCols({ A: null, B: null, C: null });
    setJuryQuestion("");
  };

  const loadSession = async (id: string) => {
    const response = await fetch(`/api/sessions/${id}`);
    const data = (await response.json()) as {
      session: SessionRecord;
      messages: ChatTurn[];
    };
    const restored = data.messages.map((item) => ({
      ...item,
      color:
        item.speaker === "human"
          ? "#e6edf3"
          : seatMap.get(item.speaker as SeatSlot)?.color,
      avatar: avatarFor(item.speaker === "human" ? "human" : item.speaker),
    }));
    if (data.session.mode === "council") {
      setRoom("council");
      setCouncilSessionId(id);
      setCouncilTurns(restored);
      setCouncilInput(data.session.topic);
    } else if (data.session.mode === "jury") {
      setRoom("jury");
      setJurySessionId(id);
      setJuryQuestion(data.session.topic);
      const next = { A: null, B: null, C: null } as Record<
        "A" | "B" | "C",
        ChatTurn | null
      >;
      for (const item of restored) {
        if (item.speaker === "A" || item.speaker === "B" || item.speaker === "C") {
          next[item.speaker] = item;
        }
      }
      setJuryCols(next);
    } else {
      setRoom("synthesis");
      setSynthSessionId(id);
      const last = restored.at(-1) ?? null;
      setSynthReport(last);
    }
  };

  const busy = councilBusy || juryBusy || synthBusy || autoRunning;
  const nextSeat = seatMap.get(COUNCIL_ORDER[speakerIndex]);

  if (boot) {
    return (
      <main className="grid min-h-screen place-items-center">
        <div className="text-center">
          <img src="/images/seal.png" alt="" className="mx-auto h-24 w-24 rounded-full" />
          <p className="font-display mt-4 text-xl tracking-[0.3em]">KONSÜL</p>
          <p className="text-sm text-mute">Masa kuruluyor…</p>
        </div>
      </main>
    );
  }

  return (
    <div className="relative z-10 min-h-screen px-4 py-4 md:px-6">
      <header className="glass mx-auto flex max-w-[1600px] flex-col gap-4 rounded-3xl px-4 py-3 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-3">
          <img
            src="/images/seal.png"
            alt="KONSÜL"
            className="h-12 w-12 rounded-full ring-1 ring-violet/40"
          />
          <div>
            <p className="font-display text-xl leading-none tracking-[0.22em]">
              KONSÜL
            </p>
            <p className="text-[11px] uppercase tracking-[0.18em] text-mute">
              Konsey · Kör Jüri · Hakem
            </p>
          </div>
        </div>

        <nav className="tab-track w-full max-w-xl">
          {(
            [
              ["council", "Açık Konsey"],
              ["jury", "Kör Jüri"],
              ["synthesis", "Sentez"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setRoom(id)}
              className={`rounded-full px-3 py-2 text-sm transition ${
                room === id
                  ? "bg-raised text-ink shadow-[0_0_24px_rgba(192,132,252,0.25)]"
                  : "text-mute hover:text-ink"
              }`}
            >
              {label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <span className="hidden rounded-full border border-line px-3 py-1 text-[11px] uppercase tracking-widest text-mute md:inline">
            {settings.demoMode ? "Demo modu" : "9Router / OpenAI uyumlu"}
          </span>
          {busy ? (
            <button
              onClick={stopAll}
              className="rounded-full bg-red-500/90 px-4 py-2 text-sm font-semibold text-white"
            >
              Durdur
            </button>
          ) : null}
          <button
            onClick={() => setSettingsOpen(true)}
            className="rounded-full border border-line px-4 py-2 text-sm text-mute hover:text-ink"
          >
            Ayarlar
          </button>
        </div>
      </header>

      {banner ? (
        <div className="mx-auto mt-3 max-w-[1600px] rounded-2xl border border-gold/30 bg-gold/10 px-4 py-2 text-sm text-gold">
          {banner}
        </div>
      ) : null}

      <main className="mx-auto mt-4 max-w-[1600px]">
        {room === "council" ? (
          <section className="grid gap-4 xl:grid-cols-[320px_1fr]">
            <aside className="glass rounded-3xl p-4">
              <p className="text-[11px] uppercase tracking-[0.2em] text-mute">
                Masa 1 · Tartışma
              </p>
              <h2 className="font-display mb-4 text-2xl">Açık Konsey</h2>
              <div className="space-y-3">
                {COUNCIL_ORDER.map((slot, index) => {
                  const seat = seatMap.get(slot);
                  if (!seat) return null;
                  const speaking = councilBusy && nextSeat?.slot === slot;
                  return (
                    <div
                      key={slot}
                      className={`seat-chip flex items-center gap-3 rounded-2xl p-3 ${speaking ? "speaking" : ""}`}
                      style={{ ["--seat" as string]: seat.color }}
                    >
                      <img
                        src={avatarFor(slot)}
                        alt=""
                        className="h-12 w-12 rounded-full object-cover"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-display" style={{ color: seat.color }}>
                            {seat.name}
                          </span>
                          {index === speakerIndex ? (
                            <span className="text-[10px] uppercase tracking-widest text-mute">
                              sıra
                            </span>
                          ) : null}
                        </div>
                        <p className="truncate text-xs text-mute">
                          {seat.role} · {seat.modelId}
                        </p>
                        <p className="truncate text-[11px] text-mute/80">
                          {providerName(seat.providerId)}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-5 space-y-2">
                <p className="text-xs text-mute">
                  Tur {round} · sonraki söz:{" "}
                  <span style={{ color: nextSeat?.color }}>{nextSeat?.name}</span>
                </p>
                <button
                  onClick={() => passFloor()}
                  disabled={councilBusy}
                  className="w-full rounded-2xl bg-violet/90 px-4 py-3 font-semibold text-void hover:bg-violet disabled:opacity-50"
                >
                  Sonraki sözü ver
                </button>
                <button
                  onClick={autoDebate}
                  disabled={busy}
                  className="w-full rounded-2xl border border-line px-4 py-3 text-sm hover:border-violet/50 disabled:opacity-50"
                >
                  Otomatik tartışma · {settings.debateRounds} tur
                </button>
                <button
                  onClick={pullCouncil}
                  className="w-full rounded-2xl border border-line px-4 py-3 text-sm hover:border-gold/50"
                >
                  Metni çek → Hakem
                </button>
                <button
                  onClick={resetCouncil}
                  className="w-full rounded-2xl px-4 py-2 text-xs text-mute hover:text-ink"
                >
                  Yeni oturum
                </button>
              </div>

              {sessions.filter((item) => item.mode === "council").length ? (
                <select
                  className="mt-4 w-full rounded-xl border border-line bg-void px-3 py-2 text-xs"
                  defaultValue=""
                  onChange={(e) => {
                    if (e.target.value) void loadSession(e.target.value);
                  }}
                >
                  <option value="">Geçmiş konsey oturumları</option>
                  {sessions
                    .filter((item) => item.mode === "council")
                    .map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.title}
                      </option>
                    ))}
                </select>
              ) : null}
            </aside>

            <div className="glass flex min-h-[72vh] flex-col rounded-3xl">
              <div className="flex-1 space-y-1 overflow-y-auto p-4">
                {councilTurns.length === 0 ? (
                  <EmptyState
                    title="Konsey henüz sessiz"
                    body="Bir konu bırakın. Stratejist ilk sözü alır; tekniker üzerine ekler; eleştirmen denetler. İstediğiniz anda araya girebilirsiniz."
                  />
                ) : (
                  councilTurns.map((turn) => (
                    <MessageBubble key={turn.id} turn={turn} />
                  ))
                )}
              </div>
              <div className="border-t border-line p-4">
                <Composer
                  value={councilInput}
                  onChange={setCouncilInput}
                  onSubmit={() => void sendHuman()}
                  placeholder="Konuyu atın veya tartışmaya müdahale edin…"
                  accent="#c084fc"
                  disabled={false}
                />
              </div>
            </div>
          </section>
        ) : null}

        {room === "jury" ? (
          <section className="space-y-4">
            <div className="glass rounded-3xl p-4">
              <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="text-[11px] uppercase tracking-[0.2em] text-mute">
                    Masa 2 · Sıfır bakışma
                  </p>
                  <h2 className="font-display text-2xl">Kör Jüri Odası</h2>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => void startJury()}
                    disabled={juryBusy}
                    className="rounded-2xl bg-green/90 px-4 py-2 font-semibold text-void disabled:opacity-50"
                  >
                    Karşılaştır
                  </button>
                  <button
                    onClick={pullJury}
                    className="rounded-2xl border border-line px-4 py-2 text-sm"
                  >
                    Metni çek → Hakem
                  </button>
                  <button onClick={resetJury} className="rounded-2xl px-3 py-2 text-sm text-mute">
                    Temizle
                  </button>
                </div>
              </div>
              <Composer
                value={juryQuestion}
                onChange={setJuryQuestion}
                onSubmit={() => void startJury()}
                placeholder="Üç model aynı anda, birbirini duymadan yanıtlasın…"
                accent="#34d399"
              />
            </div>
            <div className="grid gap-4 lg:grid-cols-3">
              {(["A", "B", "C"] as const).map((slot) => {
                const seat = seatMap.get(slot);
                const turn = juryCols[slot];
                return (
                  <div key={slot} className="glass flex min-h-[58vh] flex-col rounded-3xl">
                    <div className="flex items-center gap-3 border-b border-line p-4">
                      <img
                        src={avatarFor(slot)}
                        alt=""
                        className={`h-10 w-10 rounded-full ${turn?.streaming ? "speaking" : ""}`}
                        style={{ ["--seat" as string]: seat?.color }}
                      />
                      <div>
                        <p className="font-display" style={{ color: seat?.color }}>
                          {seat?.name}
                        </p>
                        <p className="text-[11px] text-mute">
                          {seat?.role} · {seat?.modelId}
                        </p>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3">
                      {turn ? (
                        <MessageBubble turn={turn} compact />
                      ) : (
                        <p className="p-6 text-sm text-mute">
                          Bağımsız yanıt bekleniyor. Bu kolon diğerlerini asla görmez.
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        ) : null}

        {room === "synthesis" ? (
          <section className="grid gap-4 lg:grid-cols-2">
            <div className="glass flex min-h-[72vh] flex-col rounded-3xl p-4">
              <p className="text-[11px] uppercase tracking-[0.2em] text-mute">
                Masa 3 · Nihai karar
              </p>
              <h2 className="font-display mb-3 text-2xl">Sentez ve Hakem</h2>
              <div className="mb-3 flex flex-wrap gap-2">
                <button
                  onClick={pullCouncil}
                  className="rounded-full border border-line px-3 py-1 text-xs hover:border-violet"
                >
                  Konseyden çek
                </button>
                <button
                  onClick={pullJury}
                  className="rounded-full border border-line px-3 py-1 text-xs hover:border-green"
                >
                  Jüriden çek
                </button>
              </div>
              <textarea
                value={synthSource}
                onChange={(e) => setSynthSource(e.target.value)}
                placeholder="Tutanak burada toplanır…"
                className="min-h-[36vh] flex-1 rounded-2xl border border-line bg-void/80 p-4 font-mono text-xs leading-relaxed"
              />
              <div className="mt-3">
                <Composer
                  value={synthNote}
                  onChange={setSynthNote}
                  onSubmit={() => void runJudge()}
                  placeholder="Hakeme ek talimat (opsiyonel)…"
                  accent="#fbbf24"
                  submitLabel="Analiz et & raporla"
                />
              </div>
            </div>
            <div className="glass min-h-[72vh] overflow-y-auto rounded-3xl p-4">
              <div className="mb-3 flex items-center gap-3">
                <img
                  src={avatarFor("judge")}
                  alt=""
                  className={`h-12 w-12 rounded-full ${synthReport?.streaming ? "speaking" : ""}`}
                  style={{ ["--seat" as string]: seatMap.get("judge")?.color }}
                />
                <div>
                  <p className="font-display text-gold">
                    {seatMap.get("judge")?.name ?? "Hakem"}
                  </p>
                  <p className="text-xs text-mute">
                    Konsensüs · Risk · Eylem planı
                  </p>
                </div>
              </div>
              {synthReport ? (
                <MessageBubble turn={synthReport} />
              ) : (
                <EmptyState
                  title="Rapor bekleniyor"
                  body="Konsey veya kör jüri metnini çekin. Hakem ortak zemin, çatışma ve tek bir eylem planı üretir."
                />
              )}
            </div>
          </section>
        ) : null}
      </main>

      <SettingsDrawer
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        providers={providers}
        seats={seats}
        settings={settings}
        onSaveProvider={async (id, patch) => {
          const response = await fetch(`/api/providers/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(patch),
          });
          const row = (await response.json()) as ProviderRecord;
          setProviders((prev) => prev.map((item) => (item.id === id ? row : item)));
        }}
        onSaveSeat={async (id, patch) => {
          const response = await fetch(`/api/seats/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(patch),
          });
          const row = (await response.json()) as SeatRecord;
          setSeats((prev) => prev.map((item) => (item.id === id ? row : item)));
        }}
        onSaveSettings={async (patch) => {
          const response = await fetch("/api/settings", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(patch),
          });
          const row = (await response.json()) as SettingsRecord;
          setSettings(row);
        }}
        onProbe={async (id) => {
          const response = await fetch(`/api/providers/${id}/models`);
          const json = (await response.json()) as {
            models?: string[];
            error?: string;
          };
          if (!response.ok) throw new Error(json.error || "Bağlantı yok");
          return json.models ?? [];
        }}
      />

      {toast ? (
        <div className="glass fixed right-5 bottom-5 z-50 rounded-2xl px-4 py-3 text-sm">
          {toast}
        </div>
      ) : null}
    </div>
  );
}

function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="grid h-full min-h-[48vh] place-items-center p-8 text-center">
      <div>
        <img src="/images/seal.png" alt="" className="mx-auto mb-4 h-16 w-16 rounded-full opacity-80" />
        <h3 className="font-display text-xl">{title}</h3>
        <p className="mx-auto mt-2 max-w-md text-sm text-mute">{body}</p>
      </div>
    </div>
  );
}

function Composer({
  value,
  onChange,
  onSubmit,
  placeholder,
  accent,
  disabled,
  submitLabel = "Gönder",
}: {
  value: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  placeholder: string;
  accent: string;
  disabled?: boolean;
  submitLabel?: string;
}) {
  return (
    <div className="flex items-end gap-3">
      <img src="/images/seat-human.png" alt="" className="mb-1 h-9 w-9 rounded-full" />
      <textarea
        value={value}
        disabled={disabled}
        placeholder={placeholder}
        rows={2}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
            e.preventDefault();
            onSubmit();
          }
        }}
        className="flex-1 resize-none rounded-2xl border border-line bg-void/70 px-4 py-3 text-sm"
        style={{ ["--accent" as string]: accent }}
      />
      <button
        onClick={onSubmit}
        disabled={disabled}
        className="rounded-2xl px-4 py-3 text-sm font-semibold text-void disabled:opacity-50"
        style={{ background: accent }}
      >
        {submitLabel}
      </button>
    </div>
  );
}
