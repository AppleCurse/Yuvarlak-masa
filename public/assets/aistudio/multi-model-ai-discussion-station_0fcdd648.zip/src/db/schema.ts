import {
  boolean,
  integer,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const providers = pgTable("providers", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  baseUrl: text("base_url").notNull(),
  apiKey: text("api_key").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const seats = pgTable("seats", {
  id: text("id").primaryKey(),
  slot: text("slot").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  systemPrompt: text("system_prompt").notNull(),
  modelId: text("model_id").notNull(),
  providerId: text("provider_id")
    .notNull()
    .references(() => providers.id, { onDelete: "cascade" }),
  color: text("color").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const appSettings = pgTable("app_settings", {
  id: text("id").primaryKey(),
  demoMode: boolean("demo_mode").notNull().default(false),
  autoFallback: boolean("auto_fallback").notNull().default(true),
  debateRounds: integer("debate_rounds").notNull().default(3),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  mode: text("mode").notNull(),
  title: text("title").notNull(),
  topic: text("topic").notNull().default(""),
  status: text("status").notNull().default("idle"),
  autoRounds: integer("auto_rounds").notNull().default(3),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const messages = pgTable("messages", {
  id: text("id").primaryKey(),
  sessionId: text("session_id")
    .notNull()
    .references(() => sessions.id, { onDelete: "cascade" }),
  seatId: text("seat_id"),
  speaker: text("speaker").notNull(),
  name: text("name").notNull(),
  roleLabel: text("role_label").notNull().default(""),
  content: text("content").notNull(),
  round: integer("round").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});
