import type { Metadata } from "next";
import type { ReactNode } from "react";
import { JetBrains_Mono, Outfit, Syne } from "next/font/google";
import "./globals.css";

const outfit = Outfit({
  subsets: ["latin", "latin-ext"],
  variable: "--font-outfit",
});

const syne = Syne({
  subsets: ["latin", "latin-ext"],
  variable: "--font-syne",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin", "latin-ext"],
  variable: "--font-jetbrains",
});

export const metadata: Metadata = {
  title: "KONSÜL AI — Konsey ve Kör Jüri İstasyonu",
  description:
    "Çoklu model tartışma, kör jüri karşılaştırması ve hakem sentezi. OpenAI uyumlu yerel ve bulut sağlayıcılar.",
  icons: { icon: "/images/seal.png" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr">
      <body
        className={`${outfit.variable} ${syne.variable} ${jetbrains.variable} bg-void text-ink antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
