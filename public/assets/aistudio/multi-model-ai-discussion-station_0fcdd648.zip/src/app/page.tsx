import { KonsulApp } from "@/components/konsul-app";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <KonsulApp />;
}
