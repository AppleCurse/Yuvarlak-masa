import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appSettings } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(appSettings)
    .where(eq(appSettings.id, "global"));
  return Response.json(rows[0] ?? null);
}

export async function PATCH(request: Request) {
  await ensureSeeded();
  const body = (await request.json()) as {
    demoMode?: boolean;
    autoFallback?: boolean;
    debateRounds?: number;
  };

  const patch: {
    demoMode?: boolean;
    autoFallback?: boolean;
    debateRounds?: number;
  } = {};
  if (typeof body.demoMode === "boolean") patch.demoMode = body.demoMode;
  if (typeof body.autoFallback === "boolean") patch.autoFallback = body.autoFallback;
  if (typeof body.debateRounds === "number") {
    patch.debateRounds = Math.min(12, Math.max(1, Math.round(body.debateRounds)));
  }

  const [row] = await db
    .update(appSettings)
    .set(patch)
    .where(eq(appSettings.id, "global"))
    .returning();

  return Response.json(row);
}
