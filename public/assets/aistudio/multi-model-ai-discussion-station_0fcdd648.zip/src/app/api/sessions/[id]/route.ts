import { eq } from "drizzle-orm";
import { db } from "@/db";
import { messages, sessions } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
  if (!session) {
    return Response.json({ error: "Oturum bulunamadı." }, { status: 404 });
  }
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.sessionId, id));
  return Response.json({
    session: { ...session, createdAt: session.createdAt.toISOString() },
    messages: rows.map((row) => ({
      ...row,
      createdAt: row.createdAt.toISOString(),
    })),
  });
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = (await request.json()) as {
    status?: string;
    title?: string;
    topic?: string;
  };
  const patch: Record<string, string | Date> = { updatedAt: new Date() };
  if (typeof body.status === "string") patch.status = body.status;
  if (typeof body.title === "string") patch.title = body.title;
  if (typeof body.topic === "string") patch.topic = body.topic;
  const [row] = await db
    .update(sessions)
    .set(patch)
    .where(eq(sessions.id, id))
    .returning();
  return Response.json(row);
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  await db.delete(messages).where(eq(messages.sessionId, id));
  await db.delete(sessions).where(eq(sessions.id, id));
  return Response.json({ ok: true });
}
