import { desc } from "drizzle-orm";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { createId, shortTitle } from "@/lib/ids";
import { ensureSeeded } from "@/lib/seed";
import type { RoomId } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(sessions)
    .orderBy(desc(sessions.createdAt))
    .limit(40);
  return Response.json(
    rows.map((row) => ({ ...row, createdAt: row.createdAt.toISOString() })),
  );
}

export async function POST(request: Request) {
  await ensureSeeded();
  const body = (await request.json()) as {
    mode?: RoomId;
    title?: string;
    topic?: string;
    autoRounds?: number;
  };
  const mode = body.mode ?? "council";
  const topic = body.topic?.trim() ?? "";
  const [row] = await db
    .insert(sessions)
    .values({
      id: createId("session"),
      mode,
      title: shortTitle(body.title || topic || mode),
      topic,
      status: "idle",
      autoRounds: body.autoRounds ?? 3,
    })
    .returning();
  return Response.json({
    ...row,
    createdAt: row.createdAt.toISOString(),
  });
}
