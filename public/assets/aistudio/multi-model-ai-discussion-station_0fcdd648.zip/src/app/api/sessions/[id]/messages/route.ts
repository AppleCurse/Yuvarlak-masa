import { eq } from "drizzle-orm";
import { db } from "@/db";
import { messages, sessions } from "@/db/schema";
import { createId } from "@/lib/ids";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.sessionId, id));
  return Response.json(
    rows.map((row) => ({ ...row, createdAt: row.createdAt.toISOString() })),
  );
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
  if (!session) {
    return Response.json({ error: "Oturum bulunamadı." }, { status: 404 });
  }
  const body = (await request.json()) as {
    seatId?: string | null;
    speaker?: string;
    name?: string;
    roleLabel?: string;
    content?: string;
    round?: number;
  };
  const [row] = await db
    .insert(messages)
    .values({
      id: createId("msg"),
      sessionId: id,
      seatId: body.seatId ?? null,
      speaker: body.speaker ?? "assistant",
      name: body.name ?? "Model",
      roleLabel: body.roleLabel ?? "",
      content: body.content ?? "",
      round: body.round ?? 0,
    })
    .returning();
  return Response.json({
    ...row,
    createdAt: row.createdAt.toISOString(),
  });
}
