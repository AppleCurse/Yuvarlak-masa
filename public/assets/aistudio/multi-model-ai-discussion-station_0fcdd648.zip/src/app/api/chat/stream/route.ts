import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appSettings, providers, seats } from "@/db/schema";
import { buildDemoAnswer, chunkText } from "@/lib/demo";
import {
  extractDelta,
  joinUrl,
  resolveApiKey,
  type OpenAiChatMessage,
} from "@/lib/openai";
import { ensureSeeded } from "@/lib/seed";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

function encode(data: unknown): Uint8Array {
  return new TextEncoder().encode(`data: ${JSON.stringify(data)}\n\n`);
}

function lastUserText(messages: OpenAiChatMessage[]): string {
  const last = [...messages].reverse().find((item) => item.role === "user");
  return last?.content ?? "";
}

async function demoStream(
  controller: ReadableStreamDefaultController<Uint8Array>,
  text: string,
  model: string,
  signal: AbortSignal,
) {
  controller.enqueue(encode({ type: "meta", demo: true, model }));
  for (const chunk of chunkText(text, 14)) {
    if (signal.aborted) break;
    controller.enqueue(encode({ type: "delta", text: chunk }));
    await new Promise((resolve) => setTimeout(resolve, 16));
  }
  controller.enqueue(encode({ type: "done", demo: true }));
}

export async function POST(request: Request) {
  await ensureSeeded();
  const body = (await request.json()) as {
    seatId?: string;
    messages?: OpenAiChatMessage[];
    temperature?: number;
  };

  if (!body.seatId || !Array.isArray(body.messages)) {
    return Response.json(
      { error: "seatId ve messages zorunlu." },
      { status: 400 },
    );
  }

  const [seat] = await db.select().from(seats).where(eq(seats.id, body.seatId));
  if (!seat) {
    return Response.json({ error: "Koltuk bulunamadı." }, { status: 404 });
  }
  const [provider] = await db
    .select()
    .from(providers)
    .where(eq(providers.id, seat.providerId));
  if (!provider) {
    return Response.json({ error: "Sağlayıcı bulunamadı." }, { status: 404 });
  }
  const [settings] = await db
    .select()
    .from(appSettings)
    .where(eq(appSettings.id, "global"));

  const chatMessages: OpenAiChatMessage[] = [
    { role: "system", content: seat.systemPrompt },
    ...body.messages.filter((item) => item.role !== "system"),
  ];
  const topic = lastUserText(chatMessages);
  const demoText = buildDemoAnswer({
    slot: seat.slot,
    name: seat.name,
    role: seat.role,
    topic,
  });

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const abort = () => {
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };
      request.signal.addEventListener("abort", abort);

      try {
        if (settings?.demoMode) {
          await demoStream(controller, demoText, `${seat.modelId} · demo`, request.signal);
          return;
        }

        const apiKey = resolveApiKey(provider.baseUrl, provider.apiKey);
        const headers: Record<string, string> = {
          "Content-Type": "application/json",
        };
        if (apiKey) headers.Authorization = `Bearer ${apiKey}`;

        const upstream = await fetch(joinUrl(provider.baseUrl, "chat/completions"), {
          method: "POST",
          headers,
          body: JSON.stringify({
            model: seat.modelId,
            messages: chatMessages,
            stream: true,
            temperature: body.temperature ?? 0.7,
          }),
          signal: request.signal,
        });

        if (!upstream.ok || !upstream.body) {
          const errText = await upstream.text().catch(() => "");
          if (settings?.autoFallback !== false) {
            controller.enqueue(
              encode({
                type: "meta",
                demo: true,
                model: seat.modelId,
                message: `Sağlayıcı yanıt vermedi (${upstream.status}). Demo moda düşüldü.`,
              }),
            );
            await demoStream(
              controller,
              demoText,
              `${seat.modelId} · demo`,
              request.signal,
            );
            return;
          }
          controller.enqueue(
            encode({
              type: "error",
              message:
                errText.slice(0, 280) ||
                `Sağlayıcı hatası (${upstream.status}). Base URL / API anahtarını kontrol edin.`,
            }),
          );
          controller.enqueue(encode({ type: "done" }));
          return;
        }

        controller.enqueue(
          encode({ type: "meta", demo: false, model: seat.modelId }),
        );

        const reader = upstream.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const pieces = buffer.split("\n");
          buffer = pieces.pop() ?? "";
          for (const piece of pieces) {
            const line = piece.trim();
            if (!line.startsWith("data:")) continue;
            const raw = line.slice(5).trim();
            if (!raw || raw === "[DONE]") continue;
            try {
              const json = JSON.parse(raw) as unknown;
              const delta = extractDelta(json);
              if (delta) {
                controller.enqueue(encode({ type: "delta", text: delta }));
              }
            } catch {
              /* ignore malformed chunks */
            }
          }
        }
        controller.enqueue(encode({ type: "done" }));
      } catch (error) {
        if (request.signal.aborted) {
          controller.enqueue(encode({ type: "done" }));
          return;
        }
        if (settings?.autoFallback !== false) {
          controller.enqueue(
            encode({
              type: "meta",
              demo: true,
              message:
                error instanceof Error
                  ? `${error.message} — demo moda düşüldü.`
                  : "Bağlantı yok, demo moda düşüldü.",
            }),
          );
          await demoStream(
            controller,
            demoText,
            `${seat.modelId} · demo`,
            request.signal,
          );
          return;
        }
        controller.enqueue(
          encode({
            type: "error",
            message:
              error instanceof Error
                ? error.message
                : "Yerel modele bağlanılamadı.",
          }),
        );
        controller.enqueue(encode({ type: "done" }));
      } finally {
        request.signal.removeEventListener("abort", abort);
        try {
          controller.close();
        } catch {
          /* closed */
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
