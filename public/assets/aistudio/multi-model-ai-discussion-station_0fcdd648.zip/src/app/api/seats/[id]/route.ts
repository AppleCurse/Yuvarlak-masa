import { eq } from "drizzle-orm";
import { db } from "@/db";
import { seats } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = (await request.json()) as {
    name?: string;
    role?: string;
    systemPrompt?: string;
    modelId?: string;
    providerId?: string;
    color?: string;
  };

  const [row] = await db
    .update(seats)
    .set({
      ...(typeof body.name === "string" ? { name: body.name.trim() } : {}),
      ...(typeof body.role === "string" ? { role: body.role.trim() } : {}),
      ...(typeof body.systemPrompt === "string"
        ? { systemPrompt: body.systemPrompt }
        : {}),
      ...(typeof body.modelId === "string" ? { modelId: body.modelId.trim() } : {}),
      ...(typeof body.providerId === "string" ? { providerId: body.providerId } : {}),
      ...(typeof body.color === "string" ? { color: body.color } : {}),
      updatedAt: new Date(),
    })
    .where(eq(seats.id, id))
    .returning();

  if (!row) {
    return Response.json({ error: "Koltuk bulunamadı." }, { status: 404 });
  }
  return Response.json(row);
}
