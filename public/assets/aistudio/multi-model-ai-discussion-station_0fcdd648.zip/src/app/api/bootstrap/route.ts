import { desc } from "drizzle-orm";
import { db } from "@/db";
import { appSettings, providers, seats, sessions } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();

  const [providerRows, seatRows, settingRows, sessionRows] = await Promise.all([
    db.select().from(providers),
    db.select().from(seats),
    db.select().from(appSettings),
    db.select().from(sessions).orderBy(desc(sessions.createdAt)).limit(24),
  ]);

  const settings = settingRows[0] ?? {
    id: "global",
    demoMode: false,
    autoFallback: true,
    debateRounds: 3,
  };

  return Response.json({
    providers: providerRows,
    seats: seatRows,
    settings,
    sessions: sessionRows.map((row) => ({
      ...row,
      createdAt: row.createdAt.toISOString(),
    })),
  });
}
