import { eq } from "drizzle-orm";
import { db } from "@/db";
import { providers } from "@/db/schema";
import { listRemoteModels } from "@/lib/openai";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const [provider] = await db
    .select()
    .from(providers)
    .where(eq(providers.id, id));
  if (!provider) {
    return Response.json({ error: "Sağlayıcı bulunamadı." }, { status: 404 });
  }
  try {
    const models = await listRemoteModels(provider.baseUrl, provider.apiKey);
    return Response.json({ models });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Model listesi alınamadı.";
    return Response.json({ error: message, models: [] }, { status: 502 });
  }
}
