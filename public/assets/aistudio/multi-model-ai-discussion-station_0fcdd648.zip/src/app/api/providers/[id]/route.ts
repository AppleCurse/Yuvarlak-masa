import { eq } from "drizzle-orm";
import { db } from "@/db";
import { providers } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = (await request.json()) as {
    name?: string;
    baseUrl?: string;
    apiKey?: string;
  };
  const patch: { name?: string; baseUrl?: string; apiKey?: string; updatedAt: Date } = {
    updatedAt: new Date(),
  };
  if (typeof body.name === "string") patch.name = body.name.trim();
  if (typeof body.baseUrl === "string") patch.baseUrl = body.baseUrl.trim();
  if (typeof body.apiKey === "string") patch.apiKey = body.apiKey;
  const [row] = await db
    .update(providers)
    .set(patch)
    .where(eq(providers.id, id))
    .returning();
  if (!row) {
    return Response.json({ error: "Sağlayıcı bulunamadı." }, { status: 404 });
  }
  return Response.json(row);
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  await db.delete(providers).where(eq(providers.id, id));
  return Response.json({ ok: true });
}
