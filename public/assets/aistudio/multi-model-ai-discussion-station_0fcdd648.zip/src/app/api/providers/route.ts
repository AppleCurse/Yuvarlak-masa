import { db } from "@/db";
import { providers } from "@/db/schema";
import { createId } from "@/lib/ids";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db.select().from(providers);
  return Response.json(rows);
}

export async function POST(request: Request) {
  await ensureSeeded();
  const body = (await request.json()) as {
    name?: string;
    baseUrl?: string;
    apiKey?: string;
  };
  const name = body.name?.trim();
  const baseUrl = body.baseUrl?.trim();
  if (!name || !baseUrl) {
    return Response.json(
      { error: "Ad ve Base URL zorunlu." },
      { status: 400 },
    );
  }
  const [row] = await db
    .insert(providers)
    .values({
      id: createId("provider"),
      name,
      baseUrl,
      apiKey: body.apiKey?.trim() ?? "",
    })
    .returning();
  return Response.json(row);
}
